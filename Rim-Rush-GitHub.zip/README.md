# Rim Rush — GitHub Pages edition

## What is included
The complete browser game for offline play: Quick Match against AI, two players sharing one keyboard, Training, Watch Game, the separate 500-credit play-money picks bank, tournaments, franchise, full box scores, all 30 teams, customization, name-tag settings, player upgrades, and 30 celebration effects.

Online multiplayer and persistent ranked profiles need a server. GitHub Pages cannot run that server. The Online button explains this instead of making broken API requests. The existing hosted edition remains available separately. This export does not contain your personal saves; progress saves in the browser for the new website address.

## Upload to GitHub (no build or installation needed)
1. Extract/unzip Rim-Rush-GitHub.zip.
2. Open your GitHub repository, then Code > Add file > Upload files.
3. Upload the CONTENTS of the extracted folder, including index.html, src, resources, README.md and .nojekyll. Do not upload the ZIP itself or wrap everything in another folder.
4. Commit changes. The repository should show index.html immediately, beside src and resources.
5. Settings > Pages > Source: Deploy from a branch > Branch: main > Folder: /(root) > Save.
6. Wait for publishing. Settings > Pages displays the website link, normally https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/.

## Controls
WASD move; Space shoot; Q pass/inbound; E block; K steal; C crossover; X spin; V step back; Alt switch; F fullscreen. Local Player 2 uses the arrow keys, Enter and Right Shift. Use How to Play in the game for all controls. Touch controls are included.

## Local play
Browser modules usually cannot load by double-clicking index.html as a file. Use the published GitHub Pages link, or serve this folder with a local web server.
