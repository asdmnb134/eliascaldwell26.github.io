export function createCareerView(manager,hooks) {
  const $=id=>document.getElementById(id),dialog=$('career-dialog'),body=$('career-body');
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let mode='tournament',tab='overview',creating=false,busy=false,message='',error=false,conference='east';
  let tradeTeam='ATL',tradeOut=null,tradeIn=null;
  const team=id=>manager.team(id),player=id=>manager.player(id);
  const button=(action,label,primary=false,disabled=false)=>'<button type="button" data-career="'+action+'" class="'+(primary?'career-primary':'career-button')+'"'+(disabled||busy?' disabled':'')+'>'+label+'</button>';
  function teamOptions(selected,exclude=null) {return manager.league.teams.filter(t=>t.id!==exclude).map(t=>'<option value="'+t.id+'"'+(t.id===selected?' selected':'')+'>'+escape(t.name)+'</option>').join('');}
  function playerOptions(ids,selected) {return ids.map(id=>{const p=player(id);return '<option value="'+id+'"'+(String(id)===String(selected)?' selected':'')+'>'+escape(p.name)+' · '+p.position+' · '+manager.overall(id)+' OVR</option>';}).join('');}
  function logo(id,size=48) {return '<img src="'+team(id).logo+'" alt="'+escape(team(id).name)+' logo" width="'+size+'" height="'+size+'">';}
  function render() {
    const data=manager.state[mode];
    $('career-title').textContent=mode==='tournament'?'RACE FOR THE RING.':'THE FRANCHISE OFFICE.';
    $('career-kicker').textContent=mode==='tournament'?'WIN. ADVANCE. REPEAT.':'BUILD YOUR FIVE. BUILD A DYNASTY.';
    for(const id of ['tournament','franchise']) {
      const b=$('career-mode-'+id);b.classList.toggle('selected',mode===id);b.setAttribute('aria-pressed',String(mode===id));
    }
    let html='';
    if(!data||creating)html=setup(data);
    else if(mode==='tournament')html=tournament(data);
    else html=franchise(data);
    const note=message||manager.warning;
    body.innerHTML=(note?'<p class="career-feedback '+(error?'error':'')+'" role="status">'+escape(note)+'</p>':'')+html;
  }
  function setup(existing) {
    const selected=existing?.teamId||'NYK';
    return '<section class="career-setup"><div class="career-setup-copy"><span class="career-tag">'+(mode==='tournament'?'THE CUP':'SEASON ONE')+'</span><h3>'+(mode==='tournament'?'One bracket. One champion.':'Your team. Your decisions.')+'</h3><p>'+
      (mode==='tournament'?'Take any team into an 8- or 16-team knockout tournament. Play your games or simulate them. The bracket and every box score stay saved.':'Manage all 30 teams in a 29-game league season. Set your five, make fair trades, play or simulate games, reach the best-of-three playoffs, and draft a fictional rookie for next season.')+'</p><div class="career-save-note">Progress saves automatically on this browser.</div></div>'+
      '<div class="career-setup-form"><label>YOUR TEAM<select id="career-team">'+teamOptions(selected)+'</select></label>'+
      (mode==='tournament'?'<label>TOURNAMENT FIELD<select id="career-size"><option value="16">16 teams / 4 rounds</option><option value="8">8 teams / 3 rounds</option></select></label>':'')+
      '<div class="career-field-row"><label>PLAYED GAME LENGTH<select id="career-duration"><option value="30">30 seconds</option><option value="60" selected>60 seconds</option><option value="90">90 seconds</option></select></label><label>DIFFICULTY<select id="career-difficulty"><option value="easy">Rookie</option><option value="normal" selected>Pro</option><option value="pro">All-Star</option><option value="hard">Legend</option></select></label></div>'+
      '<label>GAME FORMAT<select id="career-quarters"><option value="1">1 quarter / Quick game</option><option value="4">4 quarters / Full game</option></select></label><p class="career-small">Length is per quarter. Played games use arcade timing. Simulated games use 48-minute box scores.</p>'+
      (existing?'<p class="career-small warning">Starting a new '+mode+' replaces this saved run.</p>':'')+
      button('create','START '+(mode==='tournament'?'TOURNAMENT':'FRANCHISE')+' →',true)+
      (existing?button('cancel-new','KEEP MY SAVED RUN'):'')+'</div></section>';
  }
  function matchup(context) {
    if(!context)return '';
    const a=team(context.teamId),b=team(context.opponentId);
    return '<div class="career-matchup"><span class="career-tag">NEXT GAME</span><div class="career-matchup-teams"><div>'+logo(a.id,66)+'<strong>'+escape(a.name)+'</strong><small>'+manager.teamRating(mode,a.id)+' OVR</small></div><b>VS</b><div>'+logo(b.id,66)+'<strong>'+escape(b.name)+'</strong><small>'+manager.teamRating(mode,b.id)+' OVR</small></div></div><p>'+escape(context.label)+' · '+(context.courtTeamId===a.id?'HOME COURT':'AT '+b.city.toUpperCase())+'</p><div class="career-actions">'+button('play','PLAY GAME →',true)+button('watch','WATCH GAME')+button('sim-game',busy?'SIMULATING…':'SIMULATE GAME')+'</div></div>';
  }
  function bracket(br,ourTeam) {
    const names=br.bestOf===3?['FIRST ROUND','CONF. SEMIFINALS','CONF. FINALS','FINALS']:br.rounds[0].length===8?['ROUND OF 16','QUARTERFINALS','SEMIFINALS','FINAL']:['QUARTERFINALS','SEMIFINALS','FINAL'];
    const total=Math.log2(br.rounds[0].length*2);
    return '<div class="bracket-scroll"><div class="career-bracket">'+Array.from({length:total},(_,round)=>{
      const matches=br.rounds[round]||[];
      return '<section class="bracket-round"><h4>'+names[round]+'</h4>'+ (matches.length?matches.map(m=>'<div class="bracket-game '+(m.a===ourTeam||m.b===ourTeam?'your-game':'')+'">'+[m.a,m.b].map((id,side)=>'<div class="bracket-team '+(m.winner===id?'winner':'')+'">'+logo(id,22)+'<span>'+escape(team(id).nickname)+(id===ourTeam?' <em>YOU</em>':'')+'</span><b>'+ (br.bestOf===3?side?m.winsB:m.winsA:m.games.length?side?m.games[0].b:m.games[0].a:'—')+'</b></div>').join('')+
        (m.games.length?'<button type="button" class="bracket-box" data-career="box" data-box="'+m.games[m.games.length-1].boxId+'">'+(br.bestOf===3?'SERIES '+m.winsA+'–'+m.winsB+' · ':'')+'BOX SCORE ↗</button>':'<small>UPCOMING</small>')+'</div>').join(''):'<div class="bracket-waiting">Winners advance here</div>')+'</section>';
    }).join('')+'</div></div>';
  }
  function tournament(t) {
    const br=t.bracket,context=manager.nextGame('tournament');
    return '<div class="career-identity">'+logo(t.teamId,44)+'<div><h3>'+escape(team(t.teamId).name)+'</h3><p>'+t.size+'-TEAM CUP · ROUND '+Math.min(br.round+1,Math.log2(t.size))+'</p></div>'+button('new','NEW TOURNAMENT')+'</div>'+
      (br.champion?'<div class="career-champion"><span>THE CHAMPIONS</span>'+logo(br.champion,70)+'<h3>'+escape(team(br.champion).name)+'</h3><p>'+(br.champion===t.teamId?'You brought the trophy home.':'A new champion is crowned. Run it back.')+'</p></div>':context?matchup(context):'<div class="career-empty"><h3>Knocked out. The cup continues.</h3><p>Finish the bracket to see who wins it all.</p>'+button('sim-stage','SIMULATE TO CHAMPION',true)+'</div>')+
      '<div class="career-section-heading"><h3>THE BRACKET</h3><span>Single elimination · Progress saved</span></div>'+bracket(br,t.teamId);
  }
  function playoffBracket(f) {
    const br=f.playoffs,seeds=br.seeds||Object.fromEntries(['west','east'].map(conf=>[conf,Object.fromEntries(manager.standings(conf).map((s,i)=>[s.teamId,i+1]))]));
    const seriesCard=(m,conf,final=false)=>{
      const pair=m?[m.a,m.b]:[null,null];
      return '<article class="series-card '+(m&&(m.a===f.teamId||m.b===f.teamId)?'your-series':'')+'">'+pair.map((id,i)=>{
        const t=id?team(id):null,score=m?(i?m.winsB:m.winsA):'—';
        return '<div class="series-team '+(m?.winner===id?'series-winner':'')+'"'+(t?' style="--team-color:'+t.primary+'"':'')+'>'+ (t?logo(id,25):'<span class="series-tbd">?</span>')+'<small>'+(id?(seeds[manager.conference(id)]?.[id]||''):'')+'</small><span>'+(t?escape(t.nickname):final?(i?'East champion':'West champion'):'To be decided')+'</span><b>'+score+'</b></div>';
      }).join('')+'<footer>'+(m?.games.length?m.games.map((g,i)=>'<button type="button" data-career="box" data-box="'+g.boxId+'" aria-label="'+escape(team(m.a).nickname+' vs '+team(m.b).nickname+' game '+(i+1)+' box score')+'">G'+(i+1)+' ↗</button>').join(''):'<span>AWAITING TIPOFF</span>')+(m?.winner?'<em>WINS '+m.winsA+'–'+m.winsB+'</em>':'')+'</footer></article>';
    };
    const half=conf=>{
      const titles=['FIRST ROUND','SEMIFINALS','CONF. FINALS'];
      const paths='<svg class="playoff-connectors" viewBox="0 0 510 560" preserveAspectRatio="none" aria-hidden="true"><path d="M158 70H170V140H176 M158 210H170V140 M158 350H170V420H176 M158 490H170V420 M334 140H342V280H352 M334 420H342V280"/></svg>';
      return '<section class="conference-tree '+conf+'" aria-label="'+conf+'ern conference playoff bracket">'+paths+[0,1,2].map(round=>{
        const matches=(br.rounds[round]||[]).filter(m=>manager.conference(m.a)===conf&&manager.conference(m.b)===conf);
        return '<div class="conference-round"><h5>'+titles[round]+'</h5><div class="conference-matchups">'+Array.from({length:4/2**round},(_,i)=>seriesCard(matches[i],conf)).join('')+'</div></div>';
      }).join('')+'</section>';
    };
    const final=br.rounds[3]?.[0],westFinal=(br.rounds[2]||[]).find(m=>manager.conference(m.a)==='west'),eastFinal=(br.rounds[2]||[]).find(m=>manager.conference(m.a)==='east');
    const finalCard=final?seriesCard(final,null,true):'<div class="finalists"><span>'+ (westFinal?.winner?logo(westFinal.winner,46)+escape(team(westFinal.winner).nickname):'WEST CHAMPION')+'</span><b>VS</b><span>'+(eastFinal?.winner?logo(eastFinal.winner,46)+escape(team(eastFinal.winner).nickname):'EAST CHAMPION')+'</span></div>';
    return '<section class="playoff-section"><div class="playoff-heading"><h3>THE PLAYOFFS</h3><span>SEASON '+f.year+' · BEST OF THREE · FIRST TO 2</span></div><p class="playoff-pan-note">West on the left. East on the right. Scroll sideways to explore the full bracket. Tap G1 / G2 / G3 for box scores.</p><div class="playoff-board-scroll" tabindex="0" aria-label="East and West playoff tree"><div class="playoff-board"><div class="conference-banner west-banner">WESTERN <small>CONFERENCE</small></div><div class="finals-banner">THE FINALS</div><div class="conference-banner east-banner">EASTERN <small>CONFERENCE</small></div>'+half('west')+'<section class="championship-column"><svg viewBox="0 0 80 100" class="championship-trophy" aria-hidden="true"><path d="M23 9h34v22c0 24-34 24-34 0z" fill="#ffc76b" stroke="#fff0b2" stroke-width="2"/><path d="M23 14H9v12q0 17 18 18 M57 14h14v12q0 17-18 18" fill="none" stroke="#d99b37" stroke-width="7"/><path d="M40 48v23 M24 80h32 M19 88h42" stroke="#f6bf56" stroke-width="8"/></svg><h4>CHAMPIONSHIP</h4>'+finalCard+(br.champion?'<div class="final-champion">'+logo(br.champion,53)+'<strong>'+escape(team(br.champion).name)+'</strong><small>CHAMPIONS</small></div>':'<p>Two conferences.<br>One champion.</p>')+'</section>'+half('east')+'</div></div></section>';
  }

  function franchise(f) {
    const record=f.standings[f.teamId],rank=manager.standings(manager.conference(f.teamId)).findIndex(s=>s.teamId===f.teamId)+1;
    const tabs=[['overview','OVERVIEW'],['standings','STANDINGS'],['roster','ROSTER'],['trades','TRADES'],['draft','DRAFT'],['history','GAME LOG']];
    return '<div class="career-identity">'+logo(f.teamId,48)+'<div><h3>'+escape(team(f.teamId).name)+'</h3><p>SEASON '+f.year+' · '+f.stage.toUpperCase()+' · '+record.w+'–'+record.l+'</p></div>'+button('new','NEW FRANCHISE')+'</div>'+
      '<div class="career-summary"><div><small>RECORD</small><strong>'+record.w+'–'+record.l+'</strong></div><div><small>CONFERENCE</small><strong>#'+rank+'</strong></div><div><small>STARTING FIVE</small><strong>'+manager.teamRating('franchise',f.teamId)+' <i>OVR</i></strong></div><div><small>CHAMPIONSHIPS</small><strong>'+f.titles+'</strong></div></div>'+
      '<nav class="career-tabs" aria-label="Franchise sections">'+tabs.map(([id,label])=>'<button type="button" data-career="tab" data-tab="'+id+'" class="'+(tab===id?'selected':'')+'" aria-pressed="'+(tab===id)+'">'+label+'</button>').join('')+'</nav>'+
      (tab==='overview'?overview(f):tab==='standings'?standings(f):tab==='roster'?roster(f):tab==='trades'?trades(f):tab==='draft'?draft(f):history(f));
  }
  function overview(f) {
    const context=manager.nextGame('franchise');
    let html=context?matchup(context):'';
    if(f.stage==='regular')html+='<div class="career-progress"><span>SEASON PROGRESS</span><b>'+f.round+' / 29 GAMES</b><i><em style="width:'+f.round/29*100+'%"></em></i></div><div class="career-actions">'+button('sim-stage',busy?'SIMULATING…':'SIMULATE TO PLAYOFFS')+'</div>';
    if(f.stage==='playoffs') {
      if(!context)html+='<div class="career-empty"><h3>Your season on the court is over.</h3><p>Follow the playoffs and prepare for the draft.</p>'+button('sim-stage','SIMULATE TO DRAFT',true)+'</div>';
      else html+='<div class="career-actions">'+button('sim-stage','SIMULATE PLAYOFFS')+'</div>';

    }
    if(['draft','offseason'].includes(f.stage))html+='<div class="career-champion"><span>SEASON '+f.year+' CHAMPIONS</span>'+logo(f.champion,64)+'<h3>'+escape(team(f.champion).name)+'</h3><p>'+(f.champion===f.teamId?'Another banner for your franchise.':'The next chapter starts with the draft.')+'</p>'+button(f.stage==='draft'?'draft-tab':'next-season',f.stage==='draft'?'GO TO THE DRAFT →':'START SEASON '+(f.year+1)+' →',true)+'</div>';
    if(f.playoffs)html+=playoffBracket(f);
    html+='<div class="career-section-heading"><h3>LEAGUE LEADERS</h3><span>Regular-season points per game</span></div><div class="career-leaders">'+(manager.leaders().map((entry,i)=>'<div><b>'+String(i+1).padStart(2,'0')+'</b><span>'+escape(entry.player.name)+'<small>'+entry.player.position+'</small></span><strong>'+entry.average.toFixed(1)+'<small>PPG</small></strong></div>').join('')||'<p class="career-small">Play or simulate a game to start the leaderboard.</p>')+'</div>';
    return html;
  }
  function standings(f) {
    return '<div class="career-actions">'+['east','west','all'].map(id=>'<button type="button" data-career="conference" data-conference="'+id+'" class="career-button '+(conference===id?'selected':'')+'">'+(id==='all'?'ALL TEAMS':id.toUpperCase())+'</button>').join('')+'</div><div class="career-table-scroll"><table class="career-table"><thead><tr><th>#</th><th>TEAM</th><th>W</th><th>L</th><th>PCT</th><th>PF</th><th>PA</th><th>DIFF</th></tr></thead><tbody>'+manager.standings(conference).map((s,i)=>'<tr class="'+(s.teamId===f.teamId?'your-team':'')+'"><td>'+(i+1)+'</td><th>'+logo(s.teamId,22)+escape(team(s.teamId).name)+'</th><td>'+s.w+'</td><td>'+s.l+'</td><td>'+(s.w+s.l?s.w/(s.w+s.l):0).toFixed(3)+'</td><td>'+s.pf+'</td><td>'+s.pa+'</td><td>'+(s.pf-s.pa>0?'+':'')+(s.pf-s.pa)+'</td></tr>').join('')+'</tbody></table></div><p class="career-small">Top eight in each conference qualify. Ties use point differential, then points scored.</p>';
  }
  function roster(f) {
    const ids=f.rosters[f.teamId],lineup=f.lineups[f.teamId];
    return '<div class="career-section-heading"><h3>YOUR STARTING FIVE</h3><span>One player per slot · Captain starts under your control</span></div><div class="lineup-editor">'+['PG','SG','SF','PF','C'].map((pos,i)=>'<label>'+pos+' SLOT<select id="career-lineup-'+i+'">'+playerOptions(ids,lineup[i])+'</select></label>').join('')+'<label>CAPTAIN<select id="career-captain">'+playerOptions(ids,f.captain)+'</select></label></div><div class="career-actions">'+button('save-lineup','SAVE LINEUP',true)+'</div><div class="career-table-scroll"><table class="career-table"><thead><tr><th>PLAYER</th><th>POS</th><th>HEIGHT</th><th>OVR</th><th>GP</th><th>PPG</th><th>RPG</th><th>APG</th><th>SPG</th><th>BPG</th></tr></thead><tbody>'+ids.map(id=>{
      const p=player(id),s=f.seasonStats[id]||{games:0};const avg=k=>s.games?((s[k]||0)/s.games).toFixed(1):'—';
      return '<tr><th>'+escape(p.name)+(lineup.includes(id)?'<small>STARTER</small>':'')+(p.fictional?'<small>FICTIONAL DRAFT PROSPECT</small>':'')+'</th><td>'+p.position+'</td><td>'+p.height+'</td><td>'+manager.overall(id)+'</td><td>'+s.games+'</td>'+['pts','reb','ast','stl','blk'].map(k=>'<td>'+avg(k)+'</td>').join('')+'</tr>';
    }).join('')+'</tbody></table></div>';
  }
  function trades(f) {
    if(tradeTeam===f.teamId)tradeTeam=manager.league.teams.find(t=>t.id!==f.teamId).id;
    const own=f.rosters[f.teamId],other=f.rosters[tradeTeam];
    if(!own.some(id=>String(id)===String(tradeOut)))tradeOut=own[0];
    if(!other.some(id=>String(id)===String(tradeIn)))tradeIn=other[0];
    const a=player(tradeOut),b=player(tradeIn);
    return '<div class="career-section-heading"><h3>TRADE DESK</h3><span>One-for-one offers · Player values use custom game ratings</span></div><div class="trade-grid"><section>'+logo(f.teamId,48)+'<h4>YOU OFFER</h4><label>YOUR PLAYER<select id="trade-out">'+playerOptions(own,tradeOut)+'</select></label><strong>'+manager.overall(tradeOut)+' <small>OVR</small></strong><p>'+escape(a.name)+' · '+a.position+' · '+a.height+'</p></section><section>'+logo(tradeTeam,48)+'<h4>YOU RECEIVE</h4><label>OTHER TEAM<select id="trade-team">'+teamOptions(tradeTeam,f.teamId)+'</select></label><label>THEIR PLAYER<select id="trade-in">'+playerOptions(other,tradeIn)+'</select></label><strong>'+manager.overall(tradeIn)+' <small>OVR</small></strong><p>'+escape(b.name)+' · '+b.position+' · '+b.height+'</p></section></div><p class="career-small">The other team accepts comparable or better value. An accepted offer exchanges the players and updates both starting lineups.</p>'+button('offer-trade','MAKE TRADE OFFER',true)+
      '<div class="career-section-heading"><h3>TRANSACTIONS</h3></div><div class="career-leaders">'+(f.transactions.slice(-8).reverse().map(t=>'<div><span>'+escape(player(t.in).name)+' IN<small>'+escape(player(t.out).name)+' to '+escape(team(t.other).name)+' · Season '+t.year+'</small></span></div>').join('')||'<p class="career-small">No trades yet.</p>')+'</div>';
  }
  function draft(f) {
    const d=f.draft;
    if(!d)return '<div class="career-empty"><h3>The next generation is coming.</h3><p>The draft opens after the playoffs. Each team gets one pick in reverse order of the regular-season standings.</p></div>';
    if(d.done) {
      const p=player(d.userPick);
      return '<div class="career-champion"><span>YOUR DRAFT PICK</span><h3>'+escape(p.name)+'</h3><p>'+p.position+' · '+p.height+' · '+manager.overall(p.id)+' OVR · '+p.potential+' POTENTIAL</p><p>A fictional rookie joins your roster. Set your lineup for the new season.</p>'+button('next-season','START SEASON '+(f.year+1)+' →',true)+'</div>';
    }
    return '<div class="career-section-heading"><h3>YOU ARE ON THE CLOCK</h3><span>PICK '+(d.cursor+1)+' OF 30</span></div><p class="career-small">Original fictional prospects, generated for this save. Potential is a game projection. Choose one player; the rest of the league drafts automatically.</p><div class="draft-grid">'+[...d.prospects].sort((a,b)=>manager.overall(b)-manager.overall(a)).map(id=>{
      const p=player(id);return '<article><span class="career-tag">'+p.position+' · '+p.height+'</span><h4>'+escape(p.name)+'</h4><div><strong>'+manager.overall(id)+'<small>OVR</small></strong><strong>'+p.potential+'<small>POTENTIAL</small></strong></div>'+button('draft-player','DRAFT PLAYER →',false).replace('data-career="draft-player"','data-career="draft-player" data-player="'+id+'"')+'</article>';
    }).join('')+'</div>';
  }
  function history(f) {
    const games=f.results.filter(g=>g.a===f.teamId||g.b===f.teamId).slice().reverse();
    return '<div class="career-section-heading"><h3>SEASON '+f.year+' GAME LOG</h3><span>Played and simulated results</span></div><div class="career-table-scroll"><table class="career-table"><thead><tr><th>GAME</th><th>OPPONENT</th><th>RESULT</th><th>SCORE</th><th>DETAILS</th></tr></thead><tbody>'+games.map(g=>{
      const us=g.a===f.teamId?g.scoreA:g.scoreB,them=g.a===f.teamId?g.scoreB:g.scoreA,opponent=g.a===f.teamId?g.b:g.a;
      return '<tr><td>'+g.stage.toUpperCase()+' '+(g.stage==='regular'?g.week:'')+'</td><th>'+logo(opponent,22)+escape(team(opponent).name)+'</th><td class="'+(us>them?'win':'loss')+'">'+(us>them?'W':'L')+'</td><td>'+us+'–'+them+'</td><td><button type="button" data-career="box" data-box="'+g.id+'" class="career-button">BOX SCORE ↗</button></td></tr>';
    }).join('')+'</tbody></table></div>'+(games.length?'':'<p class="career-small">Your first game is waiting.</p>')+
      '<div class="career-section-heading"><h3>FRANCHISE HISTORY</h3></div><div class="career-leaders">'+(f.history.map(s=>'<div><b>S'+s.year+'</b><span>'+s.w+'–'+s.l+'<small>Champion: '+escape(team(s.champion).name)+' · Drafted '+escape(player(s.pick).name)+'</small></span></div>').join('')||'<p class="career-small">Complete a season to start your history.</p>')+'</div>';
  }
  async function run(operation) {
    if(busy)return;busy=true;message='';error=false;render();
    await new Promise(resolve=>setTimeout(resolve,0));
    try {const result=operation();if(typeof result==='string')message=result;}
    catch(err){message=err.message;error=true;}
    busy=false;render();
  }
  body.addEventListener('click',event=>{
    const target=event.target.closest('[data-career]');if(!target||busy)return;
    const action=target.dataset.career;event.preventDefault();message='';error=false;
    if(action==='tab'){tab=target.dataset.tab;render();return;}
    if(action==='conference'){conference=target.dataset.conference;render();return;}
    if(action==='new'){creating=true;render();return;}
    if(action==='cancel-new'){creating=false;render();return;}
    if(action==='draft-tab'){tab='draft';render();return;}
    if(action==='box'){const box=manager.getBox(mode,target.dataset.box);if(box)hooks.openBox(box);return;}
    if(action==='play'||action==='watch'){const context=manager.nextGame(mode);if(context){dialog.close();hooks.playGame(context,action==='watch');}return;}
    if(action==='create') {
      const opts={quarters:Number($('career-quarters').value),duration:Number($('career-duration').value),difficulty:$('career-difficulty').value},teamId=$('career-team').value,size=mode==='tournament'?Number($('career-size').value):16;
      run(()=>{
      if(mode==='tournament')manager.newTournament(teamId,size,opts);
      else manager.newFranchise(teamId,opts);
      creating=false;tab='overview';return 'Your '+mode+' is ready. Progress saves automatically.';
      });
    }
    if(action==='sim-game')run(()=>{manager.simulateNext(mode);return 'Game complete. Results, standings and box scores saved.';});
    if(action==='sim-stage')run(()=>{manager.simulateToNextStage(mode);return 'Simulation complete. Your progress is saved.';});
    if(action==='save-lineup') {
      const ids=Array.from({length:5},(_,i)=>$('career-lineup-'+i).value),captain=$('career-captain').value;
      run(()=>{manager.setLineup(ids,captain);return 'Your starting five and captain are saved.';});
    }
    if(action==='offer-trade')run(()=>manager.trade(tradeTeam,tradeOut,tradeIn));
    if(action==='draft-player')run(()=>{const p=manager.draftPlayer(target.dataset.player);return p.name+' joins your franchise.';});
    if(action==='next-season')run(()=>{manager.nextSeason();tab='overview';return 'A new season begins. Your roster and franchise history carry forward.';});
  });
  body.addEventListener('change',event=>{
    if(event.target.id==='trade-team'){tradeTeam=event.target.value;tradeIn=null;render();}
    if(event.target.id==='trade-out'){tradeOut=event.target.value;render();}
    if(event.target.id==='trade-in'){tradeIn=event.target.value;render();}
  });
  function open(nextMode='tournament') {mode=nextMode;tab='overview';creating=false;message='';error=false;render();dialog.showModal();}
  function close() {dialog.close();hooks.onClose?.();}
  $('career-close').addEventListener('click',close);
  dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
  for(const name of ['tournament','franchise'])$('career-mode-'+name).addEventListener('click',()=>{mode=name;tab='overview';creating=false;message='';render();});
  return {open,close,render,get mode(){return mode;}};
}
