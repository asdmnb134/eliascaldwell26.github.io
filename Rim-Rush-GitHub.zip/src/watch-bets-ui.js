export function createWatchBetView(manager, hooks) {
  const $ = id => document.getElementById(id);
  const format = n => n.toLocaleString() + ' play credits';
  function render() {
    const available = hooks.available(), state = manager.state;
    $('watch-bet-panel').hidden = !available;
    $('watch-bank').textContent = format(state.balance);
    $('watch-bet-refill').hidden = state.balance >= 10 || Boolean(state.active);
    $('watch-bet-enable').disabled = state.balance < 10;
    const teams = hooks.teams();
    for (let side = 0; side < 2; side++) $('watch-pick-' + side).textContent = teams[side].name;
    const amount = Number($('watch-bet-amount').value);
    $('watch-bet-payout').textContent = Number.isSafeInteger(amount) && amount >= 10 ? 'WIN: ' + format(amount * 2) + ' total return · ' + format(amount) + ' profit' : 'Minimum wager: 10 play credits';
    $('watch-bet-details').hidden = !$('watch-bet-enable').checked;
    $('start-button').textContent = available ? $('watch-bet-enable').checked ? 'LOCK PICK & WATCH →' : 'WATCH GAME →' : 'HIT THE COURT →';
    $('watch-bet-history').textContent = state.history.slice(0, 4).map(item => item.teams[item.side].name + ' · ' + item.amount + ' · ' + item.outcome.toUpperCase() + (item.payout ? ' · +' + item.payout : '')).join('  /  ') || 'Your first pick starts here.';
    $('watch-bet-live').hidden = !state.active;
    if (state.active) $('watch-bet-live').textContent = 'PICK: ' + state.active.teams[state.active.side].id + ' · ' + state.active.amount + ' PLAY CREDITS · 2× RETURN';
    if (manager.warning) $('watch-bet-error').textContent = manager.warning;
  }
  function beforeStart() {
    $('watch-bet-result').hidden = true;$('watch-bet-error').textContent = '';
    try {
      if (manager.state.active) manager.finish('forfeit');
      if (hooks.available() && $('watch-bet-enable').checked) {
        manager.place({ id: 'watch_' + Date.now() + '_' + Math.random().toString(36).slice(2),
          side: Number($('watch-bet-side').value), amount: Number($('watch-bet-amount').value), teams: hooks.teams() });
        $('watch-bet-enable').checked = false;
      }
      render();return true;
    } catch (err) { $('watch-bet-error').textContent = err.message;render();return false; }
  }
  function finish(winner) {
    try {
      const result = manager.finish(winner);render();
      if (result) {
        $('watch-bet-result').hidden = false;
        $('watch-bet-result').textContent = result.outcome === 'won' ? 'PICK WON! +' + result.payout + ' play credits paid · Bank: ' + manager.state.balance : 'PICK LOST · ' + result.amount + ' play credits · Bank: ' + manager.state.balance;
      }
    } catch (err) { $('watch-bet-result').hidden = false;$('watch-bet-result').textContent = err.message; }
  }
  function abandon() {
    if (!manager.state.active) return;
    try { manager.finish('forfeit'); } catch (err) { $('watch-bet-error').textContent = err.message; }
    render();
  }
  $('watch-bet-enable').addEventListener('change', render);
  $('watch-bet-amount').addEventListener('input', render);
  $('watch-bet-refill').addEventListener('click', () => {
    try { manager.refill();$('watch-bet-error').textContent = '';render(); }
    catch (err) { $('watch-bet-error').textContent = err.message; }
  });
  render();return { render, beforeStart, finish, abandon };
}
