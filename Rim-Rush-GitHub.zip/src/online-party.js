// GitHub Pages serves static files; server features stay on the hosted edition.
export function createOnlineParty() {
  const $ = id => document.getElementById(id), dialog = $('party-dialog');
  function open() {
    $('party-entry').hidden = true;
    $('party-lobby').hidden = true;
    $('party-rank-panel').hidden = true;
    $('party-title').textContent = 'ONLINE NEEDS A SERVER';
    $('party-message').textContent = 'This GitHub Pages edition supports offline play, local two-player games, Watch Game, play-money picks, tournaments and franchise. Online multiplayer and ranked profiles require the server-hosted edition.';
    if (!dialog.open) dialog.showModal();
  }
  $('party-close').addEventListener('click', () => dialog.close());
  dialog.addEventListener('cancel', event => { event.preventDefault();dialog.close(); });
  const label = $('menu-online').querySelector('small');
  if (label) label.textContent = 'SERVER REQUIRED · VIEW DETAILS';
  return { open, input() {}, command() {}, tick() {}, leave() {}, finish() {}, rematch() {}, resetInputs() {}, render() {}, get room() { return null; }, get role() { return null; } };
}
