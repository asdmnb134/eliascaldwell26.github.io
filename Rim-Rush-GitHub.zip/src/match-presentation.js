// Replays are render-only pose recordings. They never rerun the simulation.
export function lateGameIntensity({scores,remaining,quarter,totalQuarters,quarterSeconds,overtime,mode}) {
  if(mode==='practice'||quarter<totalQuarters&&!overtime)return 0;
  const gap=Math.abs(scores[0]-scores[1]),window=Math.min(35,quarterSeconds*.5);
  if(gap>6||!overtime&&remaining>window)return 0;
  const urgency=overtime?1:.4+.6*(1-remaining/window);
  return urgency*(gap<=3?1:.7);
}
function pose(p,handBall) {
  const {box,lastPass,...look}=p;
  return {...look,previewBall:handBall?{...handBall(p)}:null,
    dunk:p.dunk?{...p.dunk,start:{...p.dunk.start},startBall:{...p.dunk.startBall},hoop:{...p.dunk.hoop}}:null};
}
function frame(data) {
  return {time:data.time,players:data.players.map(p=>pose(p,data.handBall)),ball:{...data.ball,shot:data.ball.shot?{...data.ball.shot}:null},scores:[...data.scores]};
}
export function createMatchPresentation() {
  let history=[],sampleClock=0,last=null,replay=null,bursts=[],hype=0,roarClock=0;
  function reset(){history=[];sampleClock=0;last=null;replay=null;bursts=[];hype=0;roarClock=0;}
  function capture(dt,read){sampleClock+=dt;if(sampleClock<1/30)return;sampleClock%=1/30;history.push(frame(read()));if(history.length>100)history.shift();}
  function basket(meta,data) {
    history.push(frame(data));last={meta:{...meta},frames:history.slice(-58)};
    bursts.push({x:meta.x,y:meta.y,points:meta.points,color:meta.color,age:0,delay:meta.effect==='nuke'||meta.effect==='meteor'?.62:.08,duration:2.7});
  }
  function newPossession(){history=[];sampleClock=0;}
  function beginReplay(){if(!last||last.frames.length<5)return false;replay={...last,age:0,duration:2.4};return true;}
  function stepReplay(dt){if(!replay)return true;replay.age+=dt;return replay.age>=replay.duration;}
  function endReplay(){replay=null;}
  function replayFrame() {
    if(!replay)return null;
    const position=Math.min(replay.frames.length-1,replay.age/replay.duration*(replay.frames.length-1));
    const index=Math.floor(position),a=replay.frames[index],b=replay.frames[Math.min(index+1,replay.frames.length-1)],t=position-index;
    const blend=(x,y)=>x+(y-x)*t;
    return {...a,players:a.players.map((p,i)=>({...p,x:blend(p.x,b.players[i].x),y:blend(p.y,b.players[i].y),z:blend(p.z,b.players[i].z),walk:blend(p.walk,b.players[i].walk)})),
      ball:{...a.ball,x:blend(a.ball.x,b.ball.x),y:blend(a.ball.y,b.ball.y),z:blend(a.ball.z,b.ball.z),spin:blend(a.ball.spin,b.ball.spin)}};
  }
  function step(dt,state) {
    for(const burst of bursts)burst.age+=dt;bursts=bursts.filter(b=>b.age<b.duration);
    const target=lateGameIntensity(state);hype+=(target-hype)*Math.min(1,dt*2.8);
    roarClock=Math.max(0,roarClock-dt);const roar=hype>.3&&roarClock===0;if(roar)roarClock=2.3;
    return roar;
  }
  return {reset,newPossession,capture,basket,beginReplay,stepReplay,endReplay,replayFrame,step,
    get last(){return last;},get replay(){return replay;},get bursts(){return bursts;},get hype(){return hype;}};
}
export function drawPointBursts(c,bursts,reducedMotion=false) {
  for(const burst of bursts) {
    const age=burst.age-burst.delay;if(age<0)continue;
    const count=reducedMotion?1:7;
    for(let i=0;i<count;i++) {
      const t=age-i*.13;if(t<0||t>1.7)continue;
      const spread=reducedMotion?0:(i%2?1:-1)*(10+(i%3)*12)*t;
      const x=burst.x+spread,y=burst.y-(reducedMotion?32:t*57)-4;
      c.save();c.globalAlpha=Math.min(1,(1.7-t)*1.5)*Math.min(1,t*9+.15);
      c.translate(x,y);const s=1+(reducedMotion?0:Math.sin(Math.min(1,t*3)*Math.PI)*.2);c.scale(s,s);
      c.textAlign='center';c.font='900 '+(i===0?25:18)+'px Arial';c.lineWidth=4;c.strokeStyle='#10243e';c.strokeText('+'+burst.points,0,0);
      c.fillStyle=i%2?'#fff7cf':burst.color||'#b5f69e';c.fillText('+'+burst.points,0,0);c.restore();
    }
  }
}
