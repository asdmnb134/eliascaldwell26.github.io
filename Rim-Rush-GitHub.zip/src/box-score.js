export function createBoxScoreView(hooks) {
  const $=id=>document.getElementById(id),dialog=$('box-score-dialog');
  let current=null,side=0,resume=false;
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const minute=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
  const percent=(made,attempted)=>attempted?(made/attempted*100).toFixed(1):'—';
  function line(p,total=false) {
    const s=p.stats,number=v=>Math.round(v||0),pair=(a,b)=>number(s[a])+'–'+number(s[b]);
    return '<tr class="'+(total?'box-total':s.seconds?'':'box-dnp')+'"><th scope="row">'+
      (total?'TEAM TOTAL':escape(p.name)+'<small>'+escape(p.position)+' · #'+escape(p.number)+(p.starter?' · STARTER':'')+'</small>')+'</th>'+
      '<td>'+(s.seconds?minute(s.seconds):total?'0:00':'DNP')+'</td><td class="box-points">'+number(s.pts)+'</td>'+
      ['reb','oreb','dreb','ast','stl','blk','tov'].map(k=>'<td>'+number(s[k])+'</td>').join('')+
      '<td>'+pair('fgm','fga')+'</td><td>'+percent(s.fgm,s.fga)+'</td><td>'+pair('tpm','tpa')+'</td><td>'+percent(s.tpm,s.tpa)+'</td>'+
      '<td>'+pair('ftm','fta')+'</td><td>'+percent(s.ftm,s.fta)+'</td><td>'+number(s.pf)+'</td><td>'+(s.plusMinus>0?'+':'')+number(s.plusMinus)+'</td></tr>';
  }
  function render() {
    if(!current)return;
    $('box-score-state').textContent=(current.final?'FINAL':'LIVE')+(current.overtime?' / OT':'')+' · '+current.label;
    for(let n=0;n<2;n++) {
      const t=current.teams[n],team=hooks.team(t.teamId),button=$('box-team-'+n);
      button.textContent=team.name+' '+t.score;button.classList.toggle('selected',n===side);button.setAttribute('aria-pressed',String(n===side));
    }
    const periods=current.quarterScores;
    $('box-score-periods').innerHTML=periods?.length?'<table><thead><tr><th>PERIOD</th>'+periods.map(p=>'<th>'+escape(p.label)+'</th>').join('')+'<th>TOTAL</th></tr></thead><tbody>'+current.teams.map((t,i)=>'<tr><th>'+escape(hooks.team(t.teamId).id)+'</th>'+periods.map(p=>'<td>'+p.scores[i]+'</td>').join('')+'<td>'+t.score+'</td></tr>').join('')+'</tbody></table>':'';
    const team=current.teams[side],totals={};
    for(const p of team.players)for(const [k,v]of Object.entries(p.stats))totals[k]=(totals[k]||0)+v;
    $('box-score-body').innerHTML=team.players.map(p=>line(p)).join('');
    $('box-score-total').innerHTML=line({stats:totals},true);
    const mvp=current.teams.flatMap(t=>t.players).filter(p=>p.stats.seconds>0||p.stats.pts>0).sort((a,b)=>value(b.stats)-value(a.stats))[0];
    $('box-score-mvp').textContent=mvp?'GAME MVP · '+mvp.name+' · '+mvp.stats.pts+' PTS / '+mvp.stats.reb+' REB / '+mvp.stats.ast+' AST':'Play to build the box score.';
    $('box-score-note').textContent=current.simulated?'Simulated regulation is 48 minutes. DNP means the player did not enter this game.':'Arcade match statistics. No foul calls or free throws in played games; those columns stay zero. Minutes count live game time.';
  }
  function value(s) {return s.pts+s.reb*1.2+s.ast*1.5+s.stl*2+s.blk*2-s.tov-(s.fga-s.fgm)*.35;}
  function open(data=null) {
    current=data||hooks.live();side=0;resume=hooks.isPlaying();
    if(resume)hooks.pause();render();dialog.showModal();
  }
  function close() {dialog.close();if(resume){resume=false;hooks.resume();}}
  $('box-score-close').addEventListener('click',close);
  dialog.addEventListener('cancel',e=>{e.preventDefault();close();});
  for(let n=0;n<2;n++)$('box-team-'+n).addEventListener('click',()=>{side=n;render();});
  return {open,close,render,get current(){return current;}};
}
