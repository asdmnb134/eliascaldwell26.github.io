// Persistent, browser-local competition state. Simulations use the same player skill profiles.
export const BOX_FIELDS = ['seconds','pts','reb','oreb','dreb','ast','stl','blk','tov','fgm','fga','tpm','tpa','ftm','fta','pf','plusMinus'];
export function emptyBoxStats() {
  return Object.fromEntries(BOX_FIELDS.map(key=>[key,0]));
}
export function createCareerManager(league,storage) {
  const SAVE_KEY='rimrush-careers-v1';
  const teamMap=new Map(league.teams.map(t=>[t.id,t]));
  const east=new Set(['ATL','BOS','BKN','CHA','CHI','CLE','DET','IND','MIA','MIL','NYK','ORL','PHI','TOR','WAS']);
  let warning='',state={version:1,seed:730217,tournament:null,franchise:null};
  try {
    const saved=JSON.parse(storage.getItem(SAVE_KEY)||'null');
    if(saved?.version===1&&Number.isFinite(saved.seed))state=saved;
  }catch {warning='Your saved competitions could not be read. You can start a new run.';}
  function random() {
    state.seed=(Math.imul(state.seed,1664525)+1013904223)>>>0;
    return state.seed/4294967296;
  }
  function save() {
    try {storage.setItem(SAVE_KEY,JSON.stringify(state));warning='';return true;}
    catch {warning='Progress is available this session, but browser storage could not save it.';return false;}
  }
  function player(id) {
    const base=state.franchise?.extraPlayers?.[id]||league.players[id];
    if(!base)throw Error('Unknown player.');
    const developed=state.franchise?.development?.[id];
    return developed?{...base,ratings:developed}:base;
  }
  function overall(id) {
    const p=player(id),r=p.ratings;
    const weights=p.position==='C'?[.04,.24,.22,.04,.04,.04,.2,.18]:p.position==='PG'?[.2,.18,.02,.18,.16,.12,.04,.1]:[.19,.22,.09,.11,.1,.11,.08,.1];
    return Math.round(10+18*Object.values(r).reduce((n,v,i)=>n+v*weights[i],0));
  }
  function initialRosters() {return Object.fromEntries(league.teams.map(t=>[t.id,[...t.roster]]));}
  function initialLineups() {return Object.fromEntries(league.teams.map(t=>[t.id,[...t.starters]]));}
  function lineup(mode,teamId) {
    const source=mode==='franchise'?state.franchise?.lineups[teamId]:null;
    const ids=[...(source||teamMap.get(teamId).starters)];
    if(mode==='franchise'&&teamId===state.franchise?.teamId&&ids.includes(state.franchise.captain)) {
      return [state.franchise.captain,...ids.filter(id=>id!==state.franchise.captain)];
    }
    return ids;
  }
  function roster(mode,teamId) {return [...(mode==='franchise'?state.franchise.rosters[teamId]:teamMap.get(teamId).roster)];}
  function teamRating(mode,teamId) {return Math.round(lineup(mode,teamId).reduce((n,id)=>n+overall(id),0)/5);}
  function options(input={}) {
    return {quarters:Number(input.quarters)===4?4:1,duration:[30,60,90,180,360,720].includes(Number(input.duration))?Number(input.duration):60,
      difficulty:['easy','normal','pro','hard'].includes(input.difficulty)?input.difficulty:'normal'};
  }
  function assertTeam(id) {if(!teamMap.has(id))throw Error('Choose a valid team.');}
  function choose(rows,weight) {
    let target=random()*rows.reduce((n,p)=>n+Math.max(.01,weight(p)),0);
    for(const row of rows){target-=Math.max(.01,weight(row));if(target<=0)return row;}
    return rows[rows.length-1];
  }
  function simulateBox(mode,a,b,label='Simulated game') {
    const teams=[a,b].map(teamId=>{
      const start=lineup(mode,teamId),pool=roster(mode,teamId);
      const rotation=[...start,...pool.filter(id=>!start.includes(id)).slice(0,5)];
      return {teamId,score:0,players:pool.map(id=>({...player(id),stats:emptyBoxStats(),starter:start.includes(id)})),rotation};
    });
    const rotations=teams.map(t=>t.rotation.map(id=>t.players.find(p=>p.id===id)));
    const usage=(p,key)=>((p.starter?2:1)*(p.ratings[key]||3));
    function possession(side) {
      const us=teams[side],them=teams[1-side],off=rotations[side],def=rotations[1-side];
      const shooter=choose(off,p=>usage(p,'finish')+usage(p,'three')*.9),s=shooter.stats;
      if(random()<.11){s.tov++;if(random()<.67)choose(def,p=>usage(p,'defense')).stats.stl++;return;}
      for(let attempt=0;attempt<3;attempt++) {
        const three=random()<.1+shooter.ratings.three*.077;
        if(!three&&random()<.1) {
          choose(def,p=>usage(p,'defense')).stats.pf++;
          for(let ft=0;ft<2;ft++){s.fta++;if(random()<.49+shooter.ratings.finish*.075){s.ftm++;s.pts++;us.score++;}}
          return;
        }
        s.fga++;if(three)s.tpa++;
        const edge=(teamRating(mode,us.teamId)-teamRating(mode,them.teamId))*.0015;
        const chance=(three?.13+shooter.ratings.three*.065:.34+shooter.ratings.finish*.06)+edge;
        const blocker=choose(def,p=>usage(p,'block'));
        const blocked=random()<(three?.008:.012)*blocker.ratings.block;
        if(blocked)blocker.stats.blk++;
        if(!blocked&&random()<chance) {
          const points=three?3:2;s.fgm++;if(three)s.tpm++;s.pts+=points;us.score+=points;
          if(random()<.65)choose(off.filter(p=>p!==shooter),p=>usage(p,'pass')).stats.ast++;
          return;
        }
        const offensive=random()<.23,reb=choose(offensive?off:def,p=>usage(p,'rebound'));
        reb.stats.reb++;reb.stats[offensive?'oreb':'dreb']++;
        if(!offensive)return;
      }
    }
    const possessions=88+Math.floor(random()*15);
    for(let n=0;n<possessions;n++){possession(0);possession(1);}
    let duration=2880,overtime=false;
    while(teams[0].score===teams[1].score) {
      overtime=true;duration+=300;
      for(let n=0;n<8;n++){possession(0);possession(1);}
    }
    for(let side=0;side<2;side++) {
      const list=rotations[side],weights=list.map(p=>p.starter?2:1),sum=weights.reduce((n,v)=>n+v,0);
      let assigned=0,plus=0;const difference=teams[side].score-teams[1-side].score;
      list.forEach((p,i)=>{
        p.stats.seconds=i===list.length-1?duration*5-assigned:Math.round(duration*5*weights[i]/sum);
        assigned+=p.stats.seconds;
        p.stats.plusMinus=i===list.length-1?difference*5-plus:Math.round(difference*p.stats.seconds/duration);
        plus+=p.stats.plusMinus;
      });
    }
    return {label,final:true,simulated:true,duration,overtime,teams};
  }
  function packBox(box,id) {
    return {id,label:box.label,final:true,simulated:!!box.simulated,duration:box.duration,overtime:!!box.overtime,quarters:box.quarters||1,quarterScores:box.quarterScores||null,
      teams:box.teams.map(t=>({teamId:t.teamId,score:t.score,
        rows:t.players.map(p=>[p.id,p.starter?1:0,...BOX_FIELDS.map(k=>Math.round((p.stats?.[k]||0)*100)/100)])}))};
  }
  function unpackBox(box) {
    if(!box)return null;
    return {...box,teams:box.teams.map(t=>({...t,players:t.rows.map(row=>({...player(row[0]),starter:!!row[1],stats:Object.fromEntries(BOX_FIELDS.map((k,i)=>[k,row[i+2]||0]))}))}))};
  }
  function getBox(mode,id) {return unpackBox(state[mode]?.boxes?.[id]);}
  function newBracket(teamIds,prefix,bestOf=1) {
    return {round:0,bestOf,champion:null,rounds:[Array.from({length:teamIds.length/2},(_,i)=>({id:prefix+'-r0-'+i,a:teamIds[i*2],b:teamIds[i*2+1],winsA:0,winsB:0,winner:null,games:[]}))]};
  }
  function advanceBracket(bracket) {
    const round=bracket.rounds[bracket.round];
    if(!round.every(m=>m.winner))return;
    if(round.length===1){bracket.champion=round[0].winner;return;}
    const next=round.map(m=>m.winner);bracket.round++;
    bracket.rounds.push(Array.from({length:next.length/2},(_,i)=>({id:round[0].id.split('-r')[0]+'-r'+bracket.round+'-'+i,
      a:next[i*2],b:next[i*2+1],winsA:0,winsB:0,winner:null,games:[]})));
  }
  function seriesResult(series,box) {
    const a=box.teams.find(t=>t.teamId===series.a),b=box.teams.find(t=>t.teamId===series.b);
    if(!a||!b||a.score===b.score)throw Error('A completed game needs a winner and both scheduled teams.');
    series[a.score>b.score?'winsA':'winsB']++;
    series.games.push({a:a.score,b:b.score,boxId:box.id});
  }
  function newTournament(teamId,size=16,input={}) {
    assertTeam(teamId);size=Number(size)===8?8:16;
    const other=league.teams.map(t=>t.id).filter(id=>id!==teamId);
    for(let i=other.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[other[i],other[j]]=[other[j],other[i]];}
    const entrants=[teamId,...other.slice(0,size-1)];
    state.tournament={teamId,size,options:options(input),bracket:newBracket(entrants,'cup'),boxes:{},results:[],played:[],status:'active'};
    save();return state.tournament;
  }
  function recordTournament(series,box) {
    const t=state.tournament;const id='cup-'+t.results.length;
    const saved=packBox(box,id);t.boxes[id]=saved;seriesResult(series,{...box,id});
    series.winner=series.winsA>series.winsB?series.a:series.b;
    t.results.push({id,a:series.a,b:series.b,scoreA:series.games[0].a,scoreB:series.games[0].b});
  }
  function settleTournamentRound() {
    const t=state.tournament,br=t.bracket;
    for(const m of br.rounds[br.round])if(!m.winner)recordTournament(m,simulateBox('tournament',m.a,m.b,'Tournament / round '+(br.round+1)));
    advanceBracket(br);
    t.status=br.champion?'complete':br.rounds[br.round].some(m=>m.a===t.teamId||m.b===t.teamId)?'active':'eliminated';
  }
  function roundRobin() {
    const ids=league.teams.map(t=>t.id),rounds=[];
    for(let round=0;round<ids.length-1;round++) {
      const games=[];
      for(let i=0;i<ids.length/2;i++) {
        const pair=[ids[i],ids[ids.length-1-i]];if((round+i)%2)pair.reverse();
        games.push({id:'week-'+round+'-'+i,home:pair[0],away:pair[1],result:null});
      }
      rounds.push(games);ids.splice(1,0,ids.pop());
    }
    return rounds;
  }
  function freshStandings() {return Object.fromEntries(league.teams.map(t=>[t.id,{teamId:t.id,w:0,l:0,pf:0,pa:0}]));}
  function newFranchise(teamId,input={}) {
    assertTeam(teamId);
    state.franchise={teamId,year:1,options:options(input),stage:'regular',round:0,rosters:initialRosters(),lineups:initialLineups(),
      captain:teamMap.get(teamId).starters[0],standings:freshStandings(),schedule:roundRobin(),boxes:{},results:[],played:[],seasonStats:{},playoffStats:{},
      playoffs:null,extraPlayers:{},development:{},draft:null,champion:null,titles:0,history:[],transactions:[]};
    save();return state.franchise;
  }
  function standings(conference='all') {
    const f=state.franchise;if(!f)return [];
    return Object.values(f.standings).filter(s=>conference==='all'||(east.has(s.teamId)?'east':'west')===conference)
      .sort((a,b)=>b.w-a.w||(b.pf-b.pa)-(a.pf-a.pa)||b.pf-a.pf||a.teamId.localeCompare(b.teamId));
  }
  function accumulate(box,playoffs=false) {
    const f=state.franchise,target=playoffs?f.playoffStats:f.seasonStats;
    for(const team of box.teams)for(const p of team.players) {
      if(!p.stats.seconds)continue;
      const stats=target[p.id]||(target[p.id]={...emptyBoxStats(),games:0});stats.games++;
      for(const key of BOX_FIELDS)stats[key]+=p.stats[key]||0;
    }
  }
  function recordFranchise(box,fixture=null,series=null) {
    const f=state.franchise,id='s'+f.year+'-g'+f.results.length,saved=packBox(box,id);
    f.boxes[id]=saved;accumulate(box,!!series);
    const a=box.teams[0],b=box.teams[1];
    f.results.push({id,a:a.teamId,b:b.teamId,scoreA:a.score,scoreB:b.score,stage:f.stage,week:f.round+1});
    if(fixture) {
      const home=box.teams.find(t=>t.teamId===fixture.home),away=box.teams.find(t=>t.teamId===fixture.away);
      fixture.result={home:home.score,away:away.score,boxId:id};
      for(const [us,them]of[[home,away],[away,home]]) {
        const record=f.standings[us.teamId];record[us.score>them.score?'w':'l']++;record.pf+=us.score;record.pa+=them.score;
      }
    }
    if(series) {
      seriesResult(series,{...box,id});
      if(series.winsA>=2||series.winsB>=2)series.winner=series.winsA>series.winsB?series.a:series.b;
    }
  }
  function beginPlayoffs() {
    const order=[0,7,3,4,1,6,2,5],field=[];
    for(const conference of ['east','west']) {
      const seeds=standings(conference).slice(0,8);field.push(...order.map(i=>seeds[i].teamId));
    }
    const f=state.franchise;f.playoffs=newBracket(field,'s'+f.year+'-playoffs',3);
    f.playoffs.seeds=Object.fromEntries(['east','west'].map(conf=>[conf,Object.fromEntries(standings(conf).slice(0,8).map((s,i)=>[s.teamId,i+1]))]));
    f.stage='playoffs';
  }
  function settleRegularRound() {
    const f=state.franchise;
    for(const game of f.schedule[f.round])if(!game.result)recordFranchise(simulateBox('franchise',game.home,game.away,'Season '+f.year+' / game '+(f.round+1)),game);
    f.round++;
    if(f.round>=f.schedule.length)beginPlayoffs();
  }
  function settlePlayoffDay() {
    const f=state.franchise,br=f.playoffs;
    for(const series of br.rounds[br.round])if(!series.winner)recordFranchise(simulateBox('franchise',series.a,series.b,'Season '+f.year+' / playoffs'),null,series);
    advanceBracket(br);
    if(br.champion)finishSeason();
  }
  function finishSeason() {
    const f=state.franchise;f.champion=f.playoffs.champion;
    if(f.champion===f.teamId)f.titles++;
    f.stage='draft';generateDraft();
  }
  function nextGame(mode) {
    const data=state[mode];if(!data)return null;
    let opponent,matchId,courtTeamId,label;
    if(mode==='tournament') {
      if(data.status!=='active')return null;
      const m=data.bracket.rounds[data.bracket.round].find(m=>!m.winner&&(m.a===data.teamId||m.b===data.teamId));
      if(!m)return null;
      opponent=m.a===data.teamId?m.b:m.a;matchId=m.id;courtTeamId=m.a;label='TOURNAMENT / ROUND '+(data.bracket.round+1);
    } else if(data.stage==='regular') {
      const game=data.schedule[data.round].find(g=>g.home===data.teamId||g.away===data.teamId);
      if(game.result)return null;
      opponent=game.home===data.teamId?game.away:game.home;matchId=game.id;courtTeamId=game.home;label='SEASON '+data.year+' / GAME '+(data.round+1)+' OF 29';
    } else if(data.stage==='playoffs') {
      const m=data.playoffs.rounds[data.playoffs.round].find(m=>!m.winner&&(m.a===data.teamId||m.b===data.teamId));
      if(!m)return null;
      opponent=m.a===data.teamId?m.b:m.a;matchId=m.id+'-game'+m.games.length;courtTeamId=m.games.length%2?m.b:m.a;label='SEASON '+data.year+' / PLAYOFFS / GAME '+(m.games.length+1);
    } else return null;
    return {mode,key:mode+'-'+(data.year||1)+'-'+matchId,teamId:data.teamId,opponentId:opponent,courtTeamId,label,
      teams:[data.teamId,opponent],lineups:[lineup(mode,data.teamId),lineup(mode,opponent)],
      rosters:[roster(mode,data.teamId),roster(mode,opponent)],options:{...data.options}};
  }
  function submit(context,box) {
    const data=state[context.mode];if(!data)throw Error('This competition is no longer available.');
    if(data.played.includes(context.key))return false;
    const expected=nextGame(context.mode);
    if(!expected||expected.key!==context.key)throw Error('This game no longer matches the competition schedule.');
    if(!box.final||box.teams.length!==2||box.teams[0].score===box.teams[1].score||!context.teams.every(id=>box.teams.some(t=>t.teamId===id)))throw Error('Finish the scheduled game before recording a result.');
    data.played.push(context.key);
    if(context.mode==='tournament') {
      const series=data.bracket.rounds[data.bracket.round].find(m=>m.a===data.teamId||m.b===data.teamId);
      recordTournament(series,box);settleTournamentRound();
    } else if(data.stage==='regular') {
      const game=data.schedule[data.round].find(g=>g.home===data.teamId||g.away===data.teamId);
      recordFranchise(box,game);settleRegularRound();
    } else {
      const series=data.playoffs.rounds[data.playoffs.round].find(m=>!m.winner&&(m.a===data.teamId||m.b===data.teamId));
      recordFranchise(box,null,series);
      for(const other of data.playoffs.rounds[data.playoffs.round])if(other!==series&&!other.winner)recordFranchise(simulateBox('franchise',other.a,other.b,'Playoffs'),null,other);
      if(series.winner) {
        const currentRound=data.playoffs.round;
        while(data.stage==='playoffs'&&data.playoffs.round===currentRound&&!data.playoffs.rounds[currentRound].every(m=>m.winner))settlePlayoffDay();
        if(data.stage==='playoffs'&&data.playoffs.round===currentRound){advanceBracket(data.playoffs);if(data.playoffs.champion)finishSeason();}
      }
    }
    save();return true;
  }
  function simulateNext(mode) {
    const context=nextGame(mode);if(!context)throw Error('There is no scheduled game for your team.');
    const box=simulateBox(mode,context.teamId,context.opponentId,context.label);submit(context,box);return box;
  }
  function simulateToNextStage(mode) {
    if(mode==='tournament') {
      const t=state.tournament;if(!t)throw Error('Create a tournament first.');
      while(!t.bracket.champion)settleTournamentRound();save();return;
    }
    const f=state.franchise;if(!f)throw Error('Create a franchise first.');
    const stage=f.stage;
    if(stage==='regular')while(f.stage==='regular')simulateNext('franchise');
    else if(stage==='playoffs')while(f.stage==='playoffs') {
      if(nextGame('franchise'))simulateNext('franchise');else settlePlayoffDay();
    }
    save();
  }
  function setLineup(ids,captain) {
    const f=state.franchise;
    if(!f||ids.length!==5||new Set(ids.map(String)).size!==5||!ids.every(id=>f.rosters[f.teamId].some(n=>String(n)===String(id))))throw Error('Choose five different players from your roster.');
    const normalized=ids.map(id=>f.rosters[f.teamId].find(n=>String(n)===String(id)));
    if(!normalized.some(id=>String(id)===String(captain)))throw Error('Your captain must be in the starting five.');
    f.lineups[f.teamId]=normalized;f.captain=normalized.find(id=>String(id)===String(captain));save();
  }
  function trade(otherId,outId,inId) {
    const f=state.franchise;if(!f)throw Error('Create a franchise first.');assertTeam(otherId);
    if(otherId===f.teamId||!f.rosters[f.teamId].some(id=>String(id)===String(outId))||!f.rosters[otherId].some(id=>String(id)===String(inId)))throw Error('Choose one of your players and one player on another team.');
    const outgoing=f.rosters[f.teamId].find(id=>String(id)===String(outId)),incoming=f.rosters[otherId].find(id=>String(id)===String(inId));
    if(overall(outgoing)+2<overall(incoming))throw Error('Offer rejected. The other team wants a player closer in value.');
    for(const [teamId,remove,add]of[[f.teamId,outgoing,incoming],[otherId,incoming,outgoing]]) {
      f.rosters[teamId]=f.rosters[teamId].map(id=>id===remove?add:id);
      f.lineups[teamId]=f.lineups[teamId].map(id=>id===remove?add:id);
    }
    if(f.captain===outgoing)f.captain=incoming;
    f.transactions.push({type:'trade',year:f.year,out:outgoing,in:incoming,other:otherId});save();
    return player(incoming).name+' joins '+teamMap.get(f.teamId).nickname+'.';
  }
  function generateDraft() {
    const f=state.franchise,first=['Malik','Andre','Cameron','Isaiah','Darius','Julian','Marcus','Jalen','Elias','Devin'],last=['Reed','Monroe','Bennett','Cole','Brooks','Grant','Warren','Ellis','Lawson','Carter'];
    const prospects=[];
    for(let i=0;i<30;i++) {
      const position=['PG','SG','SF','PF','C'][i%5],height=[73,77,80,82,85][i%5]+Math.floor(random()*4)-1;
      const base=2.5+random(),ratings={three:base,finish:base+.3,block:position==='C'?base+.5:base-.7,
        handles:position==='PG'?base+.6:base-.2,pass:position==='PG'?base+.5:base-.2,speed:position==='C'?base-.5:base+.2,rebound:position==='C'?base+.6:base-.3,defense:base};
      for(const key of Object.keys(ratings))ratings[key]=Math.max(1,Math.min(4.5,Math.round(ratings[key]*2)/2));
      const name=first[(i+f.year)%10]+' '+last[(Math.floor(i/10)+i*3+f.year)%10]+' '+(i>=20?'Jr.':'');
      const profile={id:'rookie-'+f.year+'-'+i,name:name.trim(),shortName:name[0]+'. '+name.split(' ')[1],position,heightIn:height,
        height:Math.floor(height/12)+"'"+height%12+'"',number:String(1+i),team:'DRAFT',ratings,
        skin:['#d7a476','#aa6d49','#82543e','#edc3a1','#704c38'][i%5],hair:'#272329',hairstyle:['fade','crop','curls','braids'][i%4],beard:i%4===0,
        potential:84+Math.floor(random()*15),fictional:true};
      f.extraPlayers[profile.id]=profile;prospects.push(profile.id);
    }
    f.draft={order:standings().map(s=>s.teamId).reverse(),prospects,selected:[],cursor:0,done:false,userPick:null};
    autoDraftToUser();
  }
  function draftSelection(id) {
    const f=state.franchise,d=f.draft,teamId=d.order[d.cursor];
    f.rosters[teamId].push(id);d.selected.push({teamId,id,pick:d.cursor+1});d.prospects=d.prospects.filter(n=>n!==id);d.cursor++;
    if(teamId===f.teamId)d.userPick=id;
    if(d.cursor>=d.order.length){d.done=true;f.stage='offseason';}
  }
  function autoDraftToUser() {
    const f=state.franchise,d=f.draft;
    while(!d.done&&d.order[d.cursor]!==f.teamId) {
      const best=[...d.prospects].sort((a,b)=>overall(b)-overall(a)||player(b).potential-player(a).potential)[0];draftSelection(best);
    }
  }
  function draftPlayer(id) {
    const f=state.franchise,d=f?.draft;
    if(!d||d.done||d.order[d.cursor]!==f.teamId||!d.prospects.includes(id))throw Error('Choose an available prospect when your team is on the clock.');
    draftSelection(id);autoDraftToUser();save();return player(id);
  }
  function nextSeason() {
    const f=state.franchise;if(!f||f.stage!=='offseason'||!f.draft?.done)throw Error('Complete your draft before starting the next season.');
    f.history.push({year:f.year,w:f.standings[f.teamId].w,l:f.standings[f.teamId].l,champion:f.champion,pick:f.draft.userPick});
    for(const pick of f.draft.selected) {
      const p=player(pick.id),r={...p.ratings};r[p.position==='C'?'finish':'three']=Math.min(5,r[p.position==='C'?'finish':'three']+.5);f.development[p.id]=r;
    }
    f.year++;f.stage='regular';f.round=0;f.standings=freshStandings();f.schedule=roundRobin();f.boxes={};f.results=[];f.played=[];
    f.seasonStats={};f.playoffStats={};f.playoffs=null;f.draft=null;f.champion=null;save();return f;
  }
  function leaders(key='pts') {
    return Object.entries(state.franchise?.seasonStats||{}).filter(([,s])=>s.games>0)
      .map(([id,s])=>({player:player(id),stats:s,average:s[key]/s.games})).sort((a,b)=>b.average-a.average).slice(0,5);
  }
  return {get state(){return state;},get warning(){return warning;},league,team:id=>teamMap.get(id),player,overall,lineup,roster,teamRating,
    newTournament,newFranchise,nextGame,submit,simulateNext,simulateToNextStage,standings,setLineup,trade,draftPlayer,nextSeason,getBox,leaders,
    conference:id=>east.has(id)?'east':'west',save};
}
