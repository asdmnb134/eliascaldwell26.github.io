// Cosmetic effects are deterministic canvas drawings. They never touch match state.
export const SHOT_EFFECTS = [
  {id:'fireworks',name:'Sky Rockets',price:0,tier:'STARTER',color:'#ffc451',description:'A stadium-wide bouquet of sparkling fireworks.'},
  {id:'nuke',name:'Nuclear Splash',price:600,tier:'LEGENDARY',color:'#ff9842',description:'A cartoon bomb drops into the net. Mushroom cloud. Shockwave. Buckets.'},
  {id:'ufo',name:'Close Encounter',price:600,tier:'LEGENDARY',color:'#9afb93',description:'A flying saucer beams up the rim, then warps away.'},
  {id:'lightning',name:'Thunder God',price:250,tier:'EPIC',color:'#8edcff',description:'Three electric bolts strike the basket with arcing sparks.'},
  {id:'meteor',name:'Extinction Event',price:400,tier:'EPIC',color:'#ff7255',description:'A blazing meteor crashes into the hoop and scatters molten fragments.'},
  {id:'dragon',name:'Dragon Breath',price:650,tier:'LEGENDARY',color:'#ffbf57',description:'A winged dragon sweeps past and breathes a stream of fire.'},
  {id:'ice',name:'Absolute Zero',price:200,tier:'RARE',color:'#a2efff',description:'Ice crystals freeze around the rim, then shatter into snow.'},
  {id:'blackhole',name:'Event Horizon',price:500,tier:'LEGENDARY',color:'#bc9bff',description:'The net disappears into a spinning cosmic vortex.'},
  {id:'solar',name:'Solar Flare',price:350,tier:'EPIC',color:'#ffdd68',description:'A miniature sun erupts over the hoop with curling solar rays.'},
  {id:'wave',name:'Splash Warning',price:250,tier:'RARE',color:'#62dbff',description:'A curling tidal wave sweeps across the basket and sprays the crowd.'},
  {id:'volcano',name:'Lava League',price:350,tier:'EPIC',color:'#ff6a40',description:'A volcano rises under the hoop and launches a fountain of lava.'},
  {id:'portal',name:'Neon Dimension',price:300,tier:'EPIC',color:'#ef8aff',description:'Electric portals open around the rim and fold into one another.'},
  {id:'glitch',name:'System Override',price:200,tier:'RARE',color:'#7ffff0',description:'The basket breaks into RGB scanlines and a giant digital +3.'},
  {id:'money',name:'Cash Money',price:150,tier:'RARE',color:'#8bf4a2',description:'Bills spiral out of the net in a green money shower.'},
  {id:'crown',name:'Royal Range',price:200,tier:'RARE',color:'#ffe080',description:'A jeweled gold crown descends on the hoop with a ring of stars.'},
  {id:'ghost',name:'Haunted Hoop',price:250,tier:'EPIC',color:'#c5bcff',description:'Friendly ghosts orbit the basket before vanishing into the net.'},
  {id:'butterfly',name:'Butterfly Effect',price:100,tier:'RARE',color:'#ffb0dd',description:'A kaleidoscope of animated butterflies bursts from the rim.'},
  {id:'rocket',name:'Liftoff',price:300,tier:'EPIC',color:'#b4dcff',description:'A rocket launches out of the net and leaves a glowing smoke trail.'},
  {id:'quake',name:'Court Breaker',price:300,tier:'EPIC',color:'#e1bb83',description:'A giant slam cracks the court with rising rocks and dust.'},
  {id:'rainbow',name:'Prism Splash',price:150,tier:'RARE',color:'#b9c9ff',description:'A luminous rainbow sweeps over the basket and dissolves into stars.'},
  {id:'mecha',name:'Hoop Titan',price:800,tier:'MYTHIC',color:'#89d9ff',description:'A towering armored robot lands, winds up a giant fist and detonates the rim with a reactor pulse.'},
  {id:'kraken',name:'Deep Court',price:700,tier:'MYTHIC',color:'#78eccb',description:'Ocean tentacles coil around the basket before a giant surge of water erupts from the net.'},
  {id:'phoenix',name:'Phoenix Rising',price:750,tier:'MYTHIC',color:'#ffc078',description:'A blazing phoenix spreads enormous wings above the hoop and showers the court in embers.'},
  {id:'cometstorm',name:'Starfall Barrage',price:650,tier:'LEGENDARY',color:'#ff9cce',description:'Five colored comets rain into the rim, each impact releasing a new shockwave.'},
  {id:'disco',name:'Disco Dome',price:450,tier:'EPIC',color:'#d6a2ff',description:'A mirrored disco ball drops over the basket with sweeping spotlights and glittering confetti.'},
  {id:'train',name:'Midnight Express',price:650,tier:'LEGENDARY',color:'#c7e2f4',description:'A steam locomotive roars across the hoop, blowing clouds of smoke and leaving golden sparks.'},
  {id:'samurai',name:'Blade of Buckets',price:550,tier:'LEGENDARY',color:'#ff8d9d',description:'Two enormous glowing blade slashes cross through the basket and explode into cherry blossoms.'},
  {id:'tornado',name:'Twister',price:550,tier:'LEGENDARY',color:'#9be5ed',description:'A spiraling funnel sweeps up the net, loose stones and glowing basketballs before bursting apart.'},
  {id:'supernova',name:'Galactic Finale',price:900,tier:'MYTHIC',color:'#c2adff',description:'A collapsing star ignites a giant multicolored supernova with orbiting planets and expanding rings.'},
  {id:'scorezilla',name:'Rimzilla',price:1000,tier:'MYTHIC',color:'#b5f27e',description:'A colossal court monster rises behind the net and fires an energy beam into a booming rim explosion.'}
];
export const EFFECT_DURATION = 2.65;
const TAU=Math.PI*2;
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const seed=n=>{const v=Math.sin(n*127.1+311.7)*43758.5453;return v-Math.floor(v);};
function circle(c,x,y,r,color){if(r<=0)return;c.fillStyle=color;c.beginPath();c.arc(x,y,r,0,TAU);c.fill();}
function ellipse(c,x,y,rx,ry,color){if(rx<=0||ry<=0)return;c.fillStyle=color;c.beginPath();c.ellipse(x,y,rx,ry,0,0,TAU);c.fill();}
function line(c,points,color,width=2){c.strokeStyle=color;c.lineWidth=width;c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.stroke();}
function glow(c,x,y,r,color){const g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'#00000000');circle(c,x,y,r,g);}
function star(c,x,y,r,color,turn=0){c.save();c.translate(x,y);c.rotate(turn);c.fillStyle=color;c.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4,s=i%2?r*.3:r;c.lineTo(Math.cos(a)*s,Math.sin(a)*s);}c.closePath();c.fill();c.restore();}
function ring(c,x,y,r,color,width=3,flat=1){if(r<=0)return;c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.ellipse(x,y,r,r*flat,0,0,TAU);c.stroke();}
function particles(c,t,color,count=38,speed=90,gravity=40){for(let i=0;i<count;i++){const a=seed(i+5)*TAU,v=speed*(.4+seed(i+20)),r=2+seed(i+40)*3;circle(c,Math.cos(a)*v*t,Math.sin(a)*v*t+gravity*t*t,r*Math.max(0,1-t*.55),i%3?color:'#fff4cc');}}
export function drawShotEffect(c,id,time,options={}) {
  if(time<0||time>EFFECT_DURATION||!SHOT_EFFECTS.some(e=>e.id===id))return;
  const age=clamp(time/EFFECT_DURATION),color=SHOT_EFFECTS.find(e=>e.id===id).color;
  c.save();c.translate(options.x??0,options.y??0);c.scale(options.scale||1.4,options.scale||1.4);
  c.globalAlpha=clamp(age/.07)*clamp((1-age)/.18);c.lineCap='round';c.lineJoin='round';
  if(options.reducedMotion){glow(c,0,0,65,color+'99');ring(c,0,0,38,color,3,.55);star(c,0,-25,14,color);c.restore();return;}
  const hit=Math.max(0,(time-.68)),pulse=Math.sin(Math.PI*clamp(hit/1.8));
  switch(id) {
    case 'mecha': {
      const drop=Math.max(0,1-time/.45)*-190,charge=Math.max(0,Math.sin(Math.PI*clamp((time-.4)/1.8)));
      c.save();c.translate(0,drop);glow(c,0,-55,110,'#66d6ff55');
      for(const side of [-1,1]){line(c,[[side*20,-45],[side*30,-16],[side*34,5]],'#375b83',18);line(c,[[side*27,-95],[side*(45+charge*16),-77],[side*(27+charge*9),-36]],'#84afcf',20);circle(c,side*28,-36,13,'#bbdff0');circle(c,side*34,5,10,'#647c9b');}
      c.fillStyle='#6b96b8';c.fillRect(-30,-105,60,62);c.fillStyle='#abcadd';c.fillRect(-22,-101,44,12);circle(c,0,-74,13,'#244268');glow(c,0,-74,18,'#83f6ff');
      c.fillStyle='#7ea6c5';c.fillRect(-18,-137,36,30);c.fillStyle='#bffbff';c.fillRect(-12,-128,24,5);c.restore();
      if(hit>0){ring(c,0,4,hit*112,'#a7edff',5,.38);particles(c,hit,'#9cefff',48,115);}break;
    }
    case 'kraken': {
      glow(c,0,-20,112,'#3de6c950');
      for(let i=0;i<6;i++){const side=i%2?1:-1,reach=35+(i>>1)*28,flex=Math.sin(time*4+i)*22;c.strokeStyle=i%2?'#39a795':'#74d8bd';c.lineWidth=13-i*.8;c.beginPath();c.moveTo(side*15,18);c.bezierCurveTo(side*reach,-5,side*(reach+40),-80-flex,side*(reach-12),-122+flex);c.stroke();for(let j=0;j<5;j++)circle(c,side*(reach-5+j*2),-25-j*16+flex*.3,2.5,'#d1fbd8');}
      ring(c,0,13,55+Math.sin(time*5)*14,'#b1f8f0',4,.25);for(let i=0;i<32;i++){const t=(time+seed(i))%1.3;circle(c,(seed(i+9)-.5)*170*t,-110*t+90*t*t,2+seed(i)*3,'#b0fbff');}break;
    }
    case 'phoenix': {
      const flap=Math.sin(time*7)*15,rise=-35-Math.sin(age*Math.PI)*45;
      glow(c,0,rise,135,'#ffb84e66');
      for(const side of [-1,1])for(let feather=0;feather<8;feather++){
        const span=35+feather*12;c.fillStyle=feather%2?'#ffab42':'#ffe18a';c.beginPath();c.moveTo(side*8,rise);c.quadraticCurveTo(side*span,rise-75-flap,side*(span+10),rise-20+feather*8);c.quadraticCurveTo(side*35,rise+15,side*8,rise+12);c.fill();
      }
      ellipse(c,0,rise,10,27,'#fff0ad');circle(c,0,rise-31,9,'#ffe7a0');star(c,0,rise-32,5,'#ff9648',time);
      for(let i=0;i<35;i++){const a=i*2.4;star(c,Math.cos(a)*(20+age*115),rise+30+age*90+Math.sin(a)*20,2+seed(i)*3,'#ffd88a',time+i);}break;
    }
    case 'cometstorm': {
      for(let i=0;i<5;i++){const t=time-i*.19,arrival=.68,local=Math.max(0,t-arrival),p=clamp(t/arrival);if(t<0)continue;
        const x=(i-2)*62*(1-p),y=-185*(1-p),colors=['#ff93c5','#a5ddff','#ffe09b','#c2b1ff','#9cf1dc'];
        if(p<1){line(c,[[x+(i-2)*18,y-45],[x,y]],colors[i]+'88',14);star(c,x,y,12,colors[i],time);}
        if(local>0){ring(c,0,0,local*100,colors[i],3,.5);for(let k=0;k<9;k++){const a=k*TAU/9;circle(c,Math.cos(a)*local*85,Math.sin(a)*local*55,3,colors[i]);}}
      }break;
    }
    case 'disco': {
      const y=-115+Math.max(0,.35-time)*-120;line(c,[[0,-200],[0,y]],'#c2d4ee',2);circle(c,0,y,30,'#9faed3');
      for(let row=-3;row<=3;row++)for(let col=-3;col<=3;col++)if(row*row+col*col<10){c.fillStyle=['#a4efff','#f8c4ff','#fff4ce'][Math.abs(row+col+Math.floor(time*4))%3];c.fillRect(col*7-2,y+row*7-2,5,5);}
      for(let i=0;i<6;i++){const a=time*.8+i*TAU/6;c.fillStyle=['#ad97ff22','#ffb0df33','#8ee6ff22'][i%3];c.beginPath();c.moveTo(0,y);c.lineTo(Math.cos(a)*160-18,35);c.lineTo(Math.cos(a)*160+18,35);c.fill();}
      for(let i=0;i<55;i++)star(c,(seed(i)-.5)*260,-140+(time*55+seed(i+70)*170)%180,2,['#c7a9ff','#ffe3b1','#98e5ee'][i%3],time);break;
    }
    case 'train': {
      const x=-180+age*360;c.save();c.translate(x,-12);c.fillStyle='#31475e';c.fillRect(-83,-40,122,39);c.fillStyle='#7297af';c.fillRect(-75,-37,26,23);c.fillStyle='#e8c786';c.fillRect(-70,-33,16,13);c.fillStyle='#20394e';c.fillRect(-25,-65,14,32);c.fillRect(24,-29,24,25);
      for(let i=0;i<5;i++){circle(c,-68+i*24,0,10,'#7ca1b8');ring(c,-68+i*24,0,7,'#1b334a',2);line(c,[[-68+i*24,0],[-68+i*24+Math.cos(time*12)*7,Math.sin(time*12)*7]],'#e0dfcf',2);}
      line(c,[[-72,-1],[27,-1]],'#f0c486',3);for(let i=0;i<10;i++){const t=(time+i*.12)%1.3;circle(c,-18-t*45,-70-t*50,8+t*18,'#d3e4ed66');}c.restore();particles(c,hit,'#ffcc80',20,95);break;
    }
    case 'samurai': {
      for(let slash=0;slash<2;slash++){const t=clamp((time-.2-slash*.26)/.38);if(t<=0)continue;c.save();c.rotate(slash?-.65:.7);glow(c,0,-50,110,'#ff899433');line(c,[[-110,-50],[110*t,-50]],'#ffb1bc',14);line(c,[[-110,-50],[110*t,-50]],'#fff7e3',3);c.restore();}
      for(let i=0;i<42;i++){const t=(time*.5+seed(i))%1;c.save();c.translate(Math.sin(i*4+t*4)*125,-140+t*180);c.rotate(time*2+i);ellipse(c,0,0,3,7,i%2?'#ffc9da':'#ff8dac');c.restore();}ring(c,0,0,hit*85,'#ffd6db',2,.45);break;
    }
    case 'tornado': {
      for(let i=0;i<14;i++){const y=-i*10,r=12+i*5,x=Math.sin(time*9+i*.6)*7;ring(c,x,y,r,i%2?'#9ae7ecaa':'#d1f7f277',3,.22);}
      for(let i=0;i<25;i++){const a=time*7+i*2.7,r=25+seed(i)*60,y=-seed(i+8)*145;circle(c,Math.cos(a)*r,y+Math.sin(a)*10,2+seed(i+9)*3,i%3?'#e3e4d7':'#ffba6d');}
      glow(c,0,-60,90,'#8be6ff33');break;
    }
    case 'supernova': {
      const collapse=1-clamp(time/.55),blast=Math.max(0,time-.55);glow(c,0,-45,35+blast*95,'#b9a0ff88');
      circle(c,0,-45,5+collapse*25,'#fff0c2');for(let i=0;i<5;i++){c.save();c.translate(0,-45);c.rotate(i*.55+time*.3);ring(c,0,0,18+blast*(50+i*13),['#ffa7d4','#b4b4ff','#8ceaff','#ffdb95','#b9f4d6'][i],3,.45);c.restore();}
      for(let i=0;i<44;i++){const a=i*2.4,r=(collapse>0?collapse:blast)*120;star(c,Math.cos(a)*r,Math.sin(a)*r*.8-45,2+seed(i)*3,'#e9d2ff',time+i);}break;
    }
    case 'scorezilla': {
      const lift=clamp(time/.55);c.save();c.translate(-36,25-lift*25);c.scale(lift,lift);c.fillStyle='#355f55';c.beginPath();c.moveTo(-28,5);c.lineTo(-34,-55);c.lineTo(-15,-105);c.lineTo(-25,-140);c.lineTo(0,-158);c.lineTo(22,-143);c.lineTo(19,-112);c.lineTo(44,-60);c.lineTo(37,5);c.closePath();c.fill();
      for(let i=0;i<7;i++){c.fillStyle='#b6e785';c.beginPath();c.moveTo(-27,-30-i*13);c.lineTo(-48,-35-i*14);c.lineTo(-27,-45-i*13);c.fill();}circle(c,8,-139,3,'#ffe78d');line(c,[[-18,-59],[-40,-40],[-48,-53]],'#608570',12);line(c,[[20,-70],[43,-51],[52,-66]],'#608570',12);line(c,[[-24,-8],[-76,15],[-108,3]],'#446f5b',12);c.restore();
      if(time>.65&&time<2.1){line(c,[[-14,-117],[0,0]],'#a7f69988',20);line(c,[[-14,-117],[0,0]],'#edffc9',6);glow(c,0,0,100,'#b6ff8555');particles(c,hit,'#bdff94',35,90);}break;
    }
    case 'nuke': {
      if(time<.72){c.save();c.translate(Math.sin(time*10)*3,-160*(1-time/.72));c.rotate(.1);ellipse(c,0,-8,11,22,'#526676');circle(c,-3,-14,5,'#a9b9be');c.fillStyle='#ffcd51';c.fillRect(-8,4,16,8);c.fillStyle='#213349';c.fillRect(-14,-34,8,13);c.fillRect(6,-34,8,13);c.restore();}
      if(hit>0){glow(c,0,0,90+hit*45,'#ffac44bb');ring(c,0,3,hit*105,'#ffe0a0',4,.38);for(let i=0;i<7;i++)ellipse(c,Math.sin(i*2)*9,-hit*20-i*9,12+hit*7,12,'#d88e47');for(let i=0;i<9;i++){const x=(i-4)*10;circle(c,x,-45-hit*24,14+Math.sin(hit*3+i)*3,i%2?'#ffb44e':'#ffd875');}particles(c,hit,'#ff9b3b',32,65);}
      break;
    }
    case 'ufo': {
      const y=-83-Math.sin(age*Math.PI)*14,x=age>.77?(age-.77)*650:Math.sin(time*3)*9;
      c.save();c.translate(x,y);c.fillStyle='#9bffb438';c.beginPath();c.moveTo(-18,9);c.lineTo(-47,95);c.lineTo(47,95);c.lineTo(18,9);c.closePath();c.fill();ellipse(c,0,-5,19,14,'#7ee9cf');ellipse(c,0,3,41,10,'#4c6588');ellipse(c,0,0,40,7,'#afc5d7');for(let i=0;i<6;i++)circle(c,-29+i*12,5,2,i%2?'#b6ff8a':'#fff2aa');c.restore();for(let i=0;i<10;i++)star(c,Math.sin(i*4)*30,-(time*43+i*17)%90,3,'#b6ffb9',time);ring(c,0,-hit*15,23,'#aaffc2',2,.4);break;
    }
    case 'lightning': {
      glow(c,0,0,100,'#53cfff55');for(let k=0;k<3;k++){const points=[];for(let i=0;i<8;i++)points.push([(i===7?0:Math.sin(i*17+k+Math.floor(time*16))*16)+(k-1)*(7-i)*6,-150+i*21]);line(c,points,'#a4ddff',7);line(c,points,'#fff8d4',2);}ring(c,0,0,hit*65,'#90e6ff',2,.45);particles(c,hit,'#a1ecff',28,65);break;
    }
    case 'meteor': {
      const p=clamp(time/.75),x=-145*(1-p),y=-145*(1-p);if(p<1){line(c,[[x-70,y-65],[x,y]],'#ff753c77',25);line(c,[[x-52,y-50],[x,y]],'#ffe38b',10);circle(c,x,y,16,'#9c4438');circle(c,x-4,y-5,8,'#ffc463');}if(hit>0){glow(c,0,0,100,'#ff773c99');particles(c,hit,'#e6653c',42,100);ring(c,0,0,hit*90,'#ffbc73',4,.4);}break;
    }
    case 'dragon': {
      const x=-120+time*80,y=-95+Math.sin(time*4)*6,flap=Math.sin(time*12)*16;
      c.save();c.translate(x,y);c.fillStyle='#713e91';c.beginPath();c.moveTo(-8,0);c.lineTo(-55,-28-flap);c.lineTo(-39,3);c.lineTo(-10,11);c.lineTo(25,-29-flap);c.lineTo(21,6);c.closePath();c.fill();ellipse(c,0,6,20,9,'#9c679c');line(c,[[-14,8],[-37,16],[-53,5]],'#d293b5',5);circle(c,22,3,10,'#ae77a8');circle(c,25,0,2,'#ffe882');c.restore();if(time>.4&&time<2.1){const d=clamp((time-.4)/.5);for(let i=0;i<16;i++){const f=i/15;circle(c,x+30+(0-x-30)*f,y+6+(0-y)*f,(4+f*16)*d,i%3?'#ffab3f':'#ffe88a');}glow(c,0,0,70,'#ff8e4655');}break;
    }
    case 'ice': {
      for(let i=0;i<9;i++){const a=i*TAU/9,r=20+i%3*5;c.save();c.rotate(a);c.fillStyle=i%2?'#b6edff':'#64bee8';c.beginPath();c.moveTo(-5,0);c.lineTo(0,-r-Math.sin(age*Math.PI)*50);c.lineTo(6,0);c.closePath();c.fill();c.restore();}ring(c,0,0,42,'#e0fbff',2,.5);for(let i=0;i<25;i++)star(c,(seed(i)-.5)*120,(seed(i+50)*160+time*38)%155-120,3,'#dcfbff',i);break;
    }
    case 'blackhole': {
      glow(c,0,-20,100,'#9c6bff66');for(let i=0;i<9;i++){c.save();c.rotate(time*2+i*.4);ring(c,0,-20,18+i*5,i%2?'#caafff':'#815fc9',2,.38);c.restore();}circle(c,0,-20,24,'#070b19');for(let i=0;i<25;i++){const a=i*3+time*3,r=105*(1-(age+seed(i))%1);star(c,Math.cos(a)*r,Math.sin(a)*r*.6-20,2,'#e5c6ff');}break;
    }
    case 'solar': {
      glow(c,0,-35,115,'#ffb52688');circle(c,0,-35,29+Math.sin(time*12)*3,'#ffb833');circle(c,-7,-42,17,'#ffe77d');for(let i=0;i<12;i++){const a=i*TAU/12+time*.7;line(c,[[Math.cos(a)*40,Math.sin(a)*40-35],[Math.cos(a+.15)*70,Math.sin(a+.15)*70-35]],i%2?'#fff29b':'#ff9b42',4);}ring(c,0,-35,55+hit*27,'#ffce63',2);break;
    }
    case 'wave': {
      c.save();c.translate(-100+age*185,0);c.fillStyle='#309cdda0';c.beginPath();c.moveTo(-80,25);c.bezierCurveTo(-40,-100,80,-110,42,-35);c.bezierCurveTo(30,-6,-8,-30,5,-45);c.bezierCurveTo(-20,-20,-10,20,80,25);c.closePath();c.fill();line(c,[[-73,8],[-44,-40],[-8,-64],[27,-58],[40,-39],[20,-25],[7,-35]],'#bff9ff',5);for(let i=0;i<20;i++)circle(c,seed(i)*140-70,seed(i+30)*-95+time*13,2,'#c4f8ff');c.restore();break;
    }
    case 'volcano': {
      c.fillStyle='#653e3a';c.beginPath();c.moveTo(-65,25);c.lineTo(-14,-30*pulse);c.lineTo(14,-30*pulse);c.lineTo(65,25);c.closePath();c.fill();line(c,[[-15,-25*pulse],[0,18],[15,-25*pulse]],'#ff9a3f',4);for(let i=0;i<22;i++){const t=(time+seed(i)*1.3)%1.3;circle(c,(seed(i+30)-.5)*70*t,-150*t+100*t*t-20,2+seed(i+50)*4,i%2?'#ff8343':'#ffd573');}glow(c,0,-20,70,'#ff6b3155');break;
    }
    case 'portal': {
      for(let i=0;i<3;i++){c.save();c.translate((i-1)*23,-28-i*12);c.rotate(Math.sin(time*2+i)*.6);ring(c,0,0,43+Math.sin(time*4+i)*8,i%2?'#7ef6ff':'#ed89ff',5,.55);ring(c,0,0,37,'#fff1ff',1,.55);c.restore();}for(let i=0;i<24;i++)star(c,Math.sin(i*2+time*4)*65,Math.cos(i*2+time*4)*35-30,2,color);break;
    }
    case 'glitch': {
      for(let i=0;i<18;i++){const x=(seed(i+Math.floor(time*12))-.5)*150,y=seed(i+32)*100-80;c.fillStyle=['#76ffe7aa','#fd7ae2aa','#fff1a6aa'][i%3];c.fillRect(x,y,10+seed(i)*40,2+seed(i+9)*7);}c.font='900 60px monospace';c.textAlign='center';c.fillStyle='#ff67c9';c.fillText('+'+(options.points||3),4,-15);c.fillStyle='#74ffe2';c.fillText('+'+(options.points||3),-3,-18);c.fillStyle='#fffce4';c.fillText('+'+(options.points||3),0,-17);break;
    }
    case 'money': {
      for(let i=0;i<26;i++){const t=(time*.6+seed(i))%1;c.save();c.translate(Math.sin(i*4+t*6)*75,-130+t*165);c.rotate(Math.sin(time*3+i)*.8);c.fillStyle='#65b77c';c.fillRect(-11,-5,22,11);c.strokeStyle='#b7f7ae';c.lineWidth=1;c.strokeRect(-9,-3,18,7);ellipse(c,0,0,3,4,'#caf3b2');c.restore();}break;
    }
    case 'crown': {
      c.save();c.translate(0,-45-Math.sin(age*Math.PI)*20);c.fillStyle='#d69635';c.beginPath();c.moveTo(-34,0);c.lineTo(-42,-36);c.lineTo(-16,-18);c.lineTo(0,-46);c.lineTo(17,-18);c.lineTo(42,-36);c.lineTo(34,0);c.closePath();c.fill();line(c,[[-34,-2],[34,-2]],'#ffe69b',8);for(const x of [-24,0,24])circle(c,x,-9,3,x?'#ed7b77':'#7bdce5');c.restore();for(let i=0;i<10;i++){const a=i*TAU/10+time;star(c,Math.cos(a)*62,Math.sin(a)*40-45,4,'#ffe699',time);}break;
    }
    case 'ghost': {
      for(let i=0;i<4;i++){const a=i*TAU/4+time*2,x=Math.cos(a)*55,y=-35+Math.sin(a)*30;c.save();c.translate(x,y);c.fillStyle=['#d9ceff','#b5f7e2','#f3dafd','#d2efff'][i];c.beginPath();c.arc(0,-8,12,Math.PI,TAU);c.lineTo(12,14);for(let j=0;j<4;j++)c.lineTo(6-j*6,j%2?14:7);c.closePath();c.fill();circle(c,-4,-5,2,'#26334d');circle(c,4,-5,2,'#26334d');c.restore();}break;
    }
    case 'butterfly': {
      for(let i=0;i<17;i++){const a=i*2.4,r=age*100+seed(i)*12,x=Math.cos(a)*r,y=Math.sin(a)*r*.6-20-age*35,wing=3+Math.abs(Math.sin(time*13+i))*6;c.save();c.translate(x,y);c.rotate(Math.sin(time+i)*.4);ellipse(c,-wing/2,-3,wing/2,7,['#ff9dcf','#d0a5ff','#85e4ed'][i%3]);ellipse(c,wing/2,-3,wing/2,7,['#ffc4df','#e0bbff','#b7f2f8'][i%3]);line(c,[[0,-7],[0,5]],'#494263',1);c.restore();}break;
    }
    case 'rocket': {
      const lift=Math.max(0,time-.5)*105,y=18-lift;for(let i=0;i<15;i++)circle(c,(seed(i)-.5)*(20+lift*.25),y+28+i*5,7+i*.35,'#c7d4da55');c.save();c.translate(0,y);ellipse(c,0,-15,12,26,'#e9f4f5');c.fillStyle='#eb8056';c.beginPath();c.moveTo(-10,0);c.lineTo(-22,14);c.lineTo(-10,-20);c.lineTo(10,-20);c.lineTo(22,14);c.lineTo(10,0);c.closePath();c.fill();circle(c,0,-20,5,'#659bc7');c.fillStyle='#ffd477';c.beginPath();c.moveTo(-6,12);c.lineTo(0,35+Math.sin(time*40)*6);c.lineTo(6,12);c.fill();c.restore();break;
    }
    case 'quake': {
      ring(c,0,9,age*130,'#e8c399',3,.3);for(let i=0;i<8;i++){const a=i*TAU/8,len=age*95;line(c,[[0,12],[Math.cos(a)*len*.45,12+Math.sin(a)*len*.2],[Math.cos(a+.1)*len*.7,12+Math.sin(a+.1)*len*.32],[Math.cos(a)*len,12+Math.sin(a)*len*.45]],'#533e3a',4);}for(let i=0;i<15;i++){const t=hit,v=(seed(i)-.5)*130;circle(c,v*t,-80*t+65*t*t,3+seed(i+10)*6,i%2?'#b69272':'#dec4a2');}break;
    }
    case 'rainbow': {
      const colors=['#ff7584','#ffb05c','#ffe481','#98e6a5','#83d9ef','#b29df9'];for(let i=0;i<6;i++){c.strokeStyle=colors[i];c.lineWidth=5;c.beginPath();c.arc(0,8,39+i*6,Math.PI,TAU);c.stroke();}for(let i=0;i<26;i++){const a=i*2.4+age,r=45+age*40;star(c,Math.cos(a)*r,Math.sin(a)*r-20,3,colors[i%6],time);}break;
    }
    case 'fireworks': {
      for(let k=0;k<5;k++){const local=Math.max(0,time-k*.18),burst=local%1.5,originX=(k-2)*36,originY=-45-(k%2)*45;c.save();c.translate(originX,originY);for(let i=0;i<16;i++){const a=i*TAU/16,r=burst*45;line(c,[[Math.cos(a)*r*.65,Math.sin(a)*r*.65],[Math.cos(a)*r,Math.sin(a)*r+burst*burst*12]],[color,'#ff8d9e','#83dcff','#b9fa9b'][k%4],2);}c.restore();}break;
    }
  }
  c.restore();
}
