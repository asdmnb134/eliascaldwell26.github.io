import { LEAGUE } from './league-data.js';
import { createCareerManager, emptyBoxStats, BOX_FIELDS } from './career-engine.js';
import { createCareerView } from './career-ui.js';
import { createBoxScoreView } from './box-score.js';
import { SHOT_EFFECTS, EFFECT_DURATION, drawShotEffect } from './shot-effects.js';
import { createAnimationShop, createAnimationShopView } from './animation-shop.js';
import { createMatchPresentation, drawPointBursts, lateGameIntensity } from './match-presentation.js';
import { chooseOffense, offensiveSpot, defensiveAssignment, steerAroundPlayers } from './ai-coach.js';
import { playerShotChance, zoneBaseRate } from './shot-probability.js';
import { ZONE_NAMES } from './shooting-data.js';
import { createOnlineParty } from './online-party.js';
import { createWatchBets } from './watch-bets.js';
import { createWatchBetView } from './watch-bets-ui.js';

const $ = id => document.getElementById(id);
const canvas = $('court');
const ctx = canvas.getContext('2d');
ctx.imageSmoothingEnabled = false;
const W = 960, H = 540;
const careerManager=createCareerManager(LEAGUE,localStorage);
const animationShop=createAnimationShop(localStorage);
const watchBets=createWatchBets(localStorage);
let watchBetView=null;
let animationShopView=null,shotEffect=null,lobbyScreen='home',matchRewarded=false;
let onlineParty=null,onlineMatch=null,onlineSetup=null,applyingOnlineInput=false,applyingOnlineCommand=false;
let networkSequence=-1,networkInputSequence=-1,networkReceivedAt=0,networkReplayFrame=null,networkBursts=[],networkHype=0;
const presentation=createMatchPresentation();
let currentQuarter=1,totalQuarters=1,quarterSeconds=60,quarterLines=[],periodStartScores=[0,0];
let inboundState=null,quarterBreak=null,pendingAutoReplay=false,replayReturnPhase=null,possessionPasses=[0,0];
let careerMatch=null,quickSetup=null,matchLiveSeconds=0,careerView=null,boxScoreView=null,lastBoxScore=null;
try {lastBoxScore=JSON.parse(localStorage.getItem('rimrush-last-box-v1')||'null');}catch{}
const COURT = { left: 92, right: 900, top: 98, bottom: 478, cx: 496, cy: 288 };
const HOOPS = [{ x: 122, y: 288, z: 80 }, { x: 870, y: 288, z: 80 }];
const BALL_G = 330;

const PLAYER_SCALE = 1.65;
const BALL_RADIUS = 6.2;
const SHOT_TARGET_END = .96;
const SHOT_CHARGE_RATE = 1.85;
const PLAYER_G = 1050;
const SHOT_JUMP_SPEED = 180;
const BLOCK_JUMP_SPEED = 225;
const BLOCK_INPUT_BUFFER = .42;
const PASS_INTERCEPTION_CHANCE = .05;
const CLOSE_BLOCK_RANGE = 40;
const BLOCK_RELEASE_TRAVEL = 43;
const BLOCK_RELEASE_TIME = .24;
const DIFFICULTIES = {
  easy: { name: 'Rookie', half: .14, cpuGreen: .22, steal: .085, stealCooldown: 2.8, speed: .72, reaction: 1.15 },
  normal: { name: 'Pro', half: .095, cpuGreen: .34, steal: .13, stealCooldown: 2.35, speed: .81, reaction: .95 },
  pro: { name: 'All-Star', half: .065, cpuGreen: .46, steal: .18, stealCooldown: 1.95, speed: .9, reaction: .75 },
  hard: { name: 'Legend', half: .04, cpuGreen: .58, steal: .23, stealCooldown: 1.65, speed: .97, reaction: .6 }
};
const physicsStats = { backboard: 0, rim: 0, floor: 0, blocks: 0, stealAttempts: 0, steals: 0, passes: 0, passInterceptions: 0 };
function difficultyProfile(level = $('difficulty').value) {
  return DIFFICULTIES[level] || DIFFICULTIES.normal;
}
function shotContest(p) {
  if(p?.preview)return clamp(p.previewContest||0,0,1);
  if(!p || selectedMode==='practice')return 0;
  const hoop=HOOPS[p.team?0:1],toward=unit(hoop.x-p.x,hoop.y-p.y);
  const pressures=players.filter(d=>d.team!==p.team).map(d=>{
    if(d.fallTime>0)return 0;
    const gap=distance(p,d);
    if(gap>=94)return 0;
    const offset=unit(d.x-p.x,d.y-p.y);
    const alignment=offset.x*toward.x+offset.y*toward.y;
    const front=.3+.7*clamp((alignment+.35)/1.35,0,1);
    const hands=d.blockTime>0||d.blockPose>0?1.12:1;
    return clamp((94-gap)/70,0,1)*front*hands;
  }).sort((a,b)=>b-a);
  return clamp((pressures[0]||0)+(pressures[1]||0)*.1,0,1);
}
function contestLabel(value) {
  return value<.1?'WIDE OPEN':value<.3?'OPEN':value<.65?'CONTESTED':'SMOTHERED';
}

function greenWindow(level = $('difficulty').value, p = null) {
  const contest=shotContest(p),base=difficultyProfile(level).half*2;
  const rating=shootingSkill(p), factor=.55+rating*.14;
  const range=shotRangeProfile(p);
  const training=playerTraining(p);
  const width=Math.min(.55,Math.max(.018-range.heave*.012,base*factor*range.window*(1-contest*.72))*1.08*(1+training.timing*.025));
  const hi=SHOT_TARGET_END,lo=hi-width;
  return {lo,hi,width,center:(lo+hi)/2,contest,rating,range,label:contestLabel(contest)};
}
function isGreenRelease(charge, level = $('difficulty').value, p = null) {
  const window=greenWindow(level,p);
  return charge>=window.lo && charge<=window.hi;
}
function sampleCpuTiming(level = $('difficulty').value, p = null) {
  const d=difficultyProfile(level),window=greenWindow(level,p);
  if(Math.random()<d.cpuGreen*(.65+window.rating*.09)*(1-window.contest*.35)) {
    return window.center+(Math.random()-.5)*window.width*.65;
  }
  return Math.random()<.7 ? Math.max(.1,window.lo-.04-Math.random()*.16) : 1+Math.random()*.07;
}
function hoopGeometry(side) {
  const h = HOOPS[side], sign = side ? 1 : -1;
  return { ...h, side, sign, rx: 17.5, ry: 12, tube: 1.8, boardX: h.x + sign * 24,
    boardHalfY: 28, boardBottom: h.z - 8, boardTop: h.z + 31 };
}
function crossingBasket(previous, current, hoop) {
  if (!current.shot?.green || current.vz >= 0 || previous.z < hoop.z || current.z > hoop.z) return false;
  const t = (previous.z - hoop.z) / Math.max(.0001, previous.z - current.z);
  const x = previous.x + (current.x - previous.x) * t - hoop.x;
  const y = previous.y + (current.y - previous.y) * t - hoop.y;
  const innerX = hoop.rx - BALL_RADIUS - .8, innerY = hoop.ry - BALL_RADIUS - .8;
  return x * x / (innerX * innerX) + y * y / (innerY * innerY) < 1;
}
function backboardCollision(previous, ball, hoop) {
  const direction = previous.x < hoop.boardX ? -1 : 1;
  const face = hoop.boardX + direction * BALL_RADIUS;
  const dx = ball.x - previous.x;
  if (Math.abs(dx) < .00001 || dx * direction >= 0) return false;
  const crosses = (previous.x - face) * (ball.x - face) <= 0;
  const overlapping = Math.abs(previous.x - hoop.boardX) <= BALL_RADIUS + .2;
  if (!crosses && !overlapping) return false;
  const t = clamp((face - previous.x) / dx, 0, 1);
  const y = previous.y + (ball.y - previous.y) * t;
  const z = previous.z + (ball.z - previous.z) * t;
  if (Math.abs(y - hoop.y) > hoop.boardHalfY + BALL_RADIUS || z < hoop.boardBottom - BALL_RADIUS || z > hoop.boardTop + BALL_RADIUS) return false;
  ball.x = face + direction * .15; ball.y = y; ball.z = z;
  ball.vx = direction * Math.max(68, Math.abs(ball.vx) * .57);
  const early = ball.shot?.early;
  ball.vy = ball.vy * .48 + (early === undefined ? Math.sign(y - hoop.y) || 1 : early ? -1 : 1) * 64;
  ball.vz = ball.vz * .38 + 18;
  ball.lastTeam = ball.shot?.team ?? ball.lastTeam;
  ball.shot = null; ball.pass = null; ball.lock = .18; ball.lastImpact = 'backboard'; ball.rebound = true;
  return true;
}
function rimCollision(previous, ball, hoop) {
  if (ball.rimCooldown > 0) return false;
  let contact = null;
  for (let i = 0; i <= 5; i++) {
    const t = i / 5;
    const x = previous.x + (ball.x - previous.x) * t - hoop.x;
    const y = previous.y + (ball.y - previous.y) * t - hoop.y;
    const z = previous.z + (ball.z - previous.z) * t - hoop.z;
    const radial = Math.hypot(x, y * hoop.rx / hoop.ry);
    const dr = radial - hoop.rx;
    const gap = Math.hypot(dr, z);
    if (gap < BALL_RADIUS + hoop.tube) { contact = { x, y, z, radial, dr, gap }; break; }
  }
  if (!contact) return false;
  const q = contact, radial = Math.max(.001, q.radial), gap = Math.max(.01, q.gap);
  let nx = q.x / radial * q.dr / gap;
  let ny = q.y * Math.pow(hoop.rx / hoop.ry, 2) / radial * q.dr / gap;
  let nz = q.z / gap;
  const length = Math.hypot(nx, ny, nz) || 1; nx /= length; ny /= length; nz /= length;
  const dot = ball.vx * nx + ball.vy * ny + ball.vz * nz;
  if (dot >= 0) return false;
  const push = BALL_RADIUS + hoop.tube - q.gap + .3;
  ball.x = hoop.x + q.x + nx * push; ball.y = hoop.y + q.y + ny * push; ball.z = hoop.z + q.z + nz * push;
  ball.vx = (ball.vx - 1.64 * dot * nx) * .88;
  ball.vy = (ball.vy - 1.64 * dot * ny) * .88;
  ball.vz = (ball.vz - 1.64 * dot * nz) * .88;
  ball.rimCooldown = .045; ball.lock = .12; ball.lastImpact = 'rim'; ball.rebound = true;
  if (ball.shot && !ball.shot.green) ball.shot = null;
  return true;
}
function segmentNearHand(previous, current, hand, radius) {
  const dx = current.x - previous.x, dy = current.y - previous.y, dz = current.z - previous.z;
  const denominator = dx * dx + dy * dy + dz * dz || 1;
  const t = clamp(((hand.x - previous.x) * dx + (hand.y - previous.y) * dy + (hand.z - previous.z) * dz) / denominator, 0, 1);
  return Math.hypot(previous.x + dx * t - hand.x, previous.y + dy * t - hand.y, (previous.z + dz * t - hand.z) * .9) < radius;
}
function tryJumpBlock(previous) {
  const shot=ball.shot;
  if(!shot || ball.owner!=null || !shot.release || ball.age>BLOCK_RELEASE_TIME || ball.vz<=0 || ball.rebound) return false;
  const hoop=HOOPS[shot.team?0:1];
  if(distance(ball,shot.release)>BLOCK_RELEASE_TRAVEL || distance(ball,hoop)<46) return false;
  for(const p of players) {
    if(p.team===shot.team || p.blockTime<=0 || p.z<1 || distance(p,shot.release)>(isHuman(p)?CLOSE_BLOCK_RANGE:26) || distance(p,ball)>(isHuman(p)?CLOSE_BLOCK_RANGE:26))continue;
    const target=unit(ball.x-p.x,ball.y-p.y);
    const reach=PLAYER_SCALE*heightRatio(p);
    const hand={x:p.x+target.x*8*reach,y:p.y+target.y*5*reach,z:p.z+33*reach};
    if(!segmentNearHand(previous,ball,hand,(isHuman(p)?9:6)+skill(p,'block')*.8))continue;
    const speed=Math.max(95,Math.hypot(ball.vx,ball.vy)*.45);
    ball.vx=target.x*speed;ball.vy=target.y*speed+35;ball.vz=65;
    ball.shot=null;ball.pass=null;ball.lock=.23;ball.lastTeam=p.team;ball.lastImpact='block';
    p.box.blk++;ball.rebound=true;if(p.team===0&&selectedMode!=='watch')earnCoins(15);
    p.blocks++;p.blockPose=.35;p.energy=Math.min(1,p.energy+.22);physicsStats.blocks++;
    burst(ball.x,ball.y-ball.z,'#e6f8ff',13);announce('BLOCK!',.8);tone(100,.12);return true;
  }
  return false;
}
function tryPassInterception(previous) {
  const pass=ball.pass;
  if(!pass || !pass.interceptionAllowed || pass.interceptionResolved)return false;
  const defenders=players.filter(p=>p.team!==pass.team && p.stunned<=0 && !(p.fallTime>0)).sort((a,b)=>distance(a,ball)-distance(b,ball));
  const defender=defenders.find(p=>segmentNearHand(previous,ball,{x:p.x,y:p.y,z:p.z+18},14));
  if(!defender)return false;
  pass.interceptionResolved=true;
  defender.box.stl++;if(players[pass.from])players[pass.from].box.tov++;
  defender.steals++;physicsStats.passInterceptions++;physicsStats.steals++;
  setOwner(defender);announce('PASS INTERCEPTED',.7);tone(350,.06);
  return true;
}

function resolveSteal(p) {
  const owner = ball.owner == null ? null : players[ball.owner];
  physicsStats.stealAttempts++;
  if (p.fallTime>0 || !owner || owner.id !== p.stealTarget || owner.team === p.team || owner.protected > 0 || owner.pickupGrace > 0 || owner.z > 7 || distance(p, owner) > 29 || distance(p, ball) > 29) return false;
  const ai = !isHuman(p), exposed = ball.z - owner.z < 10 && !owner.charging && !owner.pendingShot;
  const odds = ai ? difficultyProfile().steal * (exposed ? 1.25 : .45) : exposed ? .62 : .28;
  if (Math.random() >= odds) { if (isHuman(p)) setStatus('Reach missed. Stay on the ball side and time the bounce.'); return false; }
  const d = unit(p.x - owner.x, p.y - owner.y);
  owner.charging = false; owner.pendingShot = null;
  ball.owner = null; ball.shot = ball.pass = null; ball.vx = d.x * 105; ball.vy = d.y * 105;
  ball.vz = 23; ball.z = Math.max(BALL_RADIUS, ball.z); ball.age = 0; ball.lock = .12; ball.lastTeam = owner.team;
  ball.stealCredit=p.id;ball.turnoverPlayer=owner.id;
  p.steals++; physicsStats.steals++; p.energy = Math.min(1, p.energy + .15);
  announce('POKED LOOSE!', .6); tone(410, .06); return true;
}
function startShotJump(p) {
  if(p.shotJumped || p.z>.1)return;
  p.shotJumped=true;p.vz=shotJumpSpeed(p);p.grounded=false;
}
function shotTakeoffCharge(p) {
  return clamp(greenWindow($('difficulty').value,p).center-SHOT_CHARGE_RATE*shotJumpSpeed(p)/PLAYER_G,.3,.7);
}
function updateShotMotion(p,dt) {
  if(p.charging && !p.shotJumped && p.charge>=shotTakeoffCharge(p))startShotJump(p);
  const gather=p.pendingShot?1:p.charging?clamp(p.charge/.72,0,1):0;
  p.gather+=(gather-p.gather)*Math.min(1,dt*32);
}
function integratePlayerJump(p,dt) {
  const airborne=p.z>0;
  p.z+=p.vz*dt-.5*PLAYER_G*dt*dt;p.vz-=PLAYER_G*dt;
  if(p.z<=0) {
    p.z=0;p.vz=0;p.grounded=true;
    if(airborne)p.landing=.12;
  }
}
function blockTarget(p) {
  const owner=ball.owner==null?null:players[ball.owner];
  if(owner&&owner.team!==p.team)return owner;
  if(ball.shot?.release&&ball.shot.team!==p.team)return {...players[ball.shot.shooter],...ball.shot.release,charging:false};
  return null;
}
function requestBlock(side) {
  let p=active(side);
  const target=blockTarget(p);
  if(target) {
    const nearest=players.filter(m=>m.team===side&&m.stunned<=0&&m.blockCooldown<=0)
      .sort((a,b)=>distance(a,target)-distance(b,target))[0];
    if(nearest&&distance(nearest,target)<=CLOSE_BLOCK_RANGE+4&&distance(nearest,target)<distance(p,target)) {
      controlled[side]=nearest.id;p=nearest;
    }
  }
  block(p);
}
function startBlockJump(p) {
  p.blockBuffer=0;jump(p);
  p.blockTime=.43;p.blockPose=.4;
  const target=blockTarget(p);
  if(target) {
    const aim=unit(target.x-p.x,target.y-p.y);
    p.dirX=aim.x;p.dirY=aim.y;
    if(Math.abs(aim.x)>.1)p.face=Math.sign(aim.x);
  }
}
function updateBlockIntent(p) {
  if(p.blockBuffer>0&&p.z<=.1) {
    const target=blockTarget(p);
    const wait=target?.charging?(greenWindow($('difficulty').value,target).center-target.charge)/SHOT_CHARGE_RATE:0;
    if(!target || wait<=.18)startBlockJump(p);
  }
  if(isHuman(p)&&inputs[p.team].has('block')&&p.blockCooldown<=0&&p.z<=.1&&p.blockBuffer<=0)block(p);
}

function block(p) {
  if(phase!=='live'||p.blockCooldown>0||p.stunned>0)return;
  p.blockCooldown=.48;p.blockPose=.42;
  const target=blockTarget(p);
  const close=target&&distance(p,target)<=CLOSE_BLOCK_RANGE+4;
  const wait=target?.charging?(greenWindow($('difficulty').value,target).center-target.charge)/SHOT_CHARGE_RATE:0;
  if(isHuman(p)&&close&&target.charging&&wait>.18&&p.z<=.1) {
    p.blockBuffer=BLOCK_INPUT_BUFFER;p.blockTime=0;
    announce('BLOCK READY',.4);
    setStatus('BLOCK ARMED. Stay close; your jump follows the shooter’s release.');
  } else {
    startBlockJump(p);
    if(isHuman(p))setStatus(close?'BLOCK! Contest the release with raised hands.':'E: block jump. Get within one step of the shooter to swat the release.');
  }
}
function launchShot(p, charge, boosted, releaseWindow = null, releasedByHuman = isHuman(p)) {
  if(phase!=='live' || periodEnding || ball.owner!==p.id || p.fallTime>0)return;
  const hoop=hoopGeometry(p.team?0:1),d=distance(p,hoop),window=releaseWindow||greenWindow($('difficulty').value,p);
  const percentage=window.percentage??percentageShooting();
  const probability=percentage?playerShotChance(p,hoop,shotContest(p)):null;
  const timedGreen=boosted || charge>=window.lo&&charge<=window.hi,early=percentage?Math.random()<.5:charge<window.lo;
  const range=window.range||shotRangeProfile(p);
  const rangeGood=range.make>=1 || Math.random()<range.make;
  const contestGood=releasedByHuman || d<=230 || Math.random()<cpuContestConversion(window.contest);
  const green=percentage?Math.random()<probability.chance:timedGreen && rangeGood && contestGood;
  const close=d<layupRange(p);
  p.lastCharge=charge;p.releaseWindow={...window};
  p.feedback=percentage?(green?'BUCKET':'MISSED'):green?'GREEN':timedGreen&&!rangeGood?'HEAVE MISS':timedGreen&&!contestGood?'CONTESTED':early?'EARLY':'LATE';p.feedbackTime=1.25;
  p.shootPose=.24;p.shotCount++;p.charging=false;p.moveKind=null;p.protected=0;
  if(green && canDunk(p,d,boosted)) {startDunk(p,hoop,window,boosted);return;}
  let time=close?clamp(.72+d/650,.74,.84):clamp(.65+d/650,.74,1.5);
  const target=green?{x:hoop.x,y:hoop.y,z:hoop.z}:{
    x:hoop.boardX,y:hoop.y+(early?-1:1)*clamp(Math.abs(charge-window.center)*37,5,16),z:hoop.z+17
  };
  const start={x:p.x+(close?0:p.team?-4:4),y:p.y-1,z:p.z+shotReach(p)};
  if(green && close && start.z<hoop.z+BALL_RADIUS+hoop.tube) {
    const dx=start.x-hoop.x,dy=(start.y-hoop.y)*hoop.rx/hoop.ry,r=Math.hypot(dx,dy);
    const releaseRadius=hoop.rx+BALL_RADIUS+hoop.tube+10;
    if(r>hoop.rx-BALL_RADIUS-hoop.tube&&r<releaseRadius) {
      start.x=hoop.x+dx*releaseRadius/r;start.y=hoop.y+(start.y-hoop.y)*releaseRadius/r;
    }
  }
  if(green && close) {
    // A low release needs a higher arc to clear the near lip of the ring.
    for(let i=1;i<80;i++) {
      const f=i/80,dx=(start.x-hoop.x)*(1-f),dy=(start.y-hoop.y)*(1-f);
      const dr=Math.hypot(dx,dy*hoop.rx/hoop.ry)-hoop.rx;
      const clearance=BALL_RADIUS+hoop.tube+.2;
      if(Math.abs(dr)>=clearance)continue;
      const required=hoop.z+Math.sqrt(clearance*clearance-dr*dr);
      const rise=required-start.z-(hoop.z-start.z)*f;
      if(rise>0)time=Math.max(time,Math.sqrt(2*rise/(BALL_G*f*(1-f))));
    }
  }
  const assistId=recordShotAttempt(p,d>230?3:2);
  ball={...start,reboundTeam:p.team,vx:(target.x-start.x)/time,vy:(target.y-start.y)/time,
    vz:(target.z-start.z+.5*BALL_G*time*time)/time,
    owner:null,age:0,spin:0,lock:.16,rimCooldown:0,lastTeam:p.team,behind:false,attempt:true,
    shot:{shooter:p.id,team:p.team,assistId,value:d>230?3:2,flight:time,boosted,green,early,
      layup:close,dunk:false,percentage,probability,
      release:{x:p.x,y:p.y,z:start.z},window:{...window}},pass:null};
  p.energy=boosted?0:Math.min(1,p.energy+.035);trail=[];
  if(p.team===0) {
    announce(percentage?Math.round(probability.chance*100)+'% CHANCE · '+probability.label.toUpperCase():green?(close?'GREEN FINISH':'GREEN RELEASE'):p.feedback+' / OFF THE GLASS',.65);
    setStatus(percentage?'Real Player %: '+probability.label+' · '+Math.round(probability.chance*100)+'% adjusted chance. No timing required.':green?'Perfect release. Only a close rising contest can block it.':p.feedback+' release. Get ready for the backboard rebound.');
  }
  tone(green?510:260,.06,'triangle');
}

const ROSTER = {
  ace: { name: 'ACE', trait: 'THE ALL-ROUNDER', color: '#0968aa', dark: '#03477c', trim: '#f18a30', skin: '#d7a476', hair: '#302728', number: '7', speed: 142, accuracy: 1 },
  bolt: { name: 'BOLT', trait: 'QUICK FEET. QUICK BUCKETS.', color: '#0968aa', dark: '#03477c', trim: '#f18a30', skin: '#aa6d49', hair: '#1c1e24', number: '11', speed: 162, accuracy: 1.05 },
  tank: { name: 'TANK', trait: 'BIG POWER. BIG FINISHES.', color: '#0968aa', dark: '#03477c', trim: '#f18a30', skin: '#82543e', hair: '#202227', number: '34', speed: 129, accuracy: .95 }
};
const LOOK_KEY = 'rimrush-locker-v2';
const COURTS = {
  downtown: { title: 'NEW YORK EMPIRE', subtitle: 'MAPLE GARDEN' },
  sunset: { title: 'GOLDEN HOUR', subtitle: 'MAPLE GARDEN' },
  neon: { title: 'NIGHT LEAGUE', subtitle: 'MAPLE GARDEN' }
};
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const unit = (x, y) => { const n = Math.hypot(x, y) || 1; return { x: x / n, y: y / n }; };
function shade(color, amount = .65) {
  return '#' + [1, 3, 5].map(i => clamp(Math.round(parseInt(color.slice(i, i + 2), 16) * amount), 0, 255).toString(16).padStart(2, '0')).join('');
}
function defaultLook(key = 'ace', side = 0) {
  const p = ROSTER[key];
  return { name: p.name, number: p.number, jersey: side ? '#f0eee5' : p.color, trim: side ? '#12568e' : p.trim, skin: p.skin, hair: p.hair, shoes: side ? '#1b2634' : '#e9e8de', hairstyle: key === 'bolt' ? 'curls' : key === 'tank' ? 'fade' : 'crop', gear: 'none' };
}
function normalizeLook(value, key = 'ace', side = 0) {
  if (!value || typeof value !== 'object') return null;
  const p = defaultLook(key, side);
  const color = (v, fallback) => /^#[0-9a-f]{6}$/i.test(v || '') ? v : fallback;
  return { name: String(value.name || p.name).replace(/[<>\x00-\x1f]/g, '').trim().slice(0, 12) || p.name,
    number: String(clamp(parseInt(value.number, 10) || 0, 0, 99)), jersey: color(value.jersey, p.jersey), trim: color(value.trim, p.trim),
    skin: color(value.skin, p.skin), hair: color(value.hair, p.hair), shoes: color(value.shoes, p.shoes),
    hairstyle: ['crop', 'fade', 'curls', 'spikes', 'long', 'braids', 'bald'].includes(value.hairstyle) ? value.hairstyle : p.hairstyle,
    gear: ['none', 'headband', 'sleeve', 'both'].includes(value.gear) ? value.gear : 'none' };
}
function loadPreferences() {
  let p = {};
  try { p = JSON.parse(localStorage.getItem(LOOK_KEY) || '{}') || {}; } catch {}
  return { looks: [normalizeLook(p.looks?.[0]), normalizeLook(p.looks?.[1], 'bolt', 1)], court: p.overheadVersion === 1 && COURTS[p.court] ? p.court : 'downtown', ball: ['classic', 'lime', 'ice'].includes(p.ball) ? p.ball : 'classic', shake: p.shake !== false, guide: p.guide !== false, overheadVersion: 1,
    meterScale: clamp(Number(p.meterScale) || 1.5, .8, 2.5), difficulty: DIFFICULTIES[p.difficulty] ? p.difficulty : 'normal',nameTags:p.nameTags!==false,
    teams: [p.teams?.[0],p.teams?.[1]].map((id,i)=>LEAGUE.teams.some(t=>t.id===id)?id:i?'LAL':'NYK'),
    quarters:p.quarters===4?4:1,gameDuration:[30,60,90,180,360,720].includes(p.gameDuration)?p.gameDuration:60,replayMode:['off','all','highlights'].includes(p.replayMode)?p.replayMode:'highlights',shootingMode:p.shootingMode==='percentage'?'percentage':'timing',
    captains: Array.isArray(p.captains)?p.captains.slice(0,2):[null,null], customCaptain: p.customCaptain===true };
}
let preferences = loadPreferences();
let phase = 'lobby', previousPhase = 'live', selectedMode = 'cpu', selectedBaller = 'ace';
let players = [], ball = {}, scores = [0, 0], remaining = 60, matchLength = 60, teamSize = 5;
let periodEnding = false, buzzerAge = 0;
let arenaCelebration=null, cheerBuffer=null, playerLabelNodes=[];
let controlled = [0, 5], overtime = false, pointTime = 0, nextPossession = 0, finishingPoint = false;
let elapsed = 0, calloutTime = 0, shotClock = 24, particles = [], trail = [], ripples = [];
let rimImpulses = [0, 0], boardImpulses = [0, 0], shake = 0, soundEnabled = false, audio = null;
let record = { wins: 0, losses: 0 }, resumeAfterHelp = false, fullscreenBusy = false;
let editingPlayer = 0, lockerDraft = null, lockerOptions = null, lockerResume = false, previewClock = 0;
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const touchDevice = matchMedia('(pointer: coarse)').matches || innerWidth <= 640;
const inputs = [new Set(), new Set()], pointers = new Map(), activeKeys = new Map();
try { record = { ...record, ...JSON.parse(localStorage.getItem('rimrush-record') || '{}') }; } catch {}

function captain(side) { return players.find(p => p.team === side && p.slot === 0) || players[0]; }
function active(side = onlineMatch?.role==='guest'?1:0) { return players[controlled[side]] || captain(side); }
function applyLook(p, custom = true, override = null) {
  if(p.nbaId && !override && (!preferences.customCaptain || p.slot>0))return applyNBALook(p);
  const look = override || (custom && preferences.looks[p.team]) || defaultLook(p.key, p.team);
  Object.assign(p, { name: p.slot ? ['ACE', 'CROSS', 'SKY', 'JET', 'BIG O'][p.slot] : look.name,
    number: p.slot ? String([7, 3, 14, 22, 45][p.slot]) : look.number, color: look.jersey, dark: shade(look.jersey, .6),
    trim: look.trim, skin: p.slot ? ['#d7a476', '#82543e', '#aa6d49', '#edc3a1', '#704c38'][p.slot] : look.skin,
    hair: look.hair, hairstyle: p.slot ? ['crop', 'fade', 'curls', 'spikes', 'bald'][p.slot] : look.hairstyle, gear: look.gear, shoes: look.shoes });
  return p;
}
function makePlayer(team, slot, id, key = 'ace', custom = true) {
  return applyLook({ id, team, slot, key, ...ROSTER[key], x: 0, y: 0, vx: 0, vy: 0, z: 0, vz: 0,
    dirX: team ? -1 : 1, dirY: 0, face: team ? -1 : 1, grounded: true, walk: 0, charge: 0,
    charging: false, cooldown: 0, arm: 0, shootPose: 0, passPose: 0, stamina: 100, energy: .35,
    hand: team ? -1 : 1, oldHand: 1, dribbleCycle: slot * .17, moveKind: null, moveAge: 0,
    moveLength: .4, moveCooldown: 0, protected: 0, dashX: 0, dashY: 0, stunned: 0,
    fallTime:0,fallDuration:1.15,fallDirection:1,ankleCooldown:0,guardId:null,navMark:null,avoidId:null,avoidUntil:0,evadeUntil:0,
    buckets: 0, steals: 0, dunks: 0, blocks: 0, passes: 0, moveCount: 0, shotCount: 0,
    brain: .8 + slot * .12, aiCharge: .65, dunkTime: 0, squash: 0,
    possessionAge:0,aiDecision:0,aiPassCooldown:0,inbounding:false,box:emptyBoxStats(),lastPass:null,dunk: null, celebrateTime:0, shotJumped: false, blockBuffer: 0, pickupGrace: 1.1, releaseWindow: null, pendingShot: null, gather: 0, lastCharge: 0, feedback: '', feedbackTime: 0,
    stealWind: 0, stealTarget: null, blockTime: 0, blockPose: 0, blockCooldown: 0, landing: 0 }, custom);
}
function createPlayers() {
  teamSize = selectedMode === 'practice' ? 1 : Number($('team-size').value || 5);
  players = [];
  for(let side=0;side<2;side++) {
    const lineup=selectedLineup(side), primary=selectedProfile(side);
    let unit=teamSize===1?[primary.id]:lineup;
    if(teamSize===3) {
      const others=lineup.filter(id=>id!==primary.id);
      const center=others.find(id=>LEAGUE.players[id].position==='C') || others[others.length-1];
      const wing=others.find(id=>id!==center&&['SG','SF','PF'].includes(LEAGUE.players[id].position)) || others[0];
      unit=[primary.id,wing,center];
    } else unit=[primary.id,...unit.filter(id=>id!==primary.id)];
    for(let slot=0;slot<teamSize;slot++)players.push(makeNBAPlayer(side,slot,players.length,unit[slot]));
  }
  controlled=[0,teamSize]; hudPlayerKey='';
}
function clearInputs() {
  inputs.forEach(s => s.clear()); activeKeys.clear(); pointers.clear();
  players.forEach(p => { p.charging = false; p.charge = 0; });
  document.querySelectorAll('[data-action]').forEach(b => b.classList.remove('pressed'));
}
function resetCourt(ownerTeam = 0) {
  const x = [350, 290, 450, 250, 430], y = [288, 155, 410, 380, 170];
  players.forEach(p => {
    p.x = p.team ? W - x[p.slot] + 32 : x[p.slot];
    p.y = y[p.slot]; p.vx = p.vy = p.z = p.vz = 0; p.grounded = true;
    p.dunk=null;p.celebrateTime=0;p.inbounding=false;p.lastPass=null;p.possessionAge=0;p.aiDecision=.3;p.aiPassCooldown=.5;
    p.moveKind = null; p.protected = 0; p.dashX = p.dashY = 0; p.moveCooldown = 0;
    p.fallTime=0;p.stunned=0;p.ankleCooldown=0;p.guardId=null;p.navMark=null;p.avoidId=null;p.avoidUntil=0;p.evadeUntil=0;p.aiTarget=null;
    p.brain = 1 + p.slot * .1; p.cooldown = 1; p.dunkTime = 0; p.shootPose = 0; p.passPose = 0;
    p.shotJumped = false; p.blockBuffer = 0; p.pickupGrace = 1.2; p.releaseWindow = null; p.pendingShot = null; p.gather = 0; p.feedbackTime = 0;
    p.stealWind = 0; p.blockTime = 0; p.blockPose = 0; p.blockCooldown = 0;
  });
  controlled = [0, teamSize];
  const p = captain(ownerTeam);
  ball = { x: p.x, y: p.y + 4, z: 12, vx: 0, vy: 0, vz: 0, owner: p.id, lock: .15, age: 0, spin: 0, shot: null, pass: null, behind: false };
  shotClock = 24; trail = []; clearInputs();
}
function setStatus(message) { if ($('play-state').textContent !== message) $('play-state').textContent = message; }
function updateRecord() { $('record').innerHTML = 'YOUR RECORD <b>' + record.wins + ' W / ' + record.losses + ' L</b>'; }
function updateScoreboard() {
  $('score-one').textContent=String(scores[0]);$('score-two').textContent=String(scores[1]);
  const time=Math.max(0,Math.ceil(remaining));
  $('clock').textContent=selectedMode==='practice'?'∞':overtime?'OT':String(Math.floor(time/60)).padStart(2,'0')+':'+String(time%60).padStart(2,'0');
  $('period').textContent=selectedMode==='practice'?'GYM':phase==='over'?'FINAL':overtime?'OT':['1ST','2ND','3RD','4TH'][currentQuarter-1]||'OT';
  $('name-one').textContent=selectedTeam(0).id;$('name-two').textContent=selectedMode==='practice'?'SOLO':selectedTeam(1).id;
  $('side-one').textContent=selectedTeam(0).nickname.toUpperCase();$('side-two').textContent=selectedMode==='practice'?'PRACTICE':selectedTeam(1).nickname.toUpperCase();
  const key=selectedTeam(0).id+selectedTeam(1).id;
  if($('scoreboard').dataset.teams!==key){
    $('scoreboard').dataset.teams=key;
    for(let side=0;side<2;side++){
      const team=selectedTeam(side),suffix=side?'two':'one',node=$('score-team-'+suffix);
      node.style.backgroundColor=team.primary;node.style.color=team.accent;
      $('score-logo-'+suffix).src=team.logo;$('score-logo-'+suffix).alt=team.name+' logo';
    }
  }
  const owner=ball.owner==null?null:players[ball.owner],possession=owner?.team??ball.pass?.team??ball.shot?.team??inboundState?.team;
  $('score-team-one').dataset.possession=String(possession===0);$('score-team-two').dataset.possession=String(possession===1);
  $('bug-shot-clock').textContent=selectedMode==='practice'?'—':String(Math.max(0,Math.ceil(shotClock)));
  $('bug-shot-clock').classList.toggle('urgent',shotClock<=5&&selectedMode!=='practice');
  $('broadcast-status').textContent=phase==='replay'?'INSTANT REPLAY':phase==='break'?'QUARTER BREAK':phase==='inbound'?selectedTeam(inboundState.team).id+' INBOUND':phase==='over'?'FINAL':periodEnding?'SHOT LIVE AT THE HORN':selectedMode==='watch'?'AI vs AI · WATCH LIVE':overtime?'NEXT BASKET WINS':totalQuarters===4?'FOUR QUARTER BASKETBALL':'RIM RUSH ARCADE';
  updatePlayerHUD();
  $('mode-label').textContent=selectedMode==='watch'?'WATCH / AI vs AI':careerMatch?careerMatch.mode.toUpperCase():selectedMode==='practice'?'SHOOTAROUND':teamSize+'V'+teamSize+(selectedMode==='two'?' / 2 PLAYERS':' / VS CPU');
  if(onlineMatch)$('mode-label').textContent='ONLINE '+teamSize+'v'+teamSize+' · '+(onlineMatch.role==='host'?'HOME':'AWAY');
  const focused=selectedMode==='watch'?(owner||active()):active();
  $('boost-fill').style.width=Math.round(focused.energy*100)+'%';$('stamina-fill').style.width=Math.round(focused.stamina)+'%';
  updateShotChance(focused);
  $('move-label').textContent=focused.moveKind?focused.moveKind.toUpperCase():focused.stamina<27?'RECOVER':'READY';
  $('possession').textContent=phase==='lobby'?selectedTeam(0).name.toUpperCase()+' / HOME COURT':phase==='paused'?'TIMEOUT':phase==='over'?'FINAL BUZZER':phase==='inbound'?'INBOUND · CLOCK STOPPED':periodEnding?'BUZZER / WAITING FOR SHOT':owner?owner.name+' · '+selectedTeam(owner.team).id+' BALL':ball.pass?'PASS IN THE AIR':'LOOSE BALL';
  $('shot-clock').textContent=selectedMode==='practice'?'PRACTICE':Math.max(0,Math.ceil(shotClock))+' SEC';
}
function announce(text, duration = 1) { $('callout').textContent = text; calloutTime = duration; }
function showLobby() {
  clearArenaCelebration();$('stage').classList.remove('is-paused');
  $('box-open').disabled=!lastBoxScore;
  phase = 'lobby'; resetMatchFlow();createPlayers(); resetCourt(0); scores = [0, 0]; remaining = Number($('duration').value); overtime = false; periodEnding=false; buzzerAge=0;
  setLobbyScreen(lobbyScreen); $('pause-screen').hidden = true; $('result-screen').hidden = true;
  $('stage').classList.add('lobby-active'); $('stage').classList.remove('result-active');
  $('pause-button').disabled = true; $('callout').textContent = '';
  refreshTeamUI(); applyCourtSettings(); updateScoreboard(); setStatus('Overhead pixel basketball. Choose your team and hit the floor.');
}
function startMatch() {
  if(watchBetView&&!watchBetView.beforeStart())return;
  $('ranked-result-note').hidden=true;
  clearArenaCelebration();$('stage').classList.remove('is-paused');
  resetMatchFlow();createPlayers();matchLiveSeconds=0;matchRewarded=false;$('box-open').disabled=false;
  $('arcade-menu').hidden=true;$('stage').classList.remove('home-active');
  $('rematch-button').textContent='RUN IT BACK →';$('career-result-note').textContent='';
  scores = [0, 0]; remaining = Number($('duration').value); matchLength = remaining;
  overtime = false; periodEnding=false; buzzerAge=0; finishingPoint = false; particles = []; resetCourt(0);applyCourtSettings();phase = 'live';
  $('lobby').hidden = true; $('pause-screen').hidden = true; $('result-screen').hidden = true;
  $('stage').classList.remove('lobby-active', 'result-active'); $('pause-button').disabled = false;
  $('pause-button').setAttribute('aria-label', 'Pause game'); updateScoreboard();
  announce(selectedMode === 'practice' ? 'SHOOTAROUND' : 'TIP OFF', .9);
  setStatus(selectedMode==='watch'?'Watch Game: both teams use AI. Pause, inspect box scores, or replay the last basket.':percentageShooting()?'Tap Space / SHOOT. Real Player % chooses the result from player, spot and coverage.':'WASD move · Space shoot · E block · Q pass · C cross · X 360 · V step back · Alt switches nearest to ball.');
  canvas.focus({ preventScroll: true }); if (soundEnabled) initAudio(); tone(330, .08);
}
function pauseGame() {
  if(onlineMatch&&!applyingOnlineCommand){onlineParty.command('pause');return;}
  if (!isMatchRunning()) return;
  previousPhase = phase; phase = 'paused'; $('stage').classList.add('is-paused'); clearInputs(); $('pause-screen').hidden = false;
  $('pause-button').setAttribute('aria-label', 'Resume game'); setStatus('Timeout. Players and clock are paused.'); updateScoreboard();
}
function resumeGame() {
  if(onlineMatch&&!applyingOnlineCommand){onlineParty.command('resume');return;}
  if (phase !== 'paused') return;
  phase = previousPhase; $('stage').classList.remove('is-paused'); $('pause-screen').hidden = true; clearInputs();
  $('pause-button').setAttribute('aria-label', 'Pause game'); canvas.focus({ preventScroll: true }); setStatus('Back on the floor.');
}
function endMatch() {
  if(phase==='over')return;
  phase = 'over';inboundState=null;quarterBreak=null;for(const id of ['quarter-overlay','inbound-banner','replay-banner','crowd-hype'])$(id).hidden=true;$('stage').classList.remove('is-replay','is-clutch'); clearArenaCelebration(); clearInputs(); $('result-screen').hidden = false; $('pause-button').disabled = true; $('stage').classList.add('result-active');
  const won = scores[0] > scores[1], team = players.filter(p => p.team === 0);
  $('result-title').textContent = selectedMode === 'two'&&!onlineMatch ? won ? 'PLAYER 1 WINS.' : 'PLAYER 2 WINS.' : won ? selectedTeam(0).nickname.toUpperCase()+' WIN.' : selectedTeam(1).nickname.toUpperCase()+' WIN.';
  $('result-eyebrow').textContent = overtime ? 'OVERTIME WINNER' : 'FINAL BUZZER';
  $('final-score').textContent = scores[0] + ' — ' + scores[1]; $('result-message').textContent = won ? selectedTeam(0).name+' own the floor.' : 'Next game. New story.';
  for (const [id, key] of [['result-buckets', 'buckets'], ['result-steals', 'steals'], ['result-dunks', 'dunks']]) $(id).textContent = team.reduce((n, p) => n + p[key], 0);
  if (selectedMode === 'cpu'&&!careerMatch) { record[won ? 'wins' : 'losses']++; try { localStorage.setItem('rimrush-record', JSON.stringify(record)); } catch {} updateRecord(); }
  finishBoxAndCareer();
  if(selectedMode==='watch')watchBetView?.finish(won?0:1);
  if(!matchRewarded&&selectedMode!=='practice'&&selectedMode!=='watch'&&!onlineMatch){const reward=won?100:50;earnCoins(reward);matchRewarded=true;$('career-result-note').textContent+=' +'+reward+' coins.';}
  if(onlineMatch){$('rematch-button').textContent='BACK TO PARTY →';onlineParty.finish({scores:[...scores]});}
  $('callout').textContent = ''; setStatus('Final score: ' + scores[0] + ' — ' + scores[1]); updateScoreboard();
}
function initAudio() {
  try { const A = window.AudioContext || window.webkitAudioContext; if (!audio && A) audio = new A(); if (audio?.state === 'suspended') audio.resume().catch(() => {}); } catch {}
}
function tone(frequency, duration = .06, wave = 'square', gain = .025) {
  if (!soundEnabled || !audio) return;
  try { const o = audio.createOscillator(), g = audio.createGain(); o.type = wave; o.frequency.value = frequency;
    g.gain.setValueAtTime(gain, audio.currentTime); g.gain.exponentialRampToValueAtTime(.001, audio.currentTime + duration);
    o.connect(g); g.connect(audio.destination); o.start(); o.stop(audio.currentTime + duration); } catch {}
}
function burst(x, y, color, count = 8) {
  for (let i = 0; i < count; i++) particles.push({ x, y, vx: (Math.random() - .5) * 55, vy: (Math.random() - .5) * 35, life: .3 + Math.random() * .35, color, size: 1 + i % 2 });
}
function addScore(p, points, dunk = false) {
  if (phase !== 'live') return;
  recordMadeBasket(p,points);
  scores[p.team] += points; p.buckets++;
  const effect=animationShop.state.trigger==='all'||points===3?animationShop.state.equipped:'none';
  presentation.basket({name:p.name,points,team:p.team,dunk,x:HOOPS[p.team?0:1].x,y:HOOPS[p.team?0:1].y-HOOPS[p.team?0:1].z,color:p.trim,effect},captureWorld());
  pendingAutoReplay=$('replay-mode').value==='all'||$('replay-mode').value==='highlights'&&(dunk||lateGameIntensity(matchAtmosphere())>.25);
  $('replay-open').disabled=false;
  const flash=$('score-flash-'+(p.team?'two':'one'));flash.textContent='+'+points;flash.animate?.([{opacity:1,transform:'translateY(0) scale(1.3)'},{opacity:0,transform:'translateY(-24px) scale(.9)'}],{duration:1400}); if (dunk) { p.dunks++; p.dunkTime = .7; }
  p.energy = Math.min(1, p.energy + .2); p.moveKind = null; p.protected = 0;
  const hoop = HOOPS[p.team ? 0 : 1]; rimImpulses[p.team ? 0 : 1] = dunk ? 1 : .7;
  ball.rebound=false;ball.reboundTeam=null;
  ball.owner = null; ball.shot = null; ball.pass = null; ball.x = hoop.x; ball.y = hoop.y; ball.z = hoop.z - 4; ball.vx = 0; ball.vy = 12; ball.vz = -20;
  phase = 'point'; pointTime = dunk ? 1.05 : points===3?1.45:.9; nextPossession = selectedMode === 'practice' ? 0 : 1 - p.team; finishingPoint = overtime || periodEnding;
  shake = dunk ? 3 : 1; burst(hoop.x, hoop.y - hoop.z, '#f7b85f', dunk ? 15 : 9); clearInputs();
  startArenaCelebration(p,points,dunk);
  if(p.team===0&&selectedMode!=='watch')earnCoins(points===3?25:10);startShotCelebration(p,points);
  announce(dunk ? 'SLAM DUNK +2' : points === 3 ? 'THREE POINTER' : 'BUCKET +2'); updateScoreboard(); tone(dunk ? 120 : 710, .14);
}
function setOwner(p) {
  const inboundCatch=phase==='inbound'&&inboundState?.released;
  const oldTeam=ball.owner!=null?players[ball.owner].team:ball.shot?.team??ball.pass?.team??ball.lastTeam;
  if(oldTeam!=null&&oldTeam!==p.team){shotClock=24;possessionPasses[p.team]=0;}
  else if(ball.rebound&&ball.reboundTeam===p.team)shotClock=14;
  recordPossession(p);p.possessionAge=0;p.aiDecision=.28;p.aiPassCooldown=.85;
  ball.owner = p.id; ball.shot = ball.pass = null;ball.rebound=false;ball.reboundTeam=null;ball.stealCredit=null;ball.turnoverPlayer=null;ball.attempt=false; ball.age = 0; ball.lock = .1; ball.behind = false;
  p.charging = false; p.charge = 0; p.brain = isHuman(p)?difficultyProfile().reaction:.18+difficultyProfile().reaction*.35;
  p.pickupGrace = .95; p.pendingShot = null; p.releaseWindow = null; p.shotJumped = false;
  p.guardId=null;p.navMark=null;
  if (p.team === 0 || selectedMode === 'two'||selectedMode==='watch') controlled[p.team] = p.id;
  if(inboundCatch){inboundState=null;players.forEach(m=>m.inbounding=false);$('inbound-banner').hidden=true;phase='live';shotClock=24;setStatus('Ball is live.');}
}
function jump(p) {
  if(p.z>.1||phase!=='live'||p.stunned>0)return;
  p.vz=BLOCK_JUMP_SPEED*(.9+skill(p,'block')*.03);p.grounded=false;p.blockTime=.43;p.blockPose=.4;
  burst(p.x,p.y+1,'#d5bc91',4);tone(155,.045,'triangle',.012);
}
function directionFor(side) {
  let x = (inputs[side].has('right') ? 1 : 0) - (inputs[side].has('left') ? 1 : 0);
  let y = (inputs[side].has('down') ? 1 : 0) - (inputs[side].has('up') ? 1 : 0);
  return x || y ? unit(x, y) : { x: 0, y: 0 };
}
function dribbleMove(p, kind) {
  if (phase !== 'live') return false;
  if (ball.owner !== p.id) { if (p.team === 0) setStatus('Get the ball before using a dribble move.'); return false; }
  if (p.dunk || p.charging || p.pendingShot || p.z > 2 || p.moveCooldown > 0 || p.stunned > 0) return false;
  const m = { cross: [14, .3, .45, 105], behind: [18, .4, .6, 110], spin: [24, .44, .7, 130], stepback: [22, .3, .6, 185] }[kind];
  if (!m) return false;
  if (p.stamina < m[0]) { if (p.team === 0) setStatus('Let your handles stamina refill.'); return false; }
  const training=playerTraining(p);
  p.stamina -= m[0]*(1.2-skill(p,'handles')*.05)*(1-training.conditioning*.03); p.moveKind = kind; p.moveAge = 0; p.moveLength = m[1]; p.moveCooldown = m[2]*(1-training.handles*.04);
  p.oldHand = p.hand; p.hand *= -1; p.protected = kind === 'cross' ? .22 : m[1]; p.moveCount++;
  const d = isHuman(p) ? directionFor(p.team) : { x: p.dirX, y: p.dirY };
  p.dashX = (d.x || d.y ? d.x : p.dirX) * m[3]; p.dashY = (d.x || d.y ? d.y : p.dirY) * m[3];
  if(kind==='stepback') {
    const hoop=HOOPS[p.team?0:1],away=unit(p.x-hoop.x,p.y-hoop.y);
    p.dashX=away.x*m[3];p.dashY=away.y*m[3];p.vz=90;p.grounded=false;
  }
  const defender = players.filter(o=>o.team!==p.team&&o.ankleCooldown<=0&&o.fallTime<=0&&o.z<4&&distance(o,p)<59).sort((a,b)=>distance(a,p)-distance(b,p))[0];
  const broken=defender&&tryAnkleBreaker(p,defender,kind);
  if(!broken&&p.team===0)announce(kind === 'cross' ? 'CROSSOVER' : kind === 'behind' ? 'BEHIND THE BACK' : kind==='stepback'?'STEP BACK':'360 SPIN', .45);
  tone(260, .04, 'triangle'); return true;
}
function defend(p) {
  if (phase !== 'live' || p.cooldown > 0 || p.stunned > 0) return;
  if (ball.owner == null && ball.shot) { block(p); return; }
  const owner = ball.owner == null ? null : players[ball.owner];
  if (!owner || owner.team === p.team) return;
  p.cooldown = isHuman(p) ? .95 : difficultyProfile().stealCooldown;
  p.arm = .3; p.stealWind = .18; p.stealTarget = owner.id;
}
function shoot(p, boosted = false) {
  if(phase!=='live'||periodEnding||ball.owner!==p.id||p.pendingShot||p.dunk||p.fallTime>0){p.charging=false;return;}
  const window=greenWindow($('difficulty').value,p);
  window.percentage=percentageShooting();
  p.pendingShot={charge:p.charge,boosted,delay:window.percentage ? .16 : 1/120,window:{...window},human:isHuman(p)};
  p.releaseWindow={...window};p.lastCharge=p.charge;p.charging=false;p.shootPose=.25;p.gather=1;
  p.pickupGrace=Math.max(p.pickupGrace,.25);
  if(!p.shotJumped)startShotJump(p);
}
function passBall(p, forcedTarget = null) {
  if (phase !== 'live' || ball.owner !== p.id || p.pendingShot || p.dunk) return;
  const mates = players.filter(o => o.team === p.team && o.id !== p.id);
  if (!mates.length) { if (p.team === 0) setStatus('Choose 3v3 or 5v5 to pass to teammates.'); return; }
  const direction = directionFor(p.team), hasDirection = direction.x || direction.y;
  const goal = HOOPS[p.team ? 0 : 1];
  const target = forcedTarget || mates.sort((a, b) => {
    const score = o => { const v = unit(o.x - p.x, o.y - p.y); return (hasDirection ? (v.x * direction.x + v.y * direction.y) * 120 : -distance(o, goal) * .3) - distance(o, p) * .06; };
    return score(b) - score(a);
  })[0];
  const t = clamp(distance(p, target) / 520, .25, .7), z = 23*heightRatio(p) + p.z;
  ball = { x: p.x, y: p.y, z, vx: (target.x + target.vx * .12 - p.x) / t, vy: (target.y + target.vy * .12 - p.y) / t,
    vz: (11 - z + .5 * BALL_G * t * t) / t, age: 0, owner: null, spin: 0, lock: .1, shot: null,
    pass: { team: p.team,from:p.id,target: target.id, duration: t,
      interceptionAllowed: Math.random()<PASS_INTERCEPTION_CHANCE, interceptionResolved: false }, behind: false };
  p.passes++;possessionPasses[p.team]++;p.aiPassCooldown=1.25; physicsStats.passes++; p.passPose = .3; p.charging = false; tone(235, .045, 'triangle');
  if (p.team === 0) setStatus('Pass to ' + target.name + ' #' + target.number + '. Control follows the ball.');
}
function boost(p) {
  if (ball.owner !== p.id) { if (p.team === 0) setStatus('Grab the ball before using Boost.'); return; }
  if (p.energy < .999) { if (p.team === 0) setStatus('Boost needs 100%. Score and defend to fill it.'); return; }
  shoot(p, true);
}
function switchPlayer(side) {
  if(phase!=='live'||periodEnding)return;
  const mates=players.filter(p=>p.team===side);
  if(!mates.length)return;
  const nearest=mates.sort((a,b)=>distance(a,ball)-distance(b,ball)||a.id-b.id)[0];
  const previous=active(side);
  if(previous!==nearest) {
    previous.charging=false;previous.charge=0;inputs[side].delete('shoot');
  }
  controlled[side]=nearest.id;
  setStatus('CONTROL: '+nearest.name+' · '+nearest.position+' / closest teammate to the ball.');
}
function beginAction(side, action) {
  if(routeOnlineInput(side,action,true))return;
  if(selectedMode==='watch')return;
  if(phase==='inbound'){if(side===inboundState?.team&&['pass','shoot'].includes(action))releaseInbound();return;}
  if(phase==='break'){if(['pass','shoot'].includes(action))nextQuarter();return;}
  if(phase==='replay'){if(['pass','shoot'].includes(action))finishReplay();return;}
  if (phase !== 'live' || periodEnding || side === 1 && selectedMode !== 'two' || inputs[side].has(action)) return;
  inputs[side].add(action);
  if(action==='block'){requestBlock(side);return;}
  const p = active(side);
  if(action==='switch'){switchPlayer(side);return;}
  if(p.dunk||p.fallTime>0)return;
  if (action === 'jump') jump(p); if (action === 'steal') defend(p); if (action === 'pass') passBall(p);
  if (action === 'switch') switchPlayer(side); if (action === 'boost') boost(p);
  if (['cross', 'behind', 'spin', 'stepback'].includes(action)) dribbleMove(p, action);
  if (action === 'shoot' && ball.owner === p.id && !p.pendingShot) {
    p.charge=0;p.gather=0;p.releaseWindow=null;p.shotJumped=false;
    if(percentageShooting())shoot(p);else p.charging=true;
  }
}
function endAction(side, action) { if(routeOnlineInput(side,action,false))return;inputs[side].delete(action); if (action === 'shoot' && phase === 'live' && active(side).charging) shoot(active(side)); }
function isHuman(p) { return selectedMode!=='watch'&&(p.id === controlled[0] || selectedMode === 'two' && p.id === controlled[1]); }

function computerTarget(p, dt) {
  const owner = ball.owner == null ? null : players[ball.owner], profile = difficultyProfile();
  p.brain -= dt;
  const goal = HOOPS[p.team ? 0 : 1], ownGoal = HOOPS[p.team ? 1 : 0], sign = p.team ? -1 : 1;
  if (owner?.id === p.id) {
    if (p.pendingShot || p.shootPose > .16) return { x: p.x, y: p.y };
    const world={players,hoops:HOOPS,cy:COURT.cy,time:elapsed,shotClock,passes:possessionPasses[p.team]};
    p.possessionAge+=dt;p.aiDecision-=dt;p.aiPassCooldown=Math.max(0,p.aiPassCooldown-dt);
    if(!p.charging&&p.aiDecision<=0){
      const decision=chooseOffense(p,world);p.aiDecision=.2+Math.random()*.15;p.aiTarget=decision.target||null;
      if(decision.action==='pass'){passBall(p,decision.receiver);p.brain=.35;return {x:p.x,y:p.y};}
      if(decision.action==='shoot'&&p.brain<=0){
        p.charge=0;p.releaseWindow=null;p.shotJumped=false;p.gather=0;
        if(percentageShooting())shoot(p);else {p.charging=true;p.aiCharge=sampleCpuTiming($('difficulty').value,p);}
      }
      if(decision.action==='move')dribbleMove(p,decision.move);
    }
    const nearest = players.filter(o => o.team !== p.team && !(o.fallTime>0)).sort((a, b) => distance(a, p) - distance(b, p))[0];
    const insidePlayer=p.position==='C'&&skill(p,'three')<3;
    const shootingRange=insidePlayer?layupRange(p)*.9:285;
    if (p.charging) {
      p.charge = Math.min(1.08, p.charge + dt * SHOT_CHARGE_RATE);
      if (p.charge >= p.aiCharge) shoot(p);
      return { x: p.x, y: p.y };
    }
    if (nearest && distance(nearest, p) < 48 && p.moveCooldown <= 0 && profile.speed > .8) dribbleMove(p, p.slot % 2 ? 'behind' : 'cross');
    return p.aiTarget||{ x: goal.x - sign * (insidePlayer?28:135), y: COURT.cy + Math.sin(elapsed * 1.25 + p.id) * (insidePlayer?18:65) };
  }
  if (!owner) {
    if(ball.pass){
      const receiver=players[ball.pass.target];
      if(receiver?.team===p.team){if(receiver.id===p.id)return {x:p.x,y:p.y};return offensiveSpot(p,receiver,{players,hoops:HOOPS,cy:COURT.cy,time:elapsed});}
      if(receiver)return defensiveAssignment(p,receiver,players,ownGoal);
    }
    if (ball.shot?.release && ball.shot.team !== p.team && p.brain <= 0 && p.blockCooldown <= 0 && ball.age < BLOCK_RELEASE_TIME && distance(p,ball.shot.release)<CLOSE_BLOCK_RANGE) {
      if (Math.random() < (profile.speed - .55) * .65) block(p);
      p.brain = profile.reaction;
    }
    const mates = players.filter(o => o.team === p.team && !(o.fallTime>0)).sort((a, b) => distance(a, ball) - distance(b, ball));
    if (mates.slice(0,ball.rebound?2:1).some(o=>o.id===p.id)) return { x: ball.x, y: clamp(ball.y, 125, 450) };
  }
  if (owner && owner.team !== p.team) {
    const assignment=defensiveAssignment(p,owner,players,ownGoal),onBall=assignment.onBall;
    if (onBall && distance(p, owner) < 28 && p.cooldown <= 0 && p.brain <= 0 && owner.pickupGrace <= 0 && owner.protected <= 0 && !owner.pendingShot) {
      defend(p); p.brain = profile.reaction + .35;
    }
    return assignment;
  }
  return offensiveSpot(p,owner?.team===p.team?owner:null,{players,hoops:HOOPS,cy:COURT.cy,time:elapsed});
}
function stepPlayers(dt) {
  for (const p of players) {
    if (selectedMode === 'practice' && p.team === 1) continue;
    for (const key of ['cooldown','arm','shootPose','passPose','stunned','protected','moveCooldown','pickupGrace','blockTime','blockPose','blockCooldown','blockBuffer','feedbackTime','landing','fallTime','ankleCooldown']) p[key] = Math.max(0, (p[key] || 0) - dt);
    if(p.fallTime>0){
      p.vx*=Math.exp(-dt*10);p.vy*=Math.exp(-dt*10);p.x=clamp(p.x+p.vx*dt,COURT.left+15,COURT.right-15);p.y=clamp(p.y+p.vy*dt,COURT.top+28,COURT.bottom-9);
      p.z=0;p.vz=0;continue;
    }
    if (p.stealWind > 0) { p.stealWind = Math.max(0,p.stealWind-dt); if (!p.stealWind) resolveSteal(p); }
    p.stamina = Math.min(100, p.stamina + dt * (p.moveKind ? 5 : 23)*(1+playerTraining(p).conditioning*.08));
    p.energy = Math.min(1, p.energy + dt * .023);
    p.dribbleCycle += dt * (Math.hypot(p.vx, p.vy) > 40 ? 2.75 : 1.75);
    if(p.dunk){stepDunk(p,dt);continue;}
    updateBlockIntent(p);
    if (p.pendingShot) {
      const releaseDelay=p.pendingShot.delay;
      p.pendingShot.delay -= dt;
      if (p.pendingShot.delay <= 0) {
        const shot=p.pendingShot;p.pendingShot=null;
        if(selectedMode==='practice'||overtime||releaseDelay<remaining-.00000001)launchShot(p,shot.charge,shot.boosted,shot.window,shot.human);
      }
    }
    if(p.dunk){stepDunk(p,dt);continue;}
    if (p.moveKind) { p.moveAge += dt; if (p.moveAge >= p.moveLength) p.moveKind = null; }
    let d;
    if (isHuman(p)) {
      d = directionFor(p.team);
      if (!percentageShooting() && ball.owner === p.id && inputs[p.team].has('shoot') && !p.pendingShot && p.shootPose <= .12) {
        p.charging = true; p.charge = Math.min(1.08, p.charge + dt * SHOT_CHARGE_RATE);
      }
    } else {
      const target=computerTarget(p,dt);
      target.x=clamp(target.x,COURT.left+17,COURT.right-17);target.y=clamp(target.y,COURT.top+30,COURT.bottom-12);
      d=steerAroundPlayers(p,target,players,elapsed,COURT);
    }
    updateShotMotion(p,dt);
    const modifier = isHuman(p) ? 1 : selectedMode==='watch'?difficultyProfile().speed: p.team === 1 && selectedMode === 'cpu' ? difficultyProfile().speed : .87;
    const speed = p.speed * modifier * (p.charging ? .3 : p.pendingShot ? .12 : 1) * (p.stunned ? .1 : 1);
    const acceleration = p.z > 2 ? 6 : 14;
    p.vx += (d.x * speed - p.vx) * Math.min(1, dt * acceleration); p.vy += (d.y * speed - p.vy) * Math.min(1, dt * acceleration);
    p.dashX *= Math.exp(-dt * 6); p.dashY *= Math.exp(-dt * 6);
    p.x = clamp(p.x + (p.vx + p.dashX) * dt, COURT.left + 15, COURT.right - 15);
    p.y = clamp(p.y + (p.vy + p.dashY) * dt, COURT.top + 28, COURT.bottom - 9);
    if (d.x || d.y) { p.dirX = d.x; p.dirY = d.y; if (Math.abs(d.x) > .2) p.face = Math.sign(d.x); }
    p.walk += Math.hypot(p.vx, p.vy) * dt * .095;
    integratePlayerJump(p,dt);
  }
  separatePlayers();
}
function handleBallPosition(p) {
  if(p.dunk)return dunkBallPosition(p);
  if(p.inbounding)return {x:p.x+(p.team?-1:1)*9,y:p.y,z:29,behind:false};
  const phase = (p.dribbleCycle % 1 + 1) % 1;
  const bounce = phase<.55?1-Math.pow(phase/.55,2):1-Math.pow((1-phase)/.45,2);
  let side = p.hand, behind = false, span = 13*PLAYER_SCALE/1.3*heightRatio(p), z = BALL_RADIUS + bounce * 18*PLAYER_SCALE/1.3*heightRatio(p);
  if (p.moveKind) {
    const q = clamp(p.moveAge / p.moveLength, 0, 1), blend = q*q*(3-2*q);
    side = p.oldHand + (p.hand-p.oldHand)*blend;
    if (p.moveKind === 'cross') z = BALL_RADIUS + Math.abs(2*q-1)*15;
    if (p.moveKind === 'behind') { behind = q > .18 && q < .82; z = 13 + Math.sin(q*Math.PI)*5; }
    if (p.moveKind === 'spin') { side = Math.cos(q*Math.PI*2); behind = q>.2 && q<.7; span=15; }
  }
  const gather = p.charging || p.pendingShot ? Math.min(1, (p.gather || 0) + .15) : 0;
  const pace=clamp(Math.hypot(p.vx,p.vy)/140,0,1);
  return { x: p.x + side*span*(1-gather) + p.face*4*gather + p.dirX*pace*4*(1-gather),
    y: p.y + (behind ? -7 : 4)*(1-gather) - gather,
    z: p.z + z*(1-gather) + shotReach(p)*gather, behind: behind && !gather };
}
function stepBall(dt) {
  ball.age += dt; ball.lock = Math.max(0, ball.lock - dt); ball.rimCooldown = Math.max(0,(ball.rimCooldown || 0)-dt);
  if (ball.owner != null) {
    const p = players[ball.owner], pos = handleBallPosition(p);
    Object.assign(ball, pos); ball.spin += dt * 9 * p.hand; return;
  }
  const previous = {x:ball.x,y:ball.y,z:ball.z};
  if(ball.pass) {
    const receiver=players[ball.pass.target];
    const arrival=Math.max(.045,ball.pass.duration-ball.age+dt);
    ball.vx=(receiver.x+receiver.vx*arrival*.35-ball.x)/arrival;
    ball.vy=(receiver.y+receiver.vy*arrival*.35-ball.y)/arrival;
  }
  ball.x += ball.vx*dt; ball.y += ball.vy*dt; ball.z += ball.vz*dt - .5*BALL_G*dt*dt;
  ball.vz -= BALL_G*dt; ball.spin += dt * Math.max(3,Math.hypot(ball.vx,ball.vy)*.025);
  if(tryPassInterception(previous))return;
  if (tryJumpBlock(previous)) trail = [];
  let hitBoard = false;
  for (let side=0;side<2;side++) {
    const hoop=hoopGeometry(side);
    if (backboardCollision(previous,ball,hoop)) {
      boardImpulses[side]=1; rimImpulses[side]=.3; physicsStats.backboard++; hitBoard=true;
      burst(ball.x,ball.y-ball.z,'#dce9e7',5); tone(125,.055,'triangle',.014);
      if (ball.lastTeam===0) setStatus('Off the backboard. Chase the live rebound.');
      break;
    }
  }
  if (!hitBoard) {
    const shot=ball.shot;
    if (shot && crossingBasket(previous,ball,hoopGeometry(shot.team?0:1))) { addScore(players[shot.shooter],shot.value,shot.dunk); return; }
    for (let side=0;side<2;side++) if (rimCollision(previous,ball,hoopGeometry(side))) { rimImpulses[side]=.7; physicsStats.rim++; tone(175,.04,'triangle',.015); break; }
  }
  if (ball.shot) {
    trail.push({x:ball.x,y:ball.y,z:ball.z}); if (trail.length>(ball.shot.boosted?12:6)) trail.shift();
    if (ball.age>ball.shot.flight+1.3) { ball.lastTeam=ball.shot.team; ball.shot=null; ball.rebound=true; }
  }
  if (ball.pass && ball.age>=ball.pass.duration) {
    const receiver=players[ball.pass.target];
    if (distance(receiver,ball)<47 && ball.z<32) { setOwner(receiver); tone(190,.035,'triangle'); return; }
  }
  if (ball.x<COURT.left+BALL_RADIUS || ball.x>COURT.right-BALL_RADIUS) {
    ball.x=clamp(ball.x,COURT.left+BALL_RADIUS,COURT.right-BALL_RADIUS); ball.vx*=-.62;
  }
  if (ball.y<COURT.top+BALL_RADIUS || ball.y>COURT.bottom-BALL_RADIUS) {
    ball.y=clamp(ball.y,COURT.top+BALL_RADIUS,COURT.bottom-BALL_RADIUS); ball.vy*=-.62;
  }
  if (ball.z<BALL_RADIUS) {
    ball.z=BALL_RADIUS;
    if (ball.vz<-18) { ball.vz=-ball.vz*.56; physicsStats.floor++; }
    else ball.vz=0;
    ball.vx*=.83; ball.vy*=.83; ball.shot=null; ball.rebound=true;
  }
  if (ball.z<=BALL_RADIUS+.1 && ball.vz===0) { ball.vx*=Math.exp(-dt*2); ball.vy*=Math.exp(-dt*2); }
  if (!periodEnding && ball.lock<=0 && ball.z<25) {
    const candidates=players.filter(p=>!(p.fallTime>0)&&!(selectedMode==='practice'&&p.team===1) && (!ball.pass || ball.pass.target===p.id)).sort((a,b)=>distance(a,ball)-distance(b,ball));
    const p=candidates.find(p=>distance(p,ball)<19 && (!ball.shot || ball.shot.shooter!==p.id));
    if(p) setOwner(p);
  }
  if (selectedMode==='practice' && ball.owner==null && ball.age>5) { setOwner(active()); announce('BALL RETURNED',.5); }
}
function step(dt) {
  if(onlineMatch?.role==='guest')return;
  if(phase==='paused'||phase==='over')return;
  if(phase==='replay'){if(presentation.stepReplay(dt))finishReplay();return;}
  if(phase!=='lobby')stepMatchAtmosphere(dt);
  if(phase==='break'){quarterBreak.age+=dt;$('quarter-break-time').textContent='Resuming in '+Math.max(0,Math.ceil(quarterBreak.duration-quarterBreak.age))+'…';if(quarterBreak.age>=quarterBreak.duration)nextQuarter();return;}
  if(phase==='inbound'){stepInbound(dt);updateScoreboard();return;}
  if(shotEffect){shotEffect.age+=dt;if(shotEffect.age>shotEffect.duration)shotEffect=null;}
  elapsed+=dt;stepArenaCelebration(dt);shake=Math.max(0,shake-dt*8);
  rimImpulses=rimImpulses.map(v=>Math.max(0,v-dt*1.4));boardImpulses=boardImpulses.map(v=>Math.max(0,v-dt*4));
  particles=particles.filter(p=>{p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;return p.life>0;});
  if(calloutTime>0&&(calloutTime-=dt)<=0)$('callout').textContent='';
  if(phase==='lobby'){players.forEach(p=>p.dribbleCycle+=dt*2.1);stepBall(dt);return;}
  if(phase==='point') {
    pointTime-=dt;
    players.forEach(p=>{p.dunkTime=Math.max(0,p.dunkTime-dt);p.shootPose=Math.max(0,p.shootPose-dt);p.celebrateTime=Math.max(0,(p.celebrateTime||0)-dt);if(p.dunk)stepDunk(p,dt);else integratePlayerJump(p,dt);});
    ball.vz-=BALL_G*dt;ball.z=Math.max(2,ball.z+ball.vz*dt);
    if(pointTime<=0) {
      if(pendingAutoReplay){pendingAutoReplay=false;if(!startInstantReplay())concludeBasket();}
      else concludeBasket();
    }
    updateScoreboard();return;
  }
  if(periodEnding) {
    buzzerAge+=dt;
    players.forEach(p=>{p.shootPose=Math.max(0,p.shootPose-dt);p.celebrateTime=Math.max(0,(p.celebrateTime||0)-dt);if(p.dunk)stepDunk(p,dt);else integratePlayerJump(p,dt);});
    presentation.capture(dt,captureWorld);stepBall(dt);
    if(phase==='live' && !ball.shot && (ball.owner!=null || ball.z<=BALL_RADIUS+.15&&Math.abs(ball.vz)<1&&Math.hypot(ball.vx,ball.vy)<8 || buzzerAge>8))finishPeriod();
    updateScoreboard();return;
  }
  const timed=selectedMode!=='practice'&&!overtime;
  const liveDt=timed?Math.min(dt,remaining):dt;
  if(liveDt>0){
    matchLiveSeconds+=liveDt;
    players.forEach(p=>{if(selectedMode!=='practice'||p.team===0)p.box.seconds+=liveDt;});
    presentation.capture(liveDt,captureWorld);stepPlayers(liveDt);stepBall(liveDt);
  }
  if(timed)remaining=Math.max(0,remaining-liveDt);
  if(timed&&remaining<.000001) {
    remaining=0;
    if(phase==='point') {periodEnding=true;finishingPoint=true;}
    else if((ball.shot||ball.attempt)&&ball.owner==null) {
      periodEnding=true;buzzerAge=0;clearInputs();
      players.forEach(p=>{p.pendingShot=null;p.blockBuffer=0;});
      announce('BUZZER / SHOT IS LIVE',1.5);setStatus('Released before the buzzer. Waiting for the shot and rebound to settle.');tone(95,.3);
    } else finishPeriod();
  } else if(phase==='live'&&selectedMode!=='practice') {
    shotClock=Math.max(0,shotClock-liveDt);
    if(shotClock<=0&&ball.owner!=null){players[ball.owner].box.tov++;nextPossession=1-players[ball.owner].team;beginInbound(nextPossession,'SHOT CLOCK VIOLATION');announce('SHOT CLOCK / TURNOVER',.8);}
  }
  updateScoreboard();
}

function rect(c, x, y, w, h, color) { c.fillStyle = color; c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); }
const GLYPHS = {
 A:['01110','10001','10001','11111','10001','10001','10001'], B:['11110','10001','10001','11110','10001','10001','11110'],
 C:['01111','10000','10000','10000','10000','10000','01111'], D:['11110','10001','10001','10001','10001','10001','11110'],
 E:['11111','10000','10000','11110','10000','10000','11111'], F:['11111','10000','10000','11110','10000','10000','10000'],
 G:['01111','10000','10000','10111','10001','10001','01110'], H:['10001','10001','10001','11111','10001','10001','10001'],
 I:['111','010','010','010','010','010','111'], J:['00111','00010','00010','00010','10010','10010','01100'],
 K:['10001','10010','10100','11000','10100','10010','10001'], L:['10000','10000','10000','10000','10000','10000','11111'],
 M:['10001','11011','10101','10101','10001','10001','10001'], N:['10001','11001','11001','10101','10011','10011','10001'],
 O:['01110','10001','10001','10001','10001','10001','01110'], P:['11110','10001','10001','11110','10000','10000','10000'],
 Q:['01110','10001','10001','10001','10101','10010','01101'], R:['11110','10001','10001','11110','10100','10010','10001'],
 S:['01111','10000','10000','01110','00001','00001','11110'], T:['11111','00100','00100','00100','00100','00100','00100'],
 U:['10001','10001','10001','10001','10001','10001','01110'], V:['10001','10001','10001','10001','10001','01010','00100'],
 W:['10001','10001','10001','10101','10101','10101','01010'], X:['10001','10001','01010','00100','01010','10001','10001'],
 Y:['10001','10001','01010','00100','00100','00100','00100'], Z:['11111','00001','00010','00100','01000','10000','11111']
};
Object.assign(GLYPHS, {
  '3':['111','001','001','111','001','001','111'],
  '+':['000','010','010','111','010','010','000'],
  '!':['1','1','1','1','1','0','1']
});
function pixelWidth(text, scale) { return [...text].reduce((n, ch) => n + (GLYPHS[ch]?.[0].length || 3) * scale + scale, -scale); }
function pixelText(c, text, x, y, scale, color, centered = false) {
  if (centered) x -= pixelWidth(text, scale) / 2;
  for (const ch of text) {
    const glyph = GLYPHS[ch];
    if (glyph) for (let row = 0; row < glyph.length; row++) for (let col = 0; col < glyph[row].length; col++) if (glyph[row][col] === '1') rect(c, x + col * scale, y + row * scale, scale, scale, color);
    x += (glyph?.[0].length || 3) * scale + scale;
  }
}
function drawEmpireLogo(c) {
  const team=selectedCourtTeam(),logo=logoImages.get(team.id);
  c.save();c.globalAlpha=.9;
  if(logo?.complete && logo.naturalWidth>0)c.drawImage(logo,COURT.cx-65,COURT.cy-65,130,130);
  else {
    c.fillStyle=team.primary;c.beginPath();c.arc(COURT.cx,COURT.cy,54,0,Math.PI*2);c.fill();
    pixelText(c,team.id,COURT.cx,COURT.cy-10,3,team.accent,true);
  }
  c.restore();
}
function drawBaller(c,p,x=p.x,y=p.y-p.z,scale=PLAYER_SCALE*heightRatio(p),sceneBall=ball,sceneTime=elapsed) {
  const t=p.preview?p.previewClock:sceneTime,owner=p.preview||sceneBall.owner===p.id;
  const moving=Math.min(1,Math.hypot(p.vx||0,p.vy||0)/90),stride=Math.sin(p.walk||0)*3*moving;
  const gather=p.charging||p.pendingShot?clamp((p.gather||0)+.15,0,1):0;
  const follow=p.shootPose>0&&!gather,blocking=p.blockTime>0||p.blockPose>0;
  const crouch=(p.charging&&!p.shotJumped?Math.sin(clamp(p.charge/shotTakeoffCharge(p),0,1)*Math.PI)*2:0)+(p.landing||0)*10;
  const celebration=p.celebrateTime>0;
  const dribbling=owner&&!gather&&!follow&&!blocking&&!p.dunk;
  const bounceBend=dribbling?Math.pow(Math.sin((p.dribbleCycle||0)*Math.PI),4)*1.2:0;
  const weightShift=p.moveKind==='cross'?Math.sin(p.moveAge/p.moveLength*Math.PI)*p.hand*1.4:0;
  const b=Math.round(crouch+ bounceBend-Math.abs(stride)*.18+(celebration&&!reducedMotion?Math.sin(t*15)*.5:0));
  const skin=p.skin,shadow=shade(skin,.76),light=shade(skin,1.12),ink='#201c23';
  const spin=p.moveKind==='spin'?Math.cos(p.moveAge/p.moveLength*Math.PI*2):1;
  const fallAge=(p.fallDuration||1.15)-(p.fallTime||0);
  const fall=p.fallTime>0?Math.min(1,fallAge/.18,p.fallTime/.38):0;
  c.save();c.translate(Math.round(x+weightShift*scale+(p.fallDirection||1)*fall*7*scale),Math.round(y));
  if(fall>0)c.rotate((p.fallDirection||1)*fall*1.38);
  c.scale(scale*(Math.abs(spin)<.25?.25:spin),scale);
  // Draw limbs in whole logical pixels, preserving the block shapes of the reference.
  const segment=(x1,y1,x2,y2,width,color)=>{
    c.lineCap='round';c.lineJoin='round';c.strokeStyle=shade(color,.62);c.lineWidth=width+.6;
    c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();
    c.strokeStyle=color;c.lineWidth=width;c.stroke();
    c.strokeStyle=shade(color,1.12);c.lineWidth=.55;c.beginPath();c.moveTo(x1-.45,y1);c.lineTo(x2-.45,y2);c.stroke();
  };
  for(const side of [-1,1]) {
    const foot=side*3+side*stride,knee=side*3+side*stride*.5;
    segment(side*3,-8+b,knee,-4,3,side<0?shadow:skin);
    segment(knee,-4,foot,-1,3,skin);
    rect(c,foot-1,-3,3,3,'#f4f3ed');rect(c,foot-2,-1,5,2,p.shoes||'#ecece6');
    rect(c,foot-2,0,5,1,'#252534');rect(c,foot-1,-1,3,1,'#ffffff');
  }
  rect(c,-5,-12+b,10,5,p.dark);rect(c,-5,-11+b,4,4,p.color);rect(c,1,-11+b,4,4,p.color);
  rect(c,-5,-8+b,4,1,p.trim);rect(c,1,-8+b,4,1,p.trim);
  let left={ex:-8,ey:-15+b,wx:-10-stride*.3,wy:-13+b},right={ex:8,ey:-15+b,wx:10+stride*.3,wy:-13+b};
  if(owner&&!gather&&!follow&&!blocking&&!p.dunk) {
    const pos=p.previewBall||handleBallPosition(p),s=PLAYER_SCALE*heightRatio(p);
    const wx=(pos.x-p.x)/s,wy=clamp((pos.y-p.y-pos.z+p.z)/s,-24,-13); 
    const arm={ex:wx*.7,ey:-18+b,wx,wy};if(wx<0)left=arm;else right=arm;
  }
  if(gather) {
    const reach=shotReach(p)/(PLAYER_SCALE*heightRatio(p));
    left={ex:-7,ey:-23,wx:-2,wy:-18-gather*(reach-18)};
    right={ex:7,ey:-23,wx:4,wy:-18-gather*(reach-18)};
  }
  if(follow) {left={ex:-7,ey:-23,wx:-3,wy:-31};right={ex:7,ey:-25,wx:5,wy:-35};}
  if(blocking) {left={ex:-9,ey:-23,wx:-7,wy:-32};right={ex:9,ey:-23,wx:8,wy:-33};}
  if(p.inbounding){left={ex:-7,ey:-18,wx:1,wy:-17};right={ex:7,ey:-18,wx:4,wy:-17};}
  if(p.passPose>0&&!p.inbounding)right={ex:9,ey:-18,wx:p.face*14,wy:-17};
  if(p.stealWind>0)right={ex:9,ey:-14,wx:p.face*16,wy:-10};
  if(fall>0){left={ex:-9,ey:-13,wx:-13,wy:-6};right={ex:9,ey:-11,wx:12,wy:-4};}
  if(celebration) {left={ex:-8,ey:-16,wx:-11,wy:-13};right={ex:10,ey:-23,wx:9,wy:-29};}
  if(p.dunk) {
    const pos=dunkBallPosition(p),s=PLAYER_SCALE*heightRatio(p);
    const wx=(pos.x-p.x)/s,wy=(pos.y-p.y-pos.z+p.z)/s;
    right={ex:8,ey:Math.min(-23,wy+8),wx,wy};
    left=p.dunk.twoHand?{ex:-7,ey:Math.min(-23,wy+8),wx:wx-3,wy}: {ex:-9,ey:-14,wx:-10,wy:-9};
  }
  const arm=(side,pose,sleeve)=>{
    segment(side*5,-19+b,pose.ex,pose.ey,3,sleeve?p.trim:skin);
    segment(pose.ex,pose.ey,pose.wx,pose.wy,3,skin);
    rect(c,pose.wx-1,pose.wy-1,3,3,light);
    rect(c,side*5-1,-19+b,3,2,light);
  };
  arm(-1,left,p.gear==='sleeve'||p.gear==='both');arm(1,right,false);
  rect(c,-6,-20+b,12,2,shade(p.color,.48));
  rect(c,-5,-21+b,10,10,p.color);rect(c,-5,-20+b,2,9,p.dark);rect(c,4,-20+b,1,9,p.trim);
  rect(c,-4,-21+b,2,3,p.trim);rect(c,2,-21+b,2,3,p.trim);
  rect(c,-2,-21+b,4,2,skin);rect(c,-1,-19+b,2,1,p.trim);
  rect(c,-2,-18+b,5,1,shade(p.color,1.18));rect(c,1,-13+b,3,1,shade(p.color,.75));
  rect(c,-4,-15+b,1,3,shade(p.color,.8));rect(c,4,-18+b,1,5,shade(p.color,1.14));
  drawJerseyNumber(c,p.number,-17+b,p.trim);
  rect(c,-2,-24+b,4,3,skin);rect(c,-2,-24+b,4,1,shadow);
  // Sculpted face, ears, jaw and directional lighting, still readable at court scale.
  c.save();c.translate(0,b);
  c.fillStyle=shadow;c.beginPath();c.ellipse(-5.8,-27.7,1.3,2.1,0,0,Math.PI*2);c.fill();c.fillStyle=skin;c.beginPath();c.ellipse(5.6,-27.7,1.3,2.1,0,0,Math.PI*2);c.fill();
  c.beginPath();c.moveTo(-5,-32);c.quadraticCurveTo(0,-36,5,-32);c.quadraticCurveTo(7,-29,4.5,-24);c.quadraticCurveTo(2,-20.6,-1.5,-21.7);c.quadraticCurveTo(-5.5,-23.3,-5.5,-28);c.closePath();
  const faceLight=c.createLinearGradient(-6,-28,6,-27);faceLight.addColorStop(0,shadow);faceLight.addColorStop(.48,skin);faceLight.addColorStop(.78,light);faceLight.addColorStop(1,skin);c.fillStyle=faceLight;c.fill();c.strokeStyle=shade(skin,.62);c.lineWidth=.4;c.stroke();c.restore();
  const hair=p.hairstyle||'fade',hairLight=shade(p.hair,1.45);
  if(hair!=='bald') {
    rect(c,-6,-34+b,12,hair==='fade'?3:4,p.hair);rect(c,-5,-35+b,10,2,p.hair);
    rect(c,-6,-32+b,1,4,p.hair);rect(c,5,-32+b,1,4,p.hair);
    for(let i=0;i<4;i++)rect(c,-4+i*3,-35+b+(i%2),2,1,hairLight);
    if(hair==='crop') {rect(c,2,-32+b,4,2,p.hair);rect(c,-5,-36+b,6,1,hairLight);}
    if(hair==='curls'||hair==='spikes')for(let i=0;i<5;i++){c.fillStyle=p.hair;c.beginPath();c.arc(-4.5+i*2.2,-34.5+b+i%2,1.8,0,Math.PI*2);c.fill();}
    if(hair==='long'||hair==='braids') {
      rect(c,-7,-31+b,2,12,p.hair);rect(c,5,-31+b,2,12,p.hair);
      if(hair==='braids') {
        for(let i=0;i<4;i++){rect(c,-5+i*3,-34+b,1,3,hairLight);rect(c,-7,-29+i*3+b,1,1,hairLight);}
        rect(c,-4,-37+b,2,3,p.hair);rect(c,-3,-39+b,2,3,p.hair);
      }
    }
  }
  if(p.gear==='headband'||p.gear==='both')rect(c,-6,-31+b,12,2,p.trim);
  const blink=Math.sin(t*1.6+p.id)>.998;
  c.save();c.translate(0,b);c.lineCap='round';
  for(const sx of [-3.4,2.5]) {
    c.strokeStyle=shade(p.hair,.75);c.lineWidth=.8;c.beginPath();c.moveTo(sx-1.3,-29);c.lineTo(sx+1.2,-29.3);c.stroke();
    if(!blink){c.fillStyle='#fff3e6';c.beginPath();c.ellipse(sx,-27.9,1.35,.85,0,0,Math.PI*2);c.fill();c.fillStyle=ink;c.beginPath();c.arc(sx+p.face*.25,-27.8,.63,0,Math.PI*2);c.fill();}
    else {c.strokeStyle=ink;c.lineWidth=.6;c.beginPath();c.moveTo(sx-1,-28);c.lineTo(sx+1,-28);c.stroke();}
  }
  c.strokeStyle=shadow;c.lineWidth=.65;c.beginPath();c.moveTo(.2,-28);c.lineTo(-.7,-25.2);c.lineTo(.8,-25);c.stroke();
  c.fillStyle=light;c.fillRect(-.15,-27,.5,1.7);
  if(p.beard){c.strokeStyle=p.hair;c.lineWidth=1.7;c.beginPath();c.moveTo(-4.5,-25.5);c.quadraticCurveTo(-3,-20.5,0,-21.8);c.quadraticCurveTo(3.5,-21.2,4.8,-25.4);c.stroke();}
  c.strokeStyle=p.beard?shade(p.hair,.6):shade(skin,.5);c.lineWidth=.75;c.beginPath();c.moveTo(-1.5,-23.4);c.quadraticCurveTo(.5,-22.6,2.1,-23.6);c.stroke();
  c.restore();
  if(celebration&&p.celebrateKind==='three') {rect(c,right.wx-2,right.wy-3,1,4,skin);rect(c,right.wx,right.wy-4,1,4,skin);rect(c,right.wx+2,right.wy-3,1,3,skin);}
  c.restore();
}
function drawBasketball(c, x, y, spin = 0, style = preferences.ball, hot = false, scale = BALL_RADIUS/3) {
  const main=hot||style==='lime'?'#d0ef57':style==='ice'?'#b2eaff':'#ed9346';
  c.save();c.translate(x,y);c.scale(scale,scale);
  const light=c.createRadialGradient(-1.1,-1.4,.1,.2,.4,3.5);
  light.addColorStop(0,shade(main,1.22));light.addColorStop(.48,main);light.addColorStop(1,shade(main,.48));
  c.beginPath();c.arc(0,0,3.15,0,Math.PI*2);c.fillStyle=light;c.fill();c.strokeStyle='#593525';c.lineWidth=.35;c.stroke();
  c.save();c.beginPath();c.arc(0,0,3,0,Math.PI*2);c.clip();c.rotate(spin*.55);
  c.strokeStyle=style==='ice'?'#3c799a':'#613e2b';c.lineWidth=.38;
  c.beginPath();c.moveTo(-3.3,0);c.lineTo(3.3,0);c.moveTo(0,-3.3);c.lineTo(0,3.3);c.stroke();
  for(const side of [-1,1]){c.beginPath();c.ellipse(side*3.5,0,2.3,3.5,0,0,Math.PI*2);c.stroke();}
  c.restore();c.fillStyle='#ffe7b555';c.fillRect(-1.5,-2.2,.7,.5);c.fillRect(-2,-1.3,.5,.4);c.restore();
}

function buildBackdrop() {
  const layer = document.createElement('canvas'); layer.width = W; layer.height = H;
  const c = layer.getContext('2d'); c.imageSmoothingEnabled = false;
  const theme = preferences.court;
  const blue = theme === 'neon' ? '#243a69' : shade(selectedCourtTeam().primary,.65);
  rect(c, 0, 0, W, H, blue); rect(c, 0, 0, W, 20, '#10283f');
  rect(c, 0, 22, W, 2, '#26628b'); rect(c, 0, 84, W, 5, '#125482');
  for (let i = 0; i < 87; i++) {
    const x = i * 11 + 3, y = i % 2 ? 2 : -1;
    rect(c, x, y, 7, 7, ['#c6a082','#926348','#d1ad88','#785541'][i % 4]);
    rect(c, x - 1, y + 7, 9, 9, ['#1e5074','#a25032','#b7b7a3','#2f3748'][i % 4]);
    rect(c, x - 1, y - 1, 8, 3, '#25242e');
  }
  for (let i = 0; i < 54; i++) {
    const x = 77 + i * 15;
    rect(c, x, 40, 12, 17, '#082b46'); rect(c, x + 1, 41, 10, 11, '#385d76');
    rect(c, x + 2, 42, 8, 8, '#123752'); rect(c, x + 2, 54, 9, 2, '#819197');
    rect(c, x + 1, 58, 1, 5, '#143047'); rect(c, x + 10, 58, 1, 5, '#143047');
    if (i > 2 && i < 8 || i > 44 && i < 50) {
      const p = makePlayer(i < 25 ? 0 : 1, 0, 100 + i, ['ace','bolt','tank'][i % 3], false);
      p.number = String(i); drawBaller(c, p, x + 5, 61, .65);
    }
  }
  rect(c, 395, 47, 191, 18, '#406d96'); rect(c, 398, 49, 185, 13, '#798daf');
  pixelText(c, 'RIM RUSH / '+selectedCourtTeam().id, 491, 53, 1, '#edf0e2', true);
  const l = COURT.left, r = COURT.right, t = COURT.top, b = COURT.bottom;
  rect(c, l - 4, t - 4, r - l + 8, b - t + 8, '#f3edce');
  rect(c, l, t, r - l, b - t, '#d5ac79');
  const woods = theme === 'sunset' ? ['#e0b178','#d9a76c','#d4a16c','#ddb17c'] : theme === 'neon' ? ['#c9ac8d','#d2b598','#bda58f','#cab49b'] : ['#d8af7e','#d3a875','#dfb585','#d4a573','#dcaf7b'];
  for (let row = 0, y = t; y < b; row++, y += 8) {
    rect(c, l, y, r - l, Math.min(8, b - y), woods[row % woods.length]);
    rect(c, l, y + 6, r - l, 1, '#ab7f52'); rect(c, l, y, r - l, 1, '#f1d09e');
    for (let x = l + (row * 61 % 160); x < r; x += 160) {
      rect(c, x, y + 1, 1, 5, '#b1885d'); rect(c, x + 14, y + 3, Math.max(0, Math.min(42, r - x - 14)), 1, '#c69866');
    }
  }
  rect(c, l, COURT.cy - 67, 160, 134, selectedCourtTeam().primary); rect(c, r - 160, COURT.cy - 67, 160, 134, selectedCourtTeam().primary);
  c.strokeStyle = '#fff5db'; c.lineWidth = 2;
  c.strokeRect(l, t, r - l, b - t);
  c.strokeRect(l, COURT.cy - 67, 160, 134); c.strokeRect(r - 160, COURT.cy - 67, 160, 134);
  c.beginPath(); c.moveTo(COURT.cx, t); c.lineTo(COURT.cx, b); c.stroke();
  c.beginPath(); c.arc(COURT.cx, COURT.cy, 66, 0, Math.PI * 2); c.stroke();
  for (const left of [true, false]) {
    const fx = left ? l + 160 : r - 160, hx = left ? HOOPS[0].x : HOOPS[1].x;
    c.setLineDash([]); c.beginPath(); c.arc(fx, COURT.cy, 48, left ? -Math.PI / 2 : Math.PI / 2, left ? Math.PI / 2 : Math.PI * 1.5); c.stroke();
    c.setLineDash([5, 5]); c.beginPath(); c.arc(fx, COURT.cy, 48, left ? Math.PI / 2 : -Math.PI / 2, left ? Math.PI * 1.5 : Math.PI / 2); c.stroke(); c.setLineDash([]);
    c.beginPath(); c.arc(hx, COURT.cy, 27, left ? -Math.PI / 2 : Math.PI / 2, left ? Math.PI / 2 : Math.PI * 1.5); c.stroke();
    for (let yy = COURT.cy - 56; yy <= COURT.cy + 56; yy += 28) { rect(c, left ? l + 60 : r - 64, yy, 5, 2, '#f8f1d6'); rect(c, left ? l + 94 : r - 98, yy, 5, 2, '#f8f1d6'); }
  }
  c.strokeStyle = '#075a8b'; c.lineWidth = 2;
  const radius = 236, a = Math.asin((COURT.cy - t - 24) / radius);
  for (const side of [0, 1]) {
    const h = HOOPS[side], left = side === 0;
    const endpoint = h.x + (left ? 1 : -1) * Math.cos(a) * radius;
    c.beginPath(); c.moveTo(left ? l : r, t + 24); c.lineTo(endpoint, t + 24); c.stroke();
    c.beginPath(); c.moveTo(left ? l : r, b - 24); c.lineTo(endpoint, b - 24); c.stroke();
    c.beginPath(); c.arc(h.x, h.y, radius, left ? -a : Math.PI - a, left ? a : Math.PI + a); c.stroke();
  }
  c.save();c.beginPath();c.rect(l,t,r-l,b-t);c.clip();
  const glow=c.createLinearGradient(0,t,0,b);glow.addColorStop(0,'#fff4d822');glow.addColorStop(.45,'#ffffff00');glow.addColorStop(1,'#102a4333');c.fillStyle=glow;c.fillRect(l,t,r-l,b-t);
  c.fillStyle='#fff7d410';c.beginPath();c.moveTo(l+100,t);c.lineTo(l+240,t);c.lineTo(r-60,b);c.lineTo(r-235,b);c.closePath();c.fill();c.restore();
  drawEmpireLogo(c);
  c.save(); c.translate(49, COURT.cy); c.rotate(-Math.PI / 2); pixelText(c, selectedCourtTeam().name.toUpperCase(), 0, -10, 2, '#f3f0dd', true); c.restore();
  c.save(); c.translate(942, COURT.cy); c.rotate(Math.PI / 2); pixelText(c, selectedCourtTeam().name.toUpperCase(), 0, -10, 2, '#f3f0dd', true); c.restore();
  for (const [x,y] of [[45,170],[45,392],[927,171],[927,393]]) {
    c.strokeStyle = '#5081a0'; c.lineWidth = 1; c.strokeRect(x - 17, y - 18, 29, 36);
    c.beginPath(); c.moveTo(x - 17, y); c.lineTo(x + 12, y); c.stroke();
  }
  for (let i = 0; i < 54; i++) {
    const x = 78 + i * 15; rect(c, x, 510, 12, 15, '#0a304c'); rect(c, x + 2, 511, 8, 9, '#315976'); rect(c, x + 2, 523, 9, 2, '#658198');
  }
  return layer;
}
function buildThemedBackdrop() { return buildBackdrop(); }
let backdrop;
function drawHoop(c, side, front = false) {
  const h=hoopGeometry(side),rimY=h.y-h.z,wobble=Math.sin(elapsed*28)*rimImpulses[side]*1.2;
  if(!front) {
    const top=h.y-h.boardTop-h.boardHalfY,bottom=h.y-h.boardBottom+h.boardHalfY;
    rect(c,h.boardX+h.sign*9-6,h.y-7,12,18,'#163a50');
    c.strokeStyle='#183346';c.lineWidth=6;c.beginPath();c.moveTo(h.boardX+h.sign*9,h.y+3);c.lineTo(h.boardX+h.sign*5,top+12);c.stroke();
    rect(c,h.boardX-4,top,8,bottom-top,'#18384c');
    rect(c,h.boardX-2,top+3,4,bottom-top-6,boardImpulses[side]>0?'#fff5ba':'#e5f2f1');
    rect(c,h.boardX-1,rimY-17,2,31,'#f09252');
    c.strokeStyle='#663b28';c.lineWidth=6;c.beginPath();c.moveTo(h.boardX,rimY);c.lineTo(h.x+h.sign*(h.rx-1),rimY+wobble);c.stroke();
    c.strokeStyle='#fa9c42';c.lineWidth=3;c.stroke();
    c.strokeStyle='#e7f0e5';c.lineWidth=1;
    for(let i=0;i<9;i++) {
      const a=Math.PI*2*i/9,px=Math.cos(a)*h.rx,py=Math.sin(a)*h.ry;
      c.beginPath();c.moveTo(h.x+px,rimY+py+wobble);c.lineTo(h.x+px*.55+wobble,rimY+17+py*.4);c.stroke();
    }
    for(let row=0;row<3;row++)for(let i=0;i<10;i++){const a=i*Math.PI*2/10,shift=(row%2?-.5:.5)*Math.PI*2/10,r0=1-row*.16,r1=1-(row+1)*.16;c.beginPath();c.moveTo(h.x+Math.cos(a)*h.rx*r0,rimY+row*5.7+Math.sin(a)*h.ry*r0);c.lineTo(h.x+Math.cos(a+shift)*h.rx*r1,rimY+(row+1)*5.7+Math.sin(a+shift)*h.ry*r1);c.stroke();}
    c.beginPath();c.ellipse(h.x+wobble,rimY+12.5,h.rx*.7,h.ry*.45,0,0,Math.PI*2);c.stroke();
  }
  c.beginPath();c.ellipse(h.x,rimY+wobble,h.rx,h.ry,0,front?0:Math.PI,front?Math.PI:Math.PI*2);
  c.strokeStyle='#643821';c.lineWidth=4.8;c.stroke();
  c.strokeStyle=front?'#ffae4b':'#e98632';c.lineWidth=2.8;c.stroke();
}
function drawReferee(x, y) {
  const p = { ...makePlayer(0, 0, 200, 'ace', false), x, y, z: 0, color: '#e5e6de', dark: '#a7a9a2', trim: '#252a30', number: '', hair: '#29232b', shoes: '#282a30' };
  drawBaller(ctx, p); rect(ctx, x - 2, y - 17, 1, 7, '#282a30'); rect(ctx, x + 2, y - 17, 1, 7, '#282a30');
}
function drawPracticeGuide() {
  const p = active();
  if (selectedMode !== 'practice' || !preferences.guide || !p.charging || ball.owner !== p.id) return;
  const h = HOOPS[1]; ctx.strokeStyle = '#fff3c1aa'; ctx.lineWidth = 1; ctx.setLineDash([3,6]);
  ctx.beginPath(); ctx.moveTo(p.x, p.y - 16); ctx.lineTo(h.x, h.y - h.z); ctx.stroke(); ctx.setLineDash([]);
}
function meterGeometry(p, scale = preferences.meterScale, level = $('difficulty').value) {
  const width=7*scale,height=58*scale,bend=9*scale;
  const frozen=p.pendingShot?.window || (!p.charging&&p.feedbackTime>0?p.releaseWindow:null);
  return {x:clamp(p.x-22-width,6,W-bend-width-6),y:Math.max(p.previewMeter?24:30,p.y-p.z-height-4),
    width,height,bend,scale,window:frozen||greenWindow(level,p)};
}
function meterPoint(m, progress) {
  const t=clamp(progress,0,1);
  return {x:m.x+m.bend*4*(t-.5)*(t-.5),y:m.y+m.height*(1-t)};
}
function strokeMeter(c,m,from,to,color,width) {
  if(to<=from)return;
  c.beginPath();
  const steps=Math.max(2,Math.ceil((to-from)*48));
  for(let i=0;i<=steps;i++) {
    const point=meterPoint(m,from+(to-from)*i/steps);
    if(i===0)c.moveTo(point.x,point.y);else c.lineTo(point.x,point.y);
  }
  c.strokeStyle=color;c.lineWidth=width;c.lineCap='butt';c.lineJoin='round';c.stroke();
}
function drawShotMeter(c,p,scale=preferences.meterScale,level=$('difficulty').value) {
  if(percentageShooting()&&!p.previewMeter)return;
  const m=meterGeometry(p,scale,level),w=m.window;
  const charge=p.charging?p.charge:p.pendingShot?p.pendingShot.charge:p.lastCharge||0;
  const progress=clamp(charge,0,1),good=p.feedback==='GREEN'&&!p.charging&&!p.pendingShot;
  c.save();
  strokeMeter(c,m,0,1,'#071822',m.width+5);
  strokeMeter(c,m,0,1,'#697a83',m.width+2);
  strokeMeter(c,m,0,1,'#202c35',m.width);
  strokeMeter(c,m,w.hi,1,'#f7d44a',m.width);
  strokeMeter(c,m,w.lo,w.hi,good?'#dcffb2':'#9cfa54',m.width);
  strokeMeter(c,m,0,Math.min(progress,w.lo),'#fffdf0',m.width);
  if(progress>w.hi)strokeMeter(c,m,w.hi,progress,'#ff9a53',m.width);
  if(good) {
    c.globalAlpha=.35;
    strokeMeter(c,m,w.lo,w.hi,'#a6ff6d',m.width+6*scale);
    c.globalAlpha=1;
  }
  const cursor=meterPoint(m,progress),normal=unit(m.height,m.bend*8*(progress-.5));
  const cross=(m.width+4)/2;
  c.beginPath();c.moveTo(cursor.x-normal.x*cross,cursor.y-normal.y*cross);
  c.lineTo(cursor.x+normal.x*cross,cursor.y+normal.y*cross);
  c.strokeStyle='#0a1821';c.lineWidth=4;c.stroke();
  c.strokeStyle=charge>=w.lo&&charge<=w.hi?'#e6ffb5':'#fffdf0';c.lineWidth=1.6;c.stroke();
  const labelX=m.x+m.bend*.5;
  c.textAlign='center';c.font='bold '+Math.max(7,Math.round(6*scale))+'px monospace';
  c.fillStyle=good?'#bdff86':'#fff4d5';
  c.fillText(p.charging||p.pendingShot?'RELEASE':p.feedback||'RELEASE',labelX,m.y-8);
  c.font='bold 7px monospace';
  c.fillStyle=w.contest>.3?'#ffd18a':'#c4e7e4';
  c.fillText(w.range?.heave>.15?'HEAVE / LOW ODDS':w.label+' '+Math.round(w.contest*100)+'%',labelX,m.y+m.height+13);
  c.restore();
}

function draw() {
  interpolateOnlineWorld();
  if(phase==='replay'||phase==='paused'&&previousPhase==='replay'){drawRecordedReplay();return;}
  ctx.save();if(arenaHype()>.2&&preferences.shake&&!reducedMotion&&phase!=='lobby'&&phase!=='over')ctx.translate(Math.sin(elapsed*43)*arenaHype(),Math.cos(elapsed*37)*arenaHype()*.75); if (shake > 0 && preferences.shake && !reducedMotion) ctx.translate((Math.random() - .5) * shake, (Math.random() - .5) * shake);
  ctx.drawImage(backdrop, 0, 0); drawArenaCrowd(ctx);drawPracticeGuide();
  drawReferee(340, 82); drawReferee(610, 509);if(inboundState?.inbounder==null&&inboundState&&!inboundState.released)drawReferee(inboundState.x,COURT.cy+64);
  const visible = players.filter(p => selectedMode !== 'practice' || p.team === 0).sort((a,b) => a.y - b.y);
  for (const p of visible) {
    ctx.fillStyle = '#382f3844'; ctx.beginPath(); ctx.ellipse(p.x, p.y + 1, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
    if (p.id === controlled[0] || selectedMode === 'two' && p.id === controlled[1]) {
      ctx.strokeStyle = p.team ? '#e6f5fc' : '#f6a13e'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(p.x, p.y + 1, 15, 6, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = p.team ? '#eaf1db' : '#f39c38'; ctx.beginPath(); ctx.moveTo(p.x - 3, p.y - p.z - (40*PLAYER_SCALE+4)*heightRatio(p)); ctx.lineTo(p.x + 3, p.y - p.z - (40*PLAYER_SCALE+4)*heightRatio(p)); ctx.lineTo(p.x, p.y - p.z - 40*PLAYER_SCALE*heightRatio(p)); ctx.fill();
    }
    if (ball.behind && ball.owner === p.id) drawBasketball(ctx, ball.x, ball.y - ball.z, ball.spin);
    drawBaller(ctx, p);

    if (!p.dunk && (p.charging || p.pendingShot || p.feedbackTime>0&&p.feedback!=='DUNK')) drawShotMeter(ctx,p);
  }
  drawHoop(ctx, 0); drawHoop(ctx, 1);
  if (ball.owner == null) {
    ctx.fillStyle = '#3d302955'; ctx.beginPath(); ctx.ellipse(ball.x, ball.y, BALL_RADIUS + ball.z * .025, 3, 0, 0, Math.PI * 2); ctx.fill();
    if (ball.shot) trail.forEach((p,i) => { ctx.globalAlpha = i / trail.length * .4; rect(ctx, p.x - 1, p.y - p.z - 1, 2, 2, ball.shot.boosted ? '#f9e889' : '#f7c78b'); }); ctx.globalAlpha = 1;
  }
  if (!ball.behind || ball.owner == null) drawBasketball(ctx, ball.x, ball.y - ball.z, ball.spin, preferences.ball, ball.shot?.boosted);
  drawHoop(ctx,0,true);drawHoop(ctx,1,true);
  for (const p of particles) { ctx.globalAlpha = Math.min(1, p.life * 3); rect(ctx, p.x, p.y, p.size, p.size, p.color); }
  ctx.globalAlpha = 1;
  if(shotEffect)drawShotEffect(ctx,shotEffect.id,shotEffect.age,{x:shotEffect.x,y:shotEffect.y,scale:shotEffect.scale||animationShop.state.effectScale,reducedMotion,points:shotEffect.points});
  drawPointBursts(ctx,onlineMatch?.role==='guest'?networkBursts:presentation.bursts,reducedMotion);
  ctx.restore();
  updatePlayerLabels(visible);
}
function refreshPortraits() { if(players.length)refreshTeamUI(); }
function applyCourtSettings() {
  backdrop = buildThemedBackdrop(preferences.court);
  $('court-title').textContent = selectedCourtTeam().name.toUpperCase();
  $('court-subtitle').textContent = preferences.court==='downtown'?'HOME COURT':COURTS[preferences.court].title;
}
function readLookFields() {
  return {
    name: $('custom-name').value, number: $('custom-number').value,
    jersey: $('custom-jersey').value, trim: $('custom-trim').value,
    shoes: $('custom-shoes').value, skin: $('custom-skin').value,
    hair: $('custom-hair').value, hairstyle: $('custom-hairstyle').value,
    gear: $('custom-gear').value
  };
}
function fillLookFields(look) {
  $('custom-name').value = look.name;
  $('custom-number').value = look.number;
  $('custom-jersey').value = look.jersey;
  $('custom-trim').value = look.trim;
  $('custom-shoes').value = look.shoes;
  const tones=['#f2c9a6','#d7a476','#bd835b','#aa6d49','#82543e','#543d32'];
  $('custom-skin').innerHTML=[look.skin,...tones.filter(t=>t!==look.skin)].map((tone,i)=>'<option value="'+tone+'">'+(i===0?'Player tone':'Tone '+i)+'</option>').join('');
  $('custom-skin').value = look.skin;
  $('custom-hair').value = look.hair;
  $('custom-hairstyle').value = look.hairstyle;
  $('custom-gear').value = look.gear;
  $('custom-error').textContent = '';
}
function openLocker() {
  lockerResume = isMatchRunning();
  if (lockerResume) pauseGame();
  editingPlayer = 0;
  lockerDraft = [0,1].map(id=>({...((preferences.customCaptain&&preferences.looks[id])||nbaLook(captain(id)))}));
  $('custom-captain-look').checked=preferences.customCaptain;
  lockerOptions = { court: preferences.court, ball: preferences.ball, shake: preferences.shake, guide: preferences.guide };
  fillLookFields(lockerDraft[0]);
  $('custom-court').value = lockerOptions.court;
  $('custom-ball').value = lockerOptions.ball;
  $('custom-shake').checked = lockerOptions.shake;
  $('custom-guide').checked = lockerOptions.guide;
  $('custom-name-tags').checked=preferences.nameTags;
  $('custom-meter').value = String(Math.round(preferences.meterScale*100));
  $('custom-difficulty').value = $('difficulty').value;
  $('custom-shooting-mode').value=preferences.shootingMode;
  updateMeterPreview();
  updateEditorTabs();
  $('locker-dialog').showModal();
}
function updateEditorTabs() {
  document.querySelectorAll('[data-edit-player]').forEach(button => {
    const chosen = Number(button.dataset.editPlayer) === editingPlayer;
    button.classList.toggle('selected', chosen);
    button.setAttribute('aria-pressed', String(chosen));
  });
}
function closeLocker() {
  $('locker-dialog').close();
  if (lockerResume) { lockerResume = false; resumeGame(); }
}
function saveLocker(event) {
  event.preventDefault();
  lockerDraft[editingPlayer] = readLookFields();
  for (let id = 0; id < 2; id++) {
    const number = Number(lockerDraft[id].number);
    if (lockerDraft[id].number === '' || !Number.isInteger(number) || number < 0 || number > 99) {
      editingPlayer = id; updateEditorTabs(); fillLookFields(lockerDraft[id]);
      $('custom-error').textContent = 'Choose a whole jersey number from 0 to 99.';
      $('custom-number').focus();
      return;
    }
  }
  preferences = {
    ...preferences,customCaptain:$('custom-captain-look').checked,
    looks: lockerDraft.map((look, id) => normalizeLook(look, captain(id).key, id)),
    court: COURTS[$('custom-court').value] ? $('custom-court').value : 'downtown',
    ball: ['classic', 'lime', 'ice'].includes($('custom-ball').value) ? $('custom-ball').value : 'classic',
    shake: $('custom-shake').checked, guide: $('custom-guide').checked,nameTags:$('custom-name-tags').checked, overheadVersion: 1,
    meterScale:clamp(Number($('custom-meter').value)/100,.8,2.5),
    difficulty: DIFFICULTIES[$('custom-difficulty').value] ? $('custom-difficulty').value : 'normal',
    shootingMode:$('custom-shooting-mode').value==='percentage'?'percentage':'timing'
  };
  synchronizeShootingMode(true);
  let saved = true;
  try { localStorage.setItem(LOOK_KEY, JSON.stringify(preferencesForStorage())); } catch { saved = false; }
  $('difficulty').value = preferences.difficulty; updateDifficultyUI();
  players.forEach(p => applyLook(p));
  applyCourtSettings(); updateScoreboard();
  closeLocker();
  setStatus(saved ? 'Look and gameplay settings saved. Ready for the court.' : 'Look applied for this session. Browser storage is unavailable.');
}
function isExpanded() {
  return Boolean(document.fullscreenElement || document.webkitFullscreenElement || $('game-cabinet').classList.contains('immersive'));
}
function updateExpandedUI() {
  const expanded = isExpanded();
  document.body.classList.toggle('game-expanded', expanded);
  const button = $('fullscreen-button');
  button.innerHTML = expanded ? '⛶ <span>EXIT FULLSCREEN</span>' : '⛶ <span>FULLSCREEN</span>';
  button.setAttribute('aria-label', expanded ? 'Exit fullscreen' : 'Enter fullscreen');
  button.setAttribute('aria-pressed', String(expanded));
}
function enterImmersive() {
  $('game-cabinet').classList.add('immersive');
  updateExpandedUI();
  canvas.focus({ preventScroll: true });
  setStatus('Expanded play is on. Use F or the fullscreen button to return.');
}
async function exitExpanded() {
  $('game-cabinet').classList.remove('immersive');
  try {
    if (document.fullscreenElement && document.exitFullscreen) await document.exitFullscreen();
    else if (document.webkitFullscreenElement && document.webkitExitFullscreen) document.webkitExitFullscreen();
  } catch {}
  updateExpandedUI();
  canvas.focus({ preventScroll: true });
}
async function toggleFullscreen() {
  if (fullscreenBusy) return;
  fullscreenBusy = true;
  if (isExpanded()) {
    await exitExpanded();
    fullscreenBusy = false;
    return;
  }
  const cabinet = $('game-cabinet');
  const request = cabinet.requestFullscreen || cabinet.webkitRequestFullscreen;
  if (!request) {
    enterImmersive(); fullscreenBusy = false; return;
  }
  try {
    await request.call(cabinet);
    if (!document.fullscreenElement && !document.webkitFullscreenElement) enterImmersive();
    else { updateExpandedUI(); canvas.focus({ preventScroll: true }); }
  } catch { enterImmersive(); }
  fullscreenBusy = false;
}
function renderLockerPreview(now) {
  if (!$('locker-dialog').open) return;
  previewClock = now / 1000;
  const c = $('locker-preview').getContext('2d');
  c.clearRect(0, 0, 300, 300);
  c.imageSmoothingEnabled = false;
  const look = normalizeLook(readLookFields(), captain(editingPlayer).key, editingPlayer);
  const p = applyLook({...captain(editingPlayer),id:-1},false,look);
  p.z=0;p.vx=0;p.vy=0;p.charging=false;p.pendingShot=null;p.moveKind=null;p.shootPose=0;
  p.x = 150; p.y = 241; p.preview = true; p.dribbleCycle = previewClock * 1.7;
  p.hand = 1; p.walk = 0; p.previewClock = previewClock;
  const position = handleBallPosition(p);
  p.previewBall = position;
  c.fillStyle = '#91c88d22'; c.beginPath(); c.ellipse(150, 254, 61, 11, 0, 0, Math.PI * 2); c.fill();
  drawBaller(c, p, 150, 241, 6*heightRatio(p));
  c.save(); c.translate(150, 241); c.scale(6/PLAYER_SCALE, 6/PLAYER_SCALE);
  drawBasketball(c, (position.x - p.x), (position.y - p.y - position.z), previewClock * 6, $('custom-ball').value);
  c.restore();
  updateMeterPreview();
  $('preview-name').textContent = look.name;
  $('preview-build').textContent = captain(editingPlayer).position+' / '+captain(editingPlayer).height+' / '+selectedTeam(editingPlayer).id;
  $('preview-speed').textContent = captain(editingPlayer).key === 'bolt' ? '●●●●●' : captain(editingPlayer).key === 'tank' ? '●●●' : '●●●●';
  $('preview-power').textContent = captain(editingPlayer).key === 'tank' ? '●●●●●' : '●●●';
}
function updateDifficultyUI() {
  const d=difficultyProfile();
  $('difficulty-hint').textContent=percentageShooting()?d.name+' · Real Player %: tap to shoot · Defense lowers the odds':d.name+' · Slightly wider greens · Tight defense narrows the window';
}
function updateMeterPreview() {
  const scale=clamp(Number($('custom-meter').value)/100,.8,2.5),level=$('custom-difficulty').value;
  $('meter-size-value').textContent=Math.round(scale*100)+'%';
  $('custom-meter').setAttribute('aria-valuetext',Math.round(scale*100)+' percent');
  const c=$('meter-preview').getContext('2d');
  c.clearRect(0,0,300,220);
  const noTiming=$('custom-shooting-mode').value==='percentage';$('custom-meter').disabled=noTiming;
  if(noTiming){
    const p=captain(editingPlayer);c.fillStyle='#163c58';c.fillRect(0,0,300,220);c.textAlign='left';
    c.font='900 14px Arial';c.fillStyle='#ffe3aa';c.fillText('REAL PLAYER %',16,26);
    c.font='11px Arial';c.fillStyle='#d5e6eb';c.fillText('TAP TO SHOOT · NO METER',16,45);
    for(let index=0;index<6;index++){
      const record=zoneBaseRate(p,index),y=70+index*22;
      c.fillStyle='#b9d4e4';c.fillText(ZONE_NAMES[index],16,y);c.textAlign='right';c.fillStyle='#d9f8aa';
      c.fillText((record.base*100).toFixed(1)+'%'+(record.estimated?' EST':''),282,y);c.textAlign='left';
    }
    $('custom-difficulty-hint').textContent='NBA zone base rates; missing zones use the player’s 2P/3P rate. New players without NBA history use labeled estimates. Coverage, movement, fatigue and distance adjust the shot chance. Timing upgrades do not change NBA data.';return;
  }
  for(const [x,contest] of [[96,0],[240,.85]]) {
    const p={...captain(editingPlayer),x,y:192,z:0,charging:true,pendingShot:null,feedbackTime:0,preview:true,previewMeter:true,previewContest:contest};
    p.charge=greenWindow(level,p).center;
    drawShotMeter(c,p,scale,level);
  }
  const d=difficultyProfile(level),w=greenWindow(level,{...captain(editingPlayer),preview:true,previewContest:0});
  $('custom-difficulty-hint').textContent=d.name+': '+Math.round(w.width*100)+'% open 3-point green for '+captain(editingPlayer).name+'. Tight defense narrows the green tip. Hold Space / Shoot to gather and jump; release in green at the top of the jump.';
}

function initializeUpgrades() {
  const cabinet = $('game-cabinet');
  cabinet.appendChild($('help-dialog'));
  cabinet.appendChild($('locker-dialog'));
  cabinet.appendChild($('career-dialog'));cabinet.appendChild($('box-score-dialog'));
  $('locker-form').setAttribute('novalidate', '');
  $('locker-open').addEventListener('click', openLocker);
  $('locker-toolbar').addEventListener('click', openLocker);
  $('locker-close').addEventListener('click', closeLocker);
  $('locker-dialog').addEventListener('cancel', event => { event.preventDefault(); closeLocker(); });
  $('locker-form').addEventListener('submit', saveLocker);
  $('fullscreen-button').addEventListener('click', toggleFullscreen);
  document.addEventListener('fullscreenchange', updateExpandedUI);
  document.addEventListener('webkitfullscreenchange', updateExpandedUI);
  document.querySelectorAll('[data-edit-player]').forEach(button => {
    button.addEventListener('click', () => {
      lockerDraft[editingPlayer] = readLookFields();
      editingPlayer = Number(button.dataset.editPlayer);
      fillLookFields(lockerDraft[editingPlayer]); updateEditorTabs();
    });
  });
  document.querySelectorAll('[data-jersey]').forEach(button => {
    button.addEventListener('click', () => { $('custom-jersey').value = button.dataset.jersey; });
  });
  $('reset-look').addEventListener('click', () => { fillLookFields(nbaLook(captain(editingPlayer))); });
  $('difficulty').value = preferences.difficulty;
  $('difficulty').addEventListener('change', () => {
    preferences.difficulty = $('difficulty').value; updateDifficultyUI();
    try { localStorage.setItem(LOOK_KEY, JSON.stringify(preferencesForStorage())); } catch {}
  });
  $('custom-meter').addEventListener('input',updateMeterPreview);
  $('custom-difficulty').addEventListener('change',updateMeterPreview);
  $('custom-shooting-mode').addEventListener('change',updateMeterPreview);
  updateDifficultyUI(); applyCourtSettings();
  updateExpandedUI();
}

function keyAction(code) {
  if(onlineMatch){const arrows={ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right',Enter:'shoot'};if(arrows[code])return [0,arrows[code]];}
  const one = { KeyW:'up', KeyA:'left', KeyS:'down', KeyD:'right', KeyJ:'shoot', Space:'shoot',
    KeyR:'block', KeyB:'block', KeyK:'steal', KeyL:'boost', KeyC:'cross', KeyQ:'pass', KeyE:'block', KeyX:'spin', KeyV:'stepback', KeyZ:'behind', AltLeft:'switch', AltRight:'switch', Tab:'switch' };
  if (one[code]) return [0, one[code]];
  const arrows = { ArrowUp:'up', ArrowLeft:'left', ArrowDown:'down', ArrowRight:'right' };
  if (arrows[code]) return [selectedMode === 'two' ? 1 : 0, arrows[code]];
  if (selectedMode === 'two') {
    const two = { Enter:'shoot', ShiftRight:'pass', KeyU:'block', KeyH:'block', KeyI:'steal', Numpad0:'steal', KeyO:'boost', Slash:'cross', Period:'behind', Comma:'spin', Semicolon:'stepback', Backslash:'switch' };
    if (two[code]) return [1, two[code]];
  }
  return null;
}
window.addEventListener('keydown', event => {
  if (['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName) || $('help-dialog').open || $('locker-dialog').open || $('career-dialog').open || $('box-score-dialog').open || $('animation-shop-dialog').open) return;
  if (event.code === 'KeyF' && !event.repeat) { event.preventDefault(); toggleFullscreen(); return; }
  if (event.code === 'Escape' && isExpanded()) { event.preventDefault(); exitExpanded(); return; }
  if (event.code === 'Escape' || event.code === 'KeyP') {
    if (isMatchRunning()) { event.preventDefault(); pauseGame(); } else if (phase === 'paused') { event.preventDefault(); resumeGame(); }
    return;
  }
  if(phase==='replay'&&['Space','Enter','Escape'].includes(event.code)){event.preventDefault();finishReplay();return;}
  if(phase==='break'&&['Space','Enter'].includes(event.code)){event.preventDefault();nextQuarter();return;}
  if(phase==='inbound'&&['KeyQ','Space','Enter','ShiftRight'].includes(event.code)){event.preventDefault();if(onlineMatch){beginAction(0,'pass');return;}const side=event.code==='Enter'||event.code==='ShiftRight'?1:0;if(selectedMode!=='watch'&&side===inboundState?.team)releaseInbound();return;}
  if (phase !== 'live' || event.code === 'Tab' && document.activeElement !== canvas) return;
  const action = keyAction(event.code); if (!action) return;
  event.preventDefault(); if (event.repeat || activeKeys.has(event.code)) return;
  activeKeys.set(event.code, action); beginAction(...action);
});
window.addEventListener('keyup', event => {
  const action = activeKeys.get(event.code); if (!action) return;
  event.preventDefault(); activeKeys.delete(event.code);
  if (![...activeKeys.values(),...pointers.values()].some(v => v[0] === action[0] && v[1] === action[1])) endAction(...action);
});
window.addEventListener('blur',()=>{if(onlineMatch){inputs[onlineMatch.role==='guest'?1:0].clear();activeKeys.clear();pointers.clear();onlineParty.resetInputs();}else clearInputs();});
document.addEventListener('visibilitychange', () => { if (document.hidden&&!onlineMatch) pauseGame(); });
document.querySelectorAll('[data-action]').forEach(button => {
  button.addEventListener('contextmenu', event => event.preventDefault());
  button.addEventListener('pointerdown', event => {
    event.preventDefault(); if(phase==='inbound'&&['pass','shoot'].includes(button.dataset.action)){if(onlineMatch)beginAction(0,'pass');else if(inboundState.team===0)releaseInbound();return;}if (phase !== 'live') return;
    button.setPointerCapture(event.pointerId); const action = [0,button.dataset.action];
    pointers.set(event.pointerId,action); button.classList.add('pressed'); beginAction(...action);
  });
  const release = event => {
    const action = pointers.get(event.pointerId); if (!action) return;
    pointers.delete(event.pointerId); button.classList.remove('pressed');
    if (![...activeKeys.values(),...pointers.values()].some(v => v[0] === action[0] && v[1] === action[1])) endAction(...action);
  };
  button.addEventListener('pointerup',release); button.addEventListener('pointercancel',release); button.addEventListener('lostpointercapture',release);
});
document.querySelectorAll('[data-mode]').forEach(button => button.addEventListener('click',() => {
  selectedMode = button.dataset.mode;
  document.querySelectorAll('[data-mode]').forEach(b => { const chosen = b === button; b.classList.toggle('selected',chosen); b.setAttribute('aria-pressed',String(chosen)); });
  $('difficulty').disabled = false; $('duration').disabled = selectedMode === 'practice'; $('team-size').disabled = selectedMode === 'practice';$('quarter-count').disabled=selectedMode==='practice';
  watchBetView?.render();
  $('lobby-tip').textContent = selectedMode==='watch'?'Both teams are controlled by AI. Use pause, replays and box scores.':selectedMode === 'two' ? 'P1: WASD + Space · P2: arrows + Enter · passes: Q / RShift' : touchDevice ? 'Four-way pad · Pass to teammates · Hold Shoot, release green' : 'Space shoot · E block · Q pass · C cross · X 360 · V step back · Alt switch';
  showLobby();
}));
document.querySelectorAll('[data-baller]').forEach(button => button.addEventListener('click',() => {
  selectedBaller = button.dataset.baller;
  document.querySelectorAll('[data-baller]').forEach(b => { const chosen = b === button; b.classList.toggle('selected',chosen); b.setAttribute('aria-pressed',String(chosen)); });
  $('baller-trait').textContent = ROSTER[selectedBaller].trait; showLobby();
}));
for (const id of ['duration','team-size']) $(id).addEventListener('change',() => { if (phase === 'lobby') showLobby(); });
$('start-button').addEventListener('click',startMatch);
$('pause-button').addEventListener('click',() => phase === 'paused' ? resumeGame() : pauseGame());
$('resume-button').addEventListener('click',resumeGame); $('restart-button').addEventListener('click',startMatch);
$('quit-button').addEventListener('click',returnToMenu); $('rematch-button').addEventListener('click',()=>onlineMatch?onlineParty.rematch():careerMatch?.completed?returnToMenu():selectedMode==='watch'&&!careerMatch?selectQuickMode('watch'):startMatch());
$('result-lobby-button').addEventListener('click',returnToMenu);
$('sound-button').addEventListener('click',() => {
  soundEnabled = !soundEnabled; if (soundEnabled) initAudio();
  if (!audio) soundEnabled = false; $('sound-button').textContent = soundEnabled ? 'SOUND ON' : 'SOUND OFF';
  $('sound-button').setAttribute('aria-label',soundEnabled ? 'Mute sound' : 'Enable sound'); $('sound-button').setAttribute('aria-pressed',String(soundEnabled)); tone(520,.07);
});
function openHelp() { resumeAfterHelp = isMatchRunning(); if (resumeAfterHelp) pauseGame(); $('help-dialog').showModal(); }
function closeHelp() { $('help-dialog').close(); if (resumeAfterHelp) { resumeAfterHelp = false; resumeGame(); } }
$('help-open').addEventListener('click',openHelp); $('help-bottom').addEventListener('click',openHelp);
$('help-close').addEventListener('click',closeHelp); $('help-done').addEventListener('click',closeHelp);
$('help-dialog').addEventListener('cancel',e => { e.preventDefault(); closeHelp(); });


function drawJerseyNumber(c,number,y,color) {
  const digits={0:['111','101','101','101','111'],1:['010','110','010','010','111'],2:['111','001','111','100','111'],3:['111','001','111','001','111'],4:['101','101','111','001','001'],5:['111','100','111','001','111'],6:['111','100','111','101','111'],7:['111','001','010','010','010'],8:['111','101','111','101','111'],9:['111','101','111','001','111']};
  const text=String(number).slice(0,2);let x=-(text.length*4-1)/2;
  for(const char of text) {
    const glyph=digits[char];
    if(glyph)for(let row=0;row<5;row++)for(let col=0;col<3;col++)if(glyph[row][col]==='1')rect(c,x+col,y+row,1,1,color);
    x+=4;
  }
}
function shotRangeProfile(p) {
  if(!p||p.preview)return {window:1,make:1,heave:0};
  const d=distance(p,HOOPS[p.team?0:1]),beyond=Math.max(0,d-400)/280;
  const heave=clamp((d-560)/120,0,1);
  return {window:1/(1+5*Math.pow(beyond,2.5)),make:1-heave*(.975-skill(p,'three')*.015),heave};
}
function cpuContestConversion(contest) { return .08+.92*Math.pow(1-clamp(contest,0,1),2); }
function canDunk(p,d,boosted) {
  const moving=Math.hypot(p.vx,p.vy)>45;
  return d<33+skill(p,'finish')*3+(p.heightIn-78)*.4 &&
    (boosted || p.heightIn>=79&&skill(p,'finish')>=3.5 || moving&&skill(p,'finish')>=4.5);
}
function startDunk(p,hoop,window,boosted) {
  p.dunk={age:0,releaseAt:.14,duration:.63,released:false,hoop:{...hoop},window:{...window},
    start:{x:p.x,y:p.y,z:p.z},startBall:{...handleBallPosition(p)},
    peak:Math.max(22,hoop.z-43*PLAYER_SCALE/1.3*heightRatio(p)+10),twoHand:p.heightIn>=81};
  p.vx=p.vy=p.vz=0;p.charging=false;p.pendingShot=null;p.protected=.3;
  p.energy=boosted?0:Math.min(1,p.energy+.035);p.feedback='DUNK';p.shootPose=0;
  setStatus(p.name+' rises for the rim.');
}
function dunkBallPosition(p) {
  const d=p.dunk,q=clamp(d.age/d.releaseAt,0,1),ease=1-Math.pow(1-q,3);
  if(d.released&&d.age>.3) {
    const lower=clamp((d.age-.3)/.25,0,1);
    return {x:d.hoop.x+(p.x+p.face*10-d.hoop.x)*lower,
      y:d.hoop.y+(p.y+3-d.hoop.y)*lower,
      z:d.hoop.z+9+(p.z+24*heightRatio(p)-d.hoop.z-9)*lower,behind:false};
  }
  return {x:d.startBall.x+(d.hoop.x-d.startBall.x)*ease,
    y:d.startBall.y+(d.hoop.y-d.startBall.y)*ease,
    z:d.startBall.z+(d.hoop.z+9-d.startBall.z)*ease,behind:false};
}
function stepDunk(p,dt) {
  const d=p.dunk;if(!d)return;
  d.age+=dt;
  const rise=clamp(d.age/d.releaseAt,0,1),ease=1-Math.pow(1-rise,3);
  const endX=d.hoop.x+(p.team?11:-11),endY=d.hoop.y+5;
  p.x=d.start.x+(endX-d.start.x)*ease;p.y=d.start.y+(endY-d.start.y)*ease;
  p.z=d.start.z+(d.peak-d.start.z)*Math.sin(rise*Math.PI/2);p.grounded=false;
  if(d.age>.3) {
    const fall=clamp((d.age-.3)/(.61-.3),0,1);p.z=d.peak*(1-fall*fall);
  }
  if(!d.released&&d.age>=d.releaseAt) {
    const beforeHorn=selectedMode==='practice'||overtime||remaining>dt+.00000001;
    if(!periodEnding&&phase==='live'&&ball.owner===p.id&&beforeHorn) {
      const pos=dunkBallPosition(p),assistId=recordShotAttempt(p,2);d.released=true;
      ball={...pos,reboundTeam:p.team,vx:0,vy:0,vz:-85,owner:null,age:0,spin:0,lock:.2,rimCooldown:0,lastTeam:p.team,attempt:true,
        shot:{shooter:p.id,team:p.team,assistId,value:2,flight:.12,green:true,dunk:true,
          release:{x:p.x,y:p.y,z:pos.z},window:d.window},pass:null};
      trail=[];p.releaseWindow=d.window;tone(160,.06,'triangle');
    }
  }
  if(d.age>=d.duration) {p.dunk=null;p.z=0;p.vz=0;p.grounded=true;p.landing=.12;}
}
function startArenaCelebration(p,points=3,dunk=false) {
  arenaCelebration={age:0,duration:points===3?1.35:.8,team:p.team,points};p.celebrateTime=arenaCelebration.duration;p.celebrateKind=dunk?'dunk':points===3?'three':'two';
  $('arena-celebration-value').textContent='+'+points;$('arena-celebration-type').textContent=dunk?'SLAM DUNK':points===3?'THREE POINTER':'BUCKET';
  $('stage').classList.add('three-celebrating');
  const banner=$('arena-celebration');
  $('arena-celebration-name').textContent=p.name+' · '+selectedTeam(p.team).nickname;
  banner.style.borderColor=p.trim;banner.hidden=false;banner.classList.add('celebrating');
  $('score-'+(p.team?'two':'one')).classList.add('score-pop');
  for(let i=0;i<22;i++)particles.push({x:COURT.left+Math.random()*(COURT.right-COURT.left),y:20+Math.random()*20,
    vx:(Math.random()-.5)*35,vy:25+Math.random()*40,life:.8+Math.random()*.5,color:i%2?p.trim:p.color,size:2});
  playCrowdCheer();
}
function clearArenaCelebration(clearEffect=true) {
  if(clearEffect)shotEffect=null;
  $('stage').classList.remove('three-celebrating');
  arenaCelebration=null;$('arena-celebration').hidden=true;$('arena-celebration').classList.remove('celebrating');
  $('score-one').classList.remove('score-pop');$('score-two').classList.remove('score-pop');
}
function stepArenaCelebration(dt) {
  if(!arenaCelebration)return;
  arenaCelebration.age+=dt;if(arenaCelebration.age>arenaCelebration.duration)clearArenaCelebration(false);
}
function playCrowdCheer() {
  if(!soundEnabled||!audio)return;
  try {
    if(!cheerBuffer) {
      cheerBuffer=audio.createBuffer(1,Math.floor(audio.sampleRate*.9),audio.sampleRate);
      const data=cheerBuffer.getChannelData(0);
      for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*(.6+.4*Math.sin(i/audio.sampleRate*34));
    }
    const source=audio.createBufferSource(),filter=audio.createBiquadFilter(),gain=audio.createGain();
    source.buffer=cheerBuffer;filter.type='lowpass';filter.frequency.value=1800;
    gain.gain.setValueAtTime(.001,audio.currentTime);gain.gain.linearRampToValueAtTime(.075,audio.currentTime+.1);
    gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+.9);
    source.connect(filter);filter.connect(gain);gain.connect(audio.destination);source.start();
  }catch{}
}
function drawArenaCrowd(c) {
  const party=arenaCelebration|| (arenaHype()>.2?{team:scores[0]>=scores[1]?0:1,age:elapsed,clutch:true,points:3}:null);if(!party)return;
  const team=selectedTeam(party.team),bounce=reducedMotion?0:Math.sin(party.age*(party.clutch?27:21))*(party.clutch?1.5:1);
  for(let i=0;i<87;i++) {
    const x=i*11+3,y=(i%2?2:-1)-Math.max(0,bounce+(i%3)*.3)*2;
    const shirt=i%3?team.primary:team.accent;
    rect(c,x-2,y+5,2,7,shirt);rect(c,x+7,y+5,2,7,shirt);
    rect(c,x-2,y+3,2,3,['#c6a082','#926348','#d1ad88','#785541'][i%4]);
    rect(c,x+7,y+3,2,3,['#c6a082','#926348','#d1ad88','#785541'][i%4]);
  }
  rect(c,COURT.left,23,COURT.right-COURT.left,9,team.primary);
  for(let i=0;i<4;i++)pixelText(c,party.clutch?'MAKE SOME NOISE':party.points===3?'THREE!  +3':'BUCKET!  +2',COURT.left+42+i*210,25,1,team.accent);
  rect(c,395,48,191,15,team.primary);pixelText(c,party.clutch?'ONE POSSESSION GAME':party.points===3?'THREE POINTER':'TWO POINTS',490,52,1,'#fff5df',true);
}

// League identity stays separate from each on-court instance and its match statistics.
const TEAM_MAP=new Map(LEAGUE.teams.map(t=>[t.id,t]));
const logoImages=new Map();
let hudPlayerKey='';
const SKILL_NAMES={three:'3-POINT',finish:'FINISHING',block:'BLOCKING',handles:'HANDLES',pass:'PASSING',speed:'SPEED',rebound:'REBOUND',defense:'DEFENSE'};
function selectedTeam(side) { return TEAM_MAP.get(preferences.teams[side]) || TEAM_MAP.get(side?'LAL':'NYK'); }
function selectedProfile(side) {
  if(careerMatch)return careerManager.player(careerMatch.lineups[side][0]);
  const team=selectedTeam(side),id=preferences.captains[side];
  return LEAGUE.players[team.roster.includes(Number(id))?id:team.starters[0]];
}
function selectedLineup(side) {
  if(careerMatch)return [...careerMatch.lineups[side]];
  const team=selectedTeam(side),p=selectedProfile(side),lineup=[...team.starters];
  if(!lineup.includes(p.id)) {
    let index=lineup.findIndex(id=>LEAGUE.players[id].position===p.position);
    if(index<0)index=0;
    lineup[index]=p.id;
  }
  return lineup;
}
function heightRatio(p) { return (p?.heightIn||78)/78; }
function skill(p,key) { return p?.ratings?.[key] || 3.5; }
function layupRange(p) { return 35+skill(p,'finish')*4+(heightRatio(p)-1)*65; }
function shotJumpSpeed(p) { return distance(p,HOOPS[p.team?0:1])<layupRange(p)?210:SHOT_JUMP_SPEED; }
function shotReach(p) { return (distance(p,HOOPS[p.team?0:1])<layupRange(p)?52:43)*PLAYER_SCALE/1.3*heightRatio(p); }
function shootingSkill(p) {
  if(!p)return 3.5;
  if(p.preview)return skill(p,'three');
  const d=distance(p,HOOPS[p.team?0:1]);
  return d<layupRange(p)?skill(p,'finish'):d>230?skill(p,'three'):(skill(p,'finish')+skill(p,'three'))/2;
}
function nbaLook(p) {
  const profile=p.nbaId?careerManager.player(p.nbaId):p,team=selectedTeam(p.team);
  const home=selectedTeam(0);
  const colorGap=Math.hypot(...[1,3,5].map(i=>parseInt(home.primary.slice(i,i+2),16)-parseInt(team.primary.slice(i,i+2),16)));
  const alternate=p.team && colorGap<100;
  return {name:profile.name,number:profile.number,jersey:alternate?'#eeeae1':team.primary,
    trim:alternate?team.primary:team.accent,skin:profile.skin,hair:profile.hair,
    hairstyle:profile.hairstyle,shoes:p.team?'#e4e8ea':'#f3eee5',gear:'none'};
}
function applyNBALook(p) {
  const look=nbaLook(p),profile=careerManager.player(p.nbaId);
  Object.assign(p,{name:look.name,number:look.number,color:look.jersey,dark:shade(look.jersey,.6),
    trim:look.trim,skin:look.skin,hair:look.hair,hairstyle:look.hairstyle,gear:look.gear,shoes:look.shoes,beard:profile.beard});
  return p;
}
function makeNBAPlayer(team,slot,id,nbaId) {
  const profile=careerManager.player(nbaId),p=makePlayer(team,slot,id,'ace',false);
  Object.assign(p,{nbaId:profile.id,shortName:profile.shortName,position:profile.position,heightIn:profile.heightIn,
    height:profile.height,ratings:profile.ratings,speed:103+profile.ratings.speed*12});
  return applyLook(p);
}
function finishPeriod() {
  players.forEach(p=>{p.pendingShot=null;p.charging=false;p.blockBuffer=0;});
  if(!overtime&&!quarterLines.some(row=>row.label==='Q'+currentQuarter))quarterLines.push({label:'Q'+currentQuarter,scores:scores.map((score,i)=>score-periodStartScores[i])});
  if(currentQuarter<totalQuarters&&!overtime){
    phase='break';periodEnding=false;buzzerAge=0;clearInputs();
    quarterBreak={age:0,duration:currentQuarter===2?4:2.8};$('quarter-overlay').hidden=false;
    $('quarter-eyebrow').textContent='END OF QUARTER '+currentQuarter;$('quarter-heading').textContent=currentQuarter===2?'HALFTIME.':'QUARTER COMPLETE.';
    $('quarter-score').textContent=selectedTeam(0).id+' '+scores[0]+' — '+scores[1]+' '+selectedTeam(1).id;
    $('quarter-copy').textContent='Quarter '+(currentQuarter+1)+' starts with '+selectedTeam(currentQuarter===1||currentQuarter===2?1:0).nickname+' inbounding.';
    tone(100,.25);updateScoreboard();return;
  }
  if(scores[0]===scores[1]){
    overtime=true;periodEnding=false;buzzerAge=0;finishingPoint=false;periodStartScores=[...scores];
    beginInbound(0,'OVERTIME · NEXT BASKET WINS');announce('OVERTIME / NEXT BASKET WINS',1.8);
  }else endMatch();
}
function persistLeague() { try {localStorage.setItem(LOOK_KEY,JSON.stringify(preferencesForStorage()));}catch{} }
function initializeLeague() {
  for(let side=0;side<2;side++) {
    const teamSelect=$('team-select-'+side),playerSelect=$('player-select-'+side);
    teamSelect.innerHTML=LEAGUE.teams.map(t=>'<option value="'+t.id+'">'+t.name+'</option>').join('');
    teamSelect.value=selectedTeam(side).id;
    teamSelect.addEventListener('change',()=>{
      preferences.teams[side]=teamSelect.value;preferences.captains[side]=null;persistLeague();showLobby();
    });
    playerSelect.addEventListener('change',()=>{
      preferences.captains[side]=Number(playerSelect.value);persistLeague();showLobby();
    });
  }
  if(typeof Image!=='undefined')for(const team of LEAGUE.teams) {
    const image=new Image();logoImages.set(team.id,image);
    image.onload=()=>{if(team.id===selectedTeam(0).id)applyCourtSettings();};
    image.src=team.logo;
  }
}
function refreshTeamUI() {
  for(let side=0;side<2;side++) {
    const team=selectedTeam(side),profile=selectedProfile(side),select=$('player-select-'+side);
    $('team-select-'+side).value=team.id;
    select.innerHTML=team.roster.map(id=>{const p=LEAGUE.players[id];return '<option value="'+id+'">'+p.name+' · '+p.position+' · '+p.height+'</option>';}).join('');
    select.value=String(profile.id);
    $('team-logo-'+side).src=team.logo;$('team-logo-'+side).alt=team.name+' logo';
    $('lineup-'+side).innerHTML=selectedLineup(side).map(id=>{
      const p=LEAGUE.players[id];return '<span class="lineup-player'+(id===profile.id?' chosen':'')+'"><b>'+p.position+'</b><span>'+p.shortName+'</span><small>'+p.height+'</small></span>';
    }).join('');
    const portrait=$('team-portrait-'+side),c=portrait.getContext('2d');
    c.clearRect(0,0,64,72);c.imageSmoothingEnabled=false;
    drawBaller(c,makeNBAPlayer(side,0,-1,profile.id),32,68,1.9*heightRatio(profile));
  }
  $('league-count').textContent=LEAGUE.teams.length+' TEAMS · '+Object.keys(LEAGUE.players).length+' PLAYERS';
  $('opponent-picker').hidden=selectedMode==='practice';
}
function updatePlayerHUD() {
  const p=selectedMode==='watch'?(players[ball.owner]||active()):active();if(!p)return;
  const key=p.id+':'+p.name+':'+p.nbaId+':'+preferences.customCaptain;
  if(key===hudPlayerKey)return;hudPlayerKey=key;
  $('player-hud-name').textContent=p.name;
  $('player-hud-meta').textContent=p.position+' · '+p.height+' · #'+p.number;
  const priority=Object.keys(SKILL_NAMES);
  const top=priority.map(key=>({key,value:skill(p,key)})).sort((a,b)=>b.value-a.value||priority.indexOf(a.key)-priority.indexOf(b.key)).slice(0,3);
  $('player-skill-list').innerHTML=top.map(s=>'<div class="skill-line"><span>'+SKILL_NAMES[s.key]+'</span><span class="stars" aria-label="'+s.value+' out of 5 stars"><span>★★★★★</span><b style="width:'+s.value*20+'%">★★★★★</b></span><strong>'+s.value.toFixed(1)+'/5</strong></div>').join('');
}
function updatePlayerLabels(visible) {
  syncPlayerLabelProjection();
  const layer=$('player-label-layer');
  layer.hidden=!preferences.nameTags;$('name-tags').checked=preferences.nameTags;
  if(!preferences.nameTags){for(const label of playerLabelNodes)label.node.hidden=true;return;}
  if(playerLabelNodes.length!==players.length) {
    layer.innerHTML='';
    playerLabelNodes=players.map(()=>{
      const node=document.createElement('div'),name=document.createElement('span'),position=document.createElement('b');
      node.className='player-nameplate';name.className='player-name';position.className='player-position';
      node.appendChild(position);node.appendChild(name);layer.appendChild(node);
      return {node,name,position};
    });
  }
  const shown=new Set(visible.map(p=>p.id)),placed=[];
  for(const p of players) {
    const label=playerLabelNodes[p.id];label.node.hidden=!shown.has(p.id);if(label.node.hidden)continue;
    const selected=p.id===controlled[0]||selectedMode==='two'&&p.id===controlled[1];
    const name=selected?p.name:p.slot===0&&preferences.customCaptain?p.name:p.shortName;
    if(label.name.textContent!==name)label.name.textContent=name;
    if(label.position.textContent!==p.position)label.position.textContent=p.position;
    label.node.className='player-nameplate'+(selected?' selected':'');
    label.node.style.borderLeftColor=p.trim;
    const width=Math.min(150,35+name.length*4.5),x=clamp(p.x,width/2,W-width/2);
    let y=p.y+13;
    for(let tries=0;tries<3;tries++) {
      if(!placed.some(q=>Math.abs(q.x-x)<(q.width+width)/2&&Math.abs(q.y-y)<12))break;
      y+=12;
    }
    y=Math.min(H-21,y);placed.push({x,y,width});
    label.node.style.left=(x/W*100).toFixed(3)+'%';label.node.style.top=(y/H*100).toFixed(3)+'%';
  }
}
function syncPlayerLabelProjection() {
  const stage=$('stage'),layer=$('player-label-layer');
  if(!stage.getBoundingClientRect)return;
  const rect=stage.getBoundingClientRect(),expanded=isExpanded();
  const key=rect.width+':'+rect.height+':'+expanded;
  if(layer.dataset.projection===key)return;
  layer.dataset.projection=key;
  const scale=Math.min(rect.width/W,rect.height/H);
  const width=expanded?W*scale:rect.width,height=expanded?H*scale:rect.height;
  Object.assign(layer.style,{left:(rect.width-width)/2+'px',top:(rect.height-height)/2+'px',right:'auto',bottom:'auto',width:width+'px',height:height+'px'});
}


function preferencesForStorage() {
  return careerMatch&&quickSetup?{...preferences,teams:quickSetup.teams,captains:quickSetup.captains,customCaptain:quickSetup.customCaptain}:preferences;
}
function selectedCourtTeam() {return careerMatch?careerManager.team(careerMatch.courtTeamId):selectedTeam(0);}
function recordShotAttempt(p,value) {
  p.box.fga++;if(value===3)p.box.tpa++;
  return p.lastPass&&matchLiveSeconds-p.lastPass.time<=5?p.lastPass.from:null;
}
function recordMadeBasket(p,points) {
  p.box.pts+=points;p.box.fgm++;if(points===3)p.box.tpm++;
  const helper=ball.shot?.assistId;
  if(helper!=null&&helper!==p.id&&players[helper]?.team===p.team)players[helper].box.ast++;
  players.forEach(m=>{if(selectedMode!=='practice'||m.team===0)m.box.plusMinus+=m.team===p.team?points:-points;});
}
function recordPossession(p) {
  p.lastPass=ball.pass?.team===p.team&&ball.pass.from!==p.id?{from:ball.pass.from,time:matchLiveSeconds}:null;
  if(ball.owner==null&&ball.rebound&&ball.reboundTeam!=null) {
    p.box.reb++;p.box[p.team===ball.reboundTeam?'oreb':'dreb']++;
  }
  if(ball.stealCredit!=null&&players[ball.stealCredit]?.team===p.team) {
    players[ball.stealCredit].box.stl++;if(players[ball.turnoverPlayer])players[ball.turnoverPlayer].box.tov++;
  }
}
function buildMatchBox(final=false) {
  return {label:careerMatch?.label||(selectedMode==='practice'?'Shootaround':teamSize+'v'+teamSize+' arcade match'),
    final,quarters:totalQuarters,quarterScores:periodBreakdown(),simulated:false,duration:matchLiveSeconds,overtime,teams:[0,1].map(side=>{
      const team=selectedTeam(side),pool=careerMatch?careerMatch.rosters[side]:team.roster;
      const activePlayers=players.filter(p=>p.team===side);
      const ids=[...activePlayers.map(p=>p.nbaId),...pool.filter(id=>!activePlayers.some(p=>p.nbaId===id))];
      return {teamId:team.id,score:scores[side],players:ids.map(id=>{
        const profile=careerManager.player(id),p=activePlayers.find(p=>p.nbaId===id);
        return {...profile,name:p?.name||profile.name,number:p?.number||profile.number,starter:!!p,stats:p?{...p.box}:emptyBoxStats()};
      })};
    })};
}
function finishBoxAndCareer() {
  const box=buildMatchBox(true);lastBoxScore=box;
  try {localStorage.setItem('rimrush-last-box-v1',JSON.stringify(box));}catch{}
  if(careerMatch&&!careerMatch.completed) {
    try {
      careerManager.submit(careerMatch,box);careerMatch.completed=true;
      $('rematch-button').textContent=careerMatch.mode==='tournament'?'BACK TO THE BRACKET →':'CONTINUE FRANCHISE →';
      $('career-result-note').textContent=careerManager.warning||'Result and full box score saved to your '+careerMatch.mode+'.';
    }catch(err){$('career-result-note').textContent=err.message;}
  }
}
function playCareerMatch(context,watch=false) {
  if(!quickSetup)quickSetup={teams:[...preferences.teams],captains:[...preferences.captains],customCaptain:preferences.customCaptain,
    mode:selectedMode,quarters:$('quarter-count').value,duration:$('duration').value,size:$('team-size').value,difficulty:$('difficulty').value};
  careerMatch={...context,completed:false};preferences.teams=[...context.teams];preferences.captains=[...context.lineups.map(ids=>ids[0])];preferences.customCaptain=false;
  selectedMode=watch?'watch':'cpu';$('quarter-count').value=String(context.options.quarters||1);$('team-size').value='5';$('duration').value=String(context.options.duration);$('difficulty').value=context.options.difficulty;
  startMatch();
}
function returnToMenu() {
  if(onlineMatch){onlineParty.leave();return;}
  watchBetView?.abandon();
  const careerMode=careerMatch?.mode;
  if(quickSetup) {
    preferences.teams=quickSetup.teams;preferences.captains=quickSetup.captains;preferences.customCaptain=quickSetup.customCaptain;
    selectedMode=quickSetup.mode;$('quarter-count').value=quickSetup.quarters;$('duration').value=quickSetup.duration;$('team-size').value=quickSetup.size;$('difficulty').value=quickSetup.difficulty;
  }
  careerMatch=null;quickSetup=null;lobbyScreen='home';showLobby();
  if(careerMode)careerView.open(careerMode);
}
function initializeCareerFeatures() {
  boxScoreView=createBoxScoreView({live:()=>phase==='lobby'&&lastBoxScore?lastBoxScore:buildMatchBox(phase==='over'),
    isPlaying:isMatchRunning,pause:pauseGame,resume:resumeGame,team:id=>careerManager.team(id)});
  careerView=createCareerView(careerManager,{playGame:playCareerMatch,openBox:box=>boxScoreView.open(box)});
  $('box-open').addEventListener('click',()=>boxScoreView.open());
  $('result-box-open').addEventListener('click',()=>boxScoreView.open(lastBoxScore));
  $('open-tournament').addEventListener('click',()=>careerView.open('tournament'));
  $('open-franchise').addEventListener('click',()=>careerView.open('franchise'));
}

function drawArcadePortraits(now) {
  if(phase!=='lobby'||lobbyScreen!=='home')return;
  for(let side=0;side<2;side++) {
    const pen=$('menu-portrait-'+side).getContext('2d'),p={...captain(side),preview:true,previewClock:now/1000,previewContest:0,
      x:0,y:0,z:0,vx:0,vy:0,walk:0,charging:false,pendingShot:null,shootPose:0,blockTime:0,blockPose:0,dunk:null,
      dribbleCycle:now/1000*1.65,hand:side?-1:1,face:side?-1:1,celebrateTime:0,moveKind:null,landing:0};
    pen.clearRect(0,0,280,400);pen.imageSmoothingEnabled=false;
    const g=pen.createRadialGradient(140,230,15,140,230,155);g.addColorStop(0,p.trim+'88');g.addColorStop(1,'#ffffff00');pen.fillStyle=g;pen.fillRect(0,0,280,400);
    pen.fillStyle='#41264c66';pen.beginPath();pen.ellipse(140,360,62,13,0,0,Math.PI*2);pen.fill();
    const scale=7.6*heightRatio(p);drawBaller(pen,p,140,345,scale);
    const pos=handleBallPosition(p),factor=scale/(PLAYER_SCALE*heightRatio(p));
    drawBasketball(pen,140+pos.x*factor,345+(pos.y-pos.z)*factor,now/1000*5,preferences.ball,false,BALL_RADIUS/3*factor);
    $('menu-star-'+side).textContent=p.name.toUpperCase();
  }
}
function setLobbyScreen(screen) {
  lobbyScreen=screen;$('arcade-menu').hidden=screen!=='home';$('lobby').hidden=screen==='home';
  $('stage').classList.toggle('home-active',screen==='home');watchBetView?.render();
}
function selectQuickMode(mode='cpu') {
  selectedMode=mode;lobbyScreen='setup';
  document.querySelectorAll('[data-mode]').forEach(b=>{const chosen=b.dataset.mode===mode;b.classList.toggle('selected',chosen);b.setAttribute('aria-pressed',String(chosen));});
  $('difficulty').disabled=false;$('duration').disabled=mode==='practice';$('team-size').disabled=mode==='practice';$('quarter-count').disabled=mode==='practice';showLobby();
}
function updateShopWallet(){ $('menu-coins').textContent=animationShop.state.coins.toLocaleString(); }
function earnCoins(amount){if(onlineMatch)return;animationShop.earn(amount);updateShopWallet();}
function startShotCelebration(p,points) {
  const local=animationShop.state,remote=onlineMatch?.effects[p.team],state=remote?{equipped:remote.id,trigger:remote.trigger,effectScale:remote.scale}:local;
  if(state.equipped==='none'||p.team!==0&&selectedMode!=='two'&&selectedMode!=='watch'||state.trigger==='threes'&&points!==3)return;
  const h=HOOPS[p.team?0:1];shotEffect={id:state.equipped,scale:state.effectScale,points,age:0,x:h.x,y:h.y-h.z,duration:EFFECT_DURATION};
  pointTime=Math.max(pointTime,EFFECT_DURATION+.08);
}
function initializeArcadeMenu() {
  animationShopView=createAnimationShopView(animationShop,{isPlaying:isMatchRunning,pause:pauseGame,resume:resumeGame,onChange:updateShopWallet});
  $('game-cabinet').appendChild($('animation-shop-dialog'));
  $('menu-quick').addEventListener('click',()=>selectQuickMode('cpu'));
  $('menu-training').addEventListener('click',()=>selectQuickMode('practice'));
  $('setup-back').addEventListener('click',()=>setLobbyScreen('home'));
  $('menu-shop').addEventListener('click',()=>animationShopView.open());$('shop-open').addEventListener('click',()=>animationShopView.open());
  $('menu-locker').addEventListener('click',openLocker);updateShopWallet();
}

function isMatchRunning(){return ['live','point','inbound','break','replay'].includes(phase);}
function captureWorld(){return {players,ball,scores,time:elapsed,handBall:handleBallPosition};}
function matchAtmosphere(){return {scores,remaining,quarter:currentQuarter,totalQuarters,quarterSeconds,overtime,mode:selectedMode};}
function periodBreakdown(){
  const rows=quarterLines.map(row=>({label:row.label,scores:[...row.scores]}));
  const label=overtime?'OT':'Q'+currentQuarter;
  if(!rows.some(row=>row.label===label))rows.push({label,scores:scores.map((score,i)=>score-periodStartScores[i])});
  return rows;
}
function resetMatchFlow(){
  currentQuarter=1;totalQuarters=selectedMode==='practice'?1:Number($('quarter-count').value)===4?4:1;
  quarterSeconds=Number($('duration').value);quarterLines=[];periodStartScores=[0,0];
  inboundState=null;quarterBreak=null;pendingAutoReplay=false;replayReturnPhase=null;possessionPasses=[0,0];
  presentation.reset();$('replay-open').disabled=true;
  for(const id of ['quarter-overlay','inbound-banner','replay-banner','crowd-hype'])$(id).hidden=true;
  $('stage').classList.remove('is-replay','is-clutch');$('game-cabinet').classList.toggle('watching',selectedMode==='watch');
}
function beginInbound(team,reason='AFTER THE BASKET',baseline=null){
  resetCourt(team);presentation.newPossession();possessionPasses[team]=0;
  const left=baseline==null?team===0:baseline==='left',x=left?COURT.left-13:COURT.right+13,sign=left?1:-1;
  const mates=players.filter(p=>p.team===team),inbounder=mates.length>1?mates[mates.length-1]:null;
  const receiver=mates[0];
  for(const p of players){
    p.lastPass=null;p.possessionAge=0;p.aiDecision=.25;p.aiPassCooldown=.7;
    if(p.team===team){p.x=x+sign*(83+p.slot*35);p.y=clamp(COURT.cy+[0,-105,113,-56,66][p.slot],130,448);}
    else {p.x=x+sign*(146+p.slot*38);p.y=clamp(COURT.cy+[25,-84,93,-43,60][p.slot],130,448);}
  }
  if(inbounder){inbounder.x=x;inbounder.y=COURT.cy+64;inbounder.inbounding=true;inbounder.passPose=1;controlled[team]=inbounder.id;}
  ball={x:x+sign*7,y:COURT.cy+64,z:29,vx:0,vy:0,vz:0,owner:inbounder?.id??null,age:0,spin:0,lock:.15,shot:null,pass:null,lastTeam:team};
  inboundState={team,reason,baseline:left?'left':'right',inbounder:inbounder?.id??null,receiver:receiver.id,x,sign,age:0,released:false,flightAge:0};
  phase='inbound';clearInputs();shotClock=24;periodEnding=false;finishingPoint=false;
  $('inbound-banner').hidden=false;$('inbound-team').textContent=selectedTeam(team).name;
  const human=selectedMode!=='watch'&&(team===0||selectedMode==='two');
  const ownInbound=human&&(!onlineMatch||team===(onlineMatch.role==='host'?0:1));
  $('inbound-button').hidden=!ownInbound;$('inbound-instruction').textContent=ownInbound?(onlineMatch||team===0?'Q / SPACE to pass in':'R SHIFT / ENTER to pass in'):onlineMatch?'Waiting for your opponent to inbound…':'Finding the open receiver…';
  $('inbound-tag').textContent=reason;$('inbound-count').textContent='5';
  setStatus(selectedTeam(team).id+' inbound. The game clock starts on the catch.');updateScoreboard();
}
function releaseInbound(){
  if(onlineMatch?.role==='guest'&&!applyingOnlineInput){onlineParty.input('pass',true);onlineParty.input('pass',false);return;}
  if(onlineMatch?.role==='host'&&inboundState?.team!==0&&!applyingOnlineInput)return;
  const state=inboundState;if(phase!=='inbound'||!state||state.released)return;
  const mates=players.filter(p=>p.team===state.team&&p.id!==state.inbounder);
  const receiver=mates.sort((a,b)=>{
    const openness=p=>Math.min(...players.filter(d=>d.team!==p.team).map(d=>distance(d,p)))+(p.position==='PG'?12:0)-Math.abs(p.x-state.x)*.06;
    return openness(b)-openness(a);
  })[0]||players[state.receiver];
  const from=state.inbounder==null?null:players[state.inbounder];
  if(from){phase='live';passBall(from,receiver);phase='inbound';if(!ball.pass)return;ball.pass.interceptionAllowed=false;ball.pass.inbound=true;from.inbounding=false;}
  else {
    const t=.35;ball={x:state.x+state.sign*7,y:COURT.cy+64,z:29,vx:(receiver.x-state.x-state.sign*7)/t,vy:(receiver.y-COURT.cy-64)/t,vz:(12-29+.5*BALL_G*t*t)/t,
      owner:null,age:0,spin:0,lock:.1,shot:null,pass:{team:state.team,from:null,target:receiver.id,duration:t,interceptionAllowed:false,inbound:true},lastTeam:state.team};
  }
  state.released=true;state.receiver=receiver.id;state.flightAge=0;
  $('inbound-instruction').textContent='BALL IN THE AIR · CLOCK STOPPED';$('inbound-button').hidden=true;
}
function stepInbound(dt){
  const state=inboundState;if(!state)return;
  state.age+=dt;
  if(state.released){state.flightAge+=dt;if(state.inbounder!=null){const from=players[state.inbounder];from.x+=state.sign*Math.min(75*dt,Math.max(0,Math.abs(state.x+state.sign*45-from.x)));from.walk+=dt*6;}stepBall(dt);if(phase==='inbound'&&state.flightAge>1.5)setOwner(players[state.receiver]);return;}
  for(const p of players)if(p.id!==state.inbounder){
    const move=Math.sin(state.age*1.5+p.slot)*dt*10*(p.team===state.team?1:.5);p.y=clamp(p.y+move,130,448);p.walk+=Math.abs(move)*.1;
  }
  if(state.inbounder!=null){const p=players[state.inbounder];ball.x=p.x+state.sign*7;ball.y=p.y;ball.z=29;}
  $('inbound-count').textContent=String(Math.max(0,Math.ceil(5-state.age)));
  const human=selectedMode!=='watch'&&(state.team===0||selectedMode==='two');
  if(!human&&state.age>1.05)releaseInbound();
  else if(state.age>=5){if(state.inbounder!=null)players[state.inbounder].box.tov++;const baseline=state.baseline;beginInbound(1-state.team,'5-SECOND INBOUND VIOLATION',baseline);announce('INBOUND VIOLATION',1);}
}
function nextQuarter(){
  if(onlineMatch?.role==='guest'&&!applyingOnlineCommand){onlineParty.command('next');return;}
  if(phase!=='break')return;
  currentQuarter++;periodStartScores=[...scores];remaining=quarterSeconds;matchLength=quarterSeconds;
  quarterBreak=null;$('quarter-overlay').hidden=true;periodEnding=false;buzzerAge=0;pendingAutoReplay=false;
  beginInbound(currentQuarter===2||currentQuarter===3?1:0,'START OF QUARTER '+currentQuarter);
  tone(430,.1);
}
function concludeBasket(){
  if(finishingPoint){if(overtime)endMatch();else finishPeriod();}
  else if(selectedMode==='practice'){resetCourt(0);presentation.newPossession();phase='live';}
  else beginInbound(nextPossession);
}
function startInstantReplay(manual=false){
  if(manual&&onlineMatch&&!applyingOnlineCommand){onlineParty.command('replay');return true;}
  if(phase==='lobby'||phase==='paused'||phase==='replay'||!presentation.beginReplay())return false;
  replayReturnPhase=phase;phase='replay';clearInputs();$('replay-banner').hidden=false;$('stage').classList.add('is-replay');
  if(replayReturnPhase==='over')$('result-screen').hidden=true;
  const meta=presentation.replay.meta;$('replay-caption').textContent=meta.name+' · '+(meta.dunk?'DUNK':meta.points===3?'THREE POINTER':'BUCKET')+' +'+meta.points;
  $('replay-banner').dataset.manual=String(manual);updateScoreboard();return true;
}
function finishReplay(){
  if(onlineMatch?.role==='guest'&&!applyingOnlineCommand){onlineParty.command('skip');return;}
  if(phase!=='replay')return;
  presentation.endReplay();phase=replayReturnPhase||'point';replayReturnPhase=null;
  $('replay-banner').hidden=true;$('stage').classList.remove('is-replay');
  if(phase==='over')$('result-screen').hidden=false;
  canvas.focus({preventScroll:true});updateScoreboard();
}
function drawRecordedReplay(){
  const recorded=onlineMatch?.role==='guest'?networkReplayFrame:presentation.replayFrame();if(!recorded)return;
  const focus=recorded.ball,zoom=reducedMotion?1:1.22;
  const cx=clamp(focus.x, W/(2*zoom),W-W/(2*zoom)),cy=clamp(focus.y-focus.z*.35,H/(2*zoom),H-H/(2*zoom));
  ctx.save();ctx.translate(W/2,H/2);ctx.scale(zoom,zoom);ctx.translate(-cx,-cy);ctx.drawImage(backdrop,0,0);
  for(const p of [...recorded.players].filter(p=>selectedMode!=='practice'||p.team===0).sort((a,b)=>a.y-b.y)){
    ctx.fillStyle='#17243744';ctx.beginPath();ctx.ellipse(p.x,p.y,14,5,0,0,Math.PI*2);ctx.fill();
    drawBaller(ctx,p,p.x,p.y-p.z,PLAYER_SCALE*heightRatio(p),recorded.ball,recorded.time);
  }
  drawHoop(ctx,0);drawHoop(ctx,1);drawBasketball(ctx,focus.x,focus.y-focus.z,focus.spin,preferences.ball,false);drawHoop(ctx,0,true);drawHoop(ctx,1,true);ctx.restore();
}
function stepMatchAtmosphere(dt){
  if(presentation.step(dt,matchAtmosphere()))playCrowdCheer();
  const hype=arenaHype(),active=hype>.2&&phase!=='lobby'&&phase!=='over';
  $('stage').classList.toggle('is-clutch',active);$('crowd-hype').hidden=!active;
  if(active)$('crowd-hype').style.opacity=String(Math.min(1,hype+.25));
}
function updateMatchSettings(){
  preferences.quarters=Number($('quarter-count').value)===4?4:1;preferences.gameDuration=Number($('duration').value);
  preferences.replayMode=$('replay-mode').value;preferences.shootingMode=$('shooting-mode').value==='percentage'?'percentage':'timing';persistLeague();
  synchronizeShootingMode();updateDifficultyUI();
  $('duration-label').dataset.format=preferences.quarters===4?'quarter':'game';
}
function initializeMatchFeatures(){
  $('quarter-count').value=String(preferences.quarters);$('replay-mode').value=preferences.replayMode;$('duration').value=String(preferences.gameDuration);
  $('shooting-mode').value=preferences.shootingMode;synchronizeShootingMode();
  for(const id of ['quarter-count','replay-mode','shooting-mode'])$(id).addEventListener('change',()=>{updateMatchSettings();if(phase==='lobby')showLobby();});
  $('duration').addEventListener('change',updateMatchSettings);
  $('inbound-button').addEventListener('click',releaseInbound);$('quarter-next').addEventListener('click',nextQuarter);
  $('replay-skip').addEventListener('click',finishReplay);$('replay-open').addEventListener('click',()=>startInstantReplay(true));
  $('menu-watch').addEventListener('click',()=>selectQuickMode('watch'));
  $('name-tags').checked=preferences.nameTags;
  $('name-tags').addEventListener('change',()=>{preferences.nameTags=$('name-tags').checked;persistLeague();updatePlayerLabels(players);});
}

function percentageShooting(){return preferences.shootingMode==='percentage';}
function playerTraining(p){return p?.team===0&&selectedMode!=='watch'&&!onlineMatch?animationShop.state.upgrades:{timing:0,handles:0,conditioning:0};}
function synchronizeShootingMode(reset=false){
  $('shooting-mode').value=preferences.shootingMode;
  $('shooting-mode-hint').textContent=percentageShooting()?'Tap Space / SHOOT. NBA shooting by zone, adjusted for coverage and distance. No release timing.':'Hold Space / SHOOT, then release in green. Q / Space inbounds. Length is per quarter.';
  for(const button of document.querySelectorAll('[data-action]'))if(button.dataset.action==='shoot'){
    button.innerHTML='SHOOT<small>'+(percentageShooting()?'SPACE / TAP':'SPACE / HOLD')+'</small>';
    button.setAttribute('aria-label',percentageShooting()?'Tap to shoot using Real Player percentage':'Hold to charge and release to shoot');
  }
  if(reset){clearInputs();for(const p of players){p.charging=false;p.pendingShot=null;p.gather=0;}}
}
function updateShotChance(p){
  const panel=$('shot-probability');panel.hidden=!percentageShooting()||phase==='lobby'||phase==='over';if(panel.hidden||!p)return;
  const info=playerShotChance(p,HOOPS[p.team?0:1],shotContest(p));
  $('shot-chance-value').textContent=Math.round(info.chance*100)+'% SHOT CHANCE';
  $('shot-chance-zone').textContent=info.label+' · '+contestLabel(info.contest);
  $('shot-chance-source').textContent=info.estimated?'ESTIMATE · NO NBA SAMPLE':info.season+' '+info.source+' · '+(info.base*100).toFixed(1)+'% base';
}
function tryAnkleBreaker(p,defender,kind){
  if(defender.fallTime>0||defender.ankleCooldown>0||defender.z>4||distance(p,defender)>59)return false;
  const gap=distance(p,defender),training=playerTraining(p);
  const chance=clamp(.13+(skill(p,'handles')-3)*.055-(skill(defender,'defense')-3)*.035+(gap<38?.07:0)+(kind==='spin'?.025:0)+training.handles*.03,.055,.48);
  const roll=Math.random();
  if(roll>=chance){if(roll<chance+.18){defender.stunned=Math.max(defender.stunned,.2);defender.ankleCooldown=.8;}return false;}
  defender.fallDuration=1.15;defender.fallTime=defender.fallDuration;defender.ankleCooldown=4.5;defender.stunned=defender.fallDuration;
  const away=unit(defender.x-p.x,defender.y-p.y);defender.fallDirection=away.x<0?-1:1;
  defender.vx=away.x*46;defender.vy=away.y*46;defender.z=0;defender.vz=0;defender.grounded=true;
  defender.charging=false;defender.pendingShot=null;defender.blockTime=0;defender.blockPose=0;defender.blockBuffer=0;defender.stealWind=0;defender.moveKind=null;
  defender.dashX=0;defender.dashY=0;defender.navMark=null;p.energy=Math.min(1,p.energy+.06);
  burst(defender.x,defender.y-3,'#d8c4ff',7);announce('ANKLES! DOWN GOES '+(defender.shortName||defender.name).toUpperCase(),1.05);
  playCrowdCheer();tone(155,.11,'triangle');return true;
}
function separatePlayers(){
  if(selectedMode==='practice')return;
  for(let iteration=0;iteration<3;iteration++)for(let i=0;i<players.length;i++)for(let j=i+1;j<players.length;j++){
    const a=players[i],b=players[j];if(a.dunk||b.dunk||a.fallTime>0||b.fallTime>0||a.moveKind==='spin'||b.moveKind==='spin')continue;
    const gap=distance(a,b);if(gap>=28)continue;
    const normal=gap>.001?unit(b.x-a.x,b.y-a.y):{x:0,y:i%2?1:-1};
    const aMobility=isHuman(a)?.25:1,bMobility=isHuman(b)?.25:1,total=aMobility+bMobility,push=28-gap;
    a.x-=normal.x*push*aMobility/total;a.y-=normal.y*push*aMobility/total;b.x+=normal.x*push*bMobility/total;b.y+=normal.y*push*bMobility/total;
  }
  for(const p of players){p.x=clamp(p.x,COURT.left+15,COURT.right-15);p.y=clamp(p.y,COURT.top+28,COURT.bottom-9);}
}

const NETWORK_TEXT_IDS=['callout','play-state','quarter-eyebrow','quarter-heading','quarter-score','quarter-copy','quarter-break-time','inbound-tag','inbound-team','inbound-instruction','inbound-count','replay-caption','arena-celebration-value','arena-celebration-type','arena-celebration-name','result-title','result-eyebrow','final-score','result-message','result-buckets','result-steals','result-dunks'];
function arenaHype(){return onlineMatch?.role==='guest'?networkHype:presentation.hype;}
function routeOnlineInput(side,action,pressed){
  if(!onlineMatch||applyingOnlineInput)return false;
  if(side!==0)return true;
  if(onlineMatch.role==='guest'){
    const charge=action==='shoot'&&!pressed?active().charge:undefined;
    onlineParty.input(action,pressed,charge);return true;
  }
  return false;
}
function applyOnlineCommand(command){
  if(onlineMatch?.role!=='host')return;
  applyingOnlineCommand=true;
  try{
    if(command==='pause')pauseGame();
    if(command==='resume'&&onlineParty.room?.host.connected&&onlineParty.room?.guest?.connected)resumeGame();
    if(command==='next')nextQuarter();
    if(command==='replay')startInstantReplay(true);
    if(command==='skip')finishReplay();
  }finally{applyingOnlineCommand=false;}
}
function applyOnlineInput(packet){
  if(onlineMatch?.role!=='host'||packet.seq<=networkInputSequence||!Array.isArray(packet.held))return;
  networkInputSequence=packet.seq;applyingOnlineInput=true;
  try{
    const wanted=new Set(packet.held.filter(action=>['up','down','left','right','shoot','pass','cross','behind','spin','stepback','block','jump','steal','switch','boost'].includes(action)));
    for(const action of [...inputs[1]])if(!wanted.has(action)){
      if(action==='shoot'&&Number.isFinite(packet.charge))active(1).charge=clamp(packet.charge,0,1.08);
      endAction(1,action);
    }
    for(const action of wanted)if(!inputs[1].has(action))beginAction(1,action);
    if(phase==='inbound'&&packet.action==='pass'&&packet.pressed)beginAction(1,'pass');
  }finally{applyingOnlineInput=false;}
}
const NETWORK_PLAYER_FIELDS=['id','team','slot','nbaId','x','y','z','vx','vy','vz','dirX','dirY','face','grounded','walk','charge','charging','cooldown','arm','shootPose','passPose','stamina','energy','hand','oldHand','dribbleCycle','moveKind','moveAge','moveLength','stunned','dunkTime','fallTime','fallDuration','fallDirection','box','passes','buckets','steals','dunks','blocks','shotJumped','pendingShot','releaseWindow','feedback','feedbackTime','blockTime','blockPose','blockCooldown','gather','lastCharge','dunk','celebrateTime','celebrateKind','previewBall'];
function packNetworkPlayer(p){return Object.fromEntries(NETWORK_PLAYER_FIELDS.filter(key=>p[key]!==undefined).map(key=>[key,p[key]]));}
function captureOnlineWorld(){
  const replay=presentation.replay?presentation.replayFrame():null;
  const snapshot={phase,previousPhase,players:players.map(packNetworkPlayer),ball,scores,remaining,elapsed,controlled,shotClock,matchLiveSeconds,currentQuarter,totalQuarters,quarterSeconds,quarterLines,periodStartScores,
    overtime,periodEnding,inboundState,quarterBreak,shotEffect,arenaCelebration,pointTime,rimImpulses,boardImpulses,particles,trail,
    bursts:presentation.bursts,hype:presentation.hype,replayFrame:replay?{...replay,players:replay.players.map(packNetworkPlayer)}:null,
    ui:Object.fromEntries(NETWORK_TEXT_IDS.map(id=>[id,$(id).textContent]))};
  return JSON.parse(JSON.stringify(snapshot,(_,value)=>typeof value==='number'?Math.round(value*1000)/1000:value));
}
function applyOnlineWorld(world,sequence){
  if(!onlineMatch||onlineMatch.role!=='guest'||sequence<=networkSequence||!Array.isArray(world.players)||world.players.length!==teamSize*2)return;
  const oldPhase=phase;networkSequence=sequence;networkReceivedAt=performance.now();
  const prior=players;
  players=world.players.map(p=>{
    const old=prior.find(item=>item.id===p.id),smooth=old&&distance(old,p)<130;
    return {...old,...p,x:smooth?old.x:p.x,y:smooth?old.y:p.y,z:smooth?old.z:p.z,networkTarget:{x:p.x,y:p.y,z:p.z,charge:p.charge}};
  });
  ball={...world.ball};scores=[...world.scores];remaining=world.remaining;elapsed=world.elapsed;controlled=[...world.controlled];shotClock=world.shotClock;matchLiveSeconds=world.matchLiveSeconds;
  currentQuarter=world.currentQuarter;totalQuarters=world.totalQuarters;quarterSeconds=world.quarterSeconds;quarterLines=world.quarterLines;periodStartScores=world.periodStartScores;
  overtime=world.overtime;periodEnding=world.periodEnding;inboundState=world.inboundState;quarterBreak=world.quarterBreak;pointTime=world.pointTime;
  shotEffect=world.shotEffect;arenaCelebration=world.arenaCelebration;rimImpulses=world.rimImpulses;boardImpulses=world.boardImpulses;particles=world.particles;trail=world.trail;
  networkBursts=world.bursts;networkHype=world.hype;networkReplayFrame=world.replayFrame?{...world.replayFrame,players:world.replayFrame.players.map(p=>({...players.find(current=>current.id===p.id),...p}))}:null;phase=world.phase;previousPhase=world.previousPhase;
  for(const [id,value]of Object.entries(world.ui||{}))if(NETWORK_TEXT_IDS.includes(id))$(id).textContent=value;
  for(const [id,state]of [['pause-screen','paused'],['result-screen','over'],['quarter-overlay','break'],['inbound-banner','inbound'],['replay-banner','replay']])$(id).hidden=phase!==state;
  $('arena-celebration').hidden=!arenaCelebration;$('crowd-hype').hidden=networkHype<.2;
  $('stage').classList.toggle('is-paused',phase==='paused');$('stage').classList.toggle('is-replay',phase==='replay'||phase==='paused'&&previousPhase==='replay');$('stage').classList.toggle('result-active',phase==='over');
  $('inbound-button').hidden=phase!=='inbound'||inboundState?.team!==1||inboundState?.released;
  if(phase==='inbound'&&!inboundState.released)$('inbound-instruction').textContent=inboundState.team===1?'Q / SPACE to pass in':'Waiting for your opponent to inbound…';
  if(String(world.ui?.['play-state']||'').startsWith('ONLINE · HOME'))$('play-state').textContent='ONLINE · AWAY · WASD / arrows · Space shoot · Q pass · E block · Alt switch.';
  $('replay-open').disabled=!world.replayFrame&&scores[0]+scores[1]===0;$('pause-button').disabled=phase==='over';$('pause-button').setAttribute('aria-label',phase==='paused'?'Resume game':'Pause game');
  if(phase==='over'&&oldPhase!=='over'){lastBoxScore=buildMatchBox(true);$('rematch-button').textContent='BACK TO PARTY →';onlineParty.finish({scores:[...scores]});}
  updateScoreboard();
}
let networkDrawTime=0;
function interpolateOnlineWorld(){
  if(onlineMatch?.role!=='guest')return;
  const now=performance.now(),dt=Math.min(.08,(now-networkDrawTime)/1000);networkDrawTime=now;
  if(phase==='paused'||phase==='over')return;
  for(const p of players)if(p.networkTarget){
    const factor=Math.min(1,dt*23);p.x+=(p.networkTarget.x-p.x)*factor;p.y+=(p.networkTarget.y-p.y)*factor;p.z+=(p.networkTarget.z-p.z)*factor;
    if(p.charging)p.charge=Math.min(1.08,p.networkTarget.charge+Math.min(.12,(now-networkReceivedAt)/1000)*SHOT_CHARGE_RATE);
  }
}
function startOnlineMatch(room,role){
  if(!onlineSetup)onlineSetup={teams:[...preferences.teams],captains:[...preferences.captains],customCaptain:preferences.customCaptain,shootingMode:preferences.shootingMode,mode:selectedMode,
    quarters:$('quarter-count').value,duration:$('duration').value,size:$('team-size').value,difficulty:$('difficulty').value};
  onlineMatch={id:room.id,role,gameId:room.gameId,effects:[room.host.effect,room.guest.effect]};networkSequence=-1;networkInputSequence=-1;networkBursts=[];networkReplayFrame=null;networkHype=0;
  careerMatch=null;selectedMode='two';preferences.teams=[room.host.team,room.guest.team];preferences.captains=[room.host.captain,room.guest.captain];preferences.customCaptain=false;preferences.shootingMode=room.settings.shootingMode;
  $('quarter-count').value=String(room.settings.quarters);$('duration').value=String(room.settings.duration);$('team-size').value=String(room.settings.size);$('difficulty').value=room.settings.difficulty;
  synchronizeShootingMode(true);startMatch();$('restart-button').disabled=true;
  setStatus('ONLINE · '+(role==='host'?'HOME':'AWAY')+' · WASD / arrows · Space shoot · Q pass · E block · Alt switch.');
}
function stopOnlineMatch(){
  onlineMatch=null;networkReplayFrame=null;networkBursts=[];networkHype=0;
  if(onlineSetup){preferences.teams=onlineSetup.teams;preferences.captains=onlineSetup.captains;preferences.customCaptain=onlineSetup.customCaptain;preferences.shootingMode=onlineSetup.shootingMode;selectedMode=onlineSetup.mode;
    $('quarter-count').value=onlineSetup.quarters;$('duration').value=onlineSetup.duration;$('team-size').value=onlineSetup.size;$('difficulty').value=onlineSetup.difficulty;onlineSetup=null;}
  $('restart-button').disabled=false;synchronizeShootingMode(true);lobbyScreen='home';showLobby();
}
function initializeOnlineParty(){
  $('game-cabinet').appendChild($('party-dialog'));
  onlineParty=createOnlineParty(LEAGUE,{selectedTeam:()=>selectedTeam(0).id,effect:()=>({id:animationShop.state.equipped,scale:animationShop.state.effectScale,trigger:animationShop.state.trigger}),
    onStart:startOnlineMatch,onWorld:applyOnlineWorld,onInput:applyOnlineInput,onCommand:applyOnlineCommand,onClosed:stopOnlineMatch,onWaiting:stopOnlineMatch,
    onRankResult:(profile,delta)=>{$('ranked-result-note').hidden=false;$('ranked-result-note').textContent=profile.rank.name.toUpperCase()+' · '+profile.points+' RP · '+(delta>=0?'+':'')+delta+' RP';},
    onConnectionLost:()=>{if(onlineMatch?.role==='host')applyOnlineCommand('pause');else if(onlineMatch){phase='paused';$('pause-screen').hidden=false;setStatus('Connection lost. Open ONLINE → RECONNECT.');}}});
  $('menu-online').addEventListener('click',()=>onlineParty.open());$('party-open').addEventListener('click',()=>onlineParty.open());
}

initializeUpgrades(); initializeLeague();
watchBetView=createWatchBetView(watchBets,{available:()=>selectedMode==='watch'&&!careerMatch&&!onlineMatch,teams:()=>[selectedTeam(0),selectedTeam(1)]});initializeMatchFeatures(); updateRecord(); showLobby();initializeCareerFeatures();initializeArcadeMenu();initializeOnlineParty();
for(const id of ['team-select-0','team-select-1'])$(id).addEventListener('change',()=>watchBetView.render());
if (touchDevice) $('lobby-tip').textContent = 'Four-way pad · Pass to teammates · Hold Shoot, release green';
let previousTime = performance.now(), accumulator = 0;
function frame(now) {
  accumulator += Math.min(onlineMatch?1:.05,(now - previousTime)/1000); previousTime = now;
  while (accumulator >= 1/120) { step(1/120); accumulator -= 1/120; }
  draw(); renderLockerPreview(now); drawArcadePortraits(now);animationShopView?.draw(now,reducedMotion);onlineParty?.tick(now,captureOnlineWorld);requestAnimationFrame(frame);
}
requestAnimationFrame(frame);




