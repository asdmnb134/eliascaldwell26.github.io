const $ = id => document.getElementById(id);
const canvas = $('court');
const ctx = canvas.getContext('2d');
ctx.imageSmoothingEnabled = false;

const W = 960;
const H = 540;
const FLOOR = 438;
const GRAVITY = 1450;
const BALL_G = 980;
const HOOPS = [
  { x: 104, y: 248 },
  { x: 856, y: 248 },
];
const ROSTER = {
  ace: {
    name: 'ACE',
    trait: 'THE ALL-ROUNDER',
    color: '#36a8ed',
    dark: '#165a9c',
    trim: '#e8f6ef',
    skin: '#d7a476',
    hair: '#372f2d',
    number: '7',
    speed: 264,
    jump: 690,
    accuracy: 1,
  },
  bolt: {
    name: 'BOLT',
    trait: 'QUICK FEET. QUICK BUCKETS.',
    color: '#ff8255',
    dark: '#bc413b',
    trim: '#ffe6bc',
    skin: '#aa6d49',
    hair: '#241f2b',
    number: '11',
    speed: 298,
    jump: 685,
    accuracy: 1.12,
  },
  tank: {
    name: 'TANK',
    trait: 'BIG JUMPS. BIG DUNKS.',
    color: '#b597ef',
    dark: '#644aa1',
    trim: '#f0e5ff',
    skin: '#82543e',
    hair: '#1d252d',
    number: '34',
    speed: 235,
    jump: 735,
    accuracy: 0.9,
  },
};

// PHYSICS_START
function launchVelocity(start, target, flight, gravity) {
  return {
    vx: (target.x - start.x) / flight,
    vy: (target.y - start.y - 0.5 * gravity * flight * flight) / flight,
  };
}
function basketCrossing(previous, current, hoop) {
  if (current.vy <= 0 || previous.y > hoop.y || current.y < hoop.y)
    return false;
  const ratio =
    (hoop.y - previous.y) / Math.max(0.00001, current.y - previous.y);
  const crossingX = previous.x + (current.x - previous.x) * ratio;
  return Math.abs(crossingX - hoop.x) < 17;
}
function shotPoints(playerX, targetX) {
  return Math.abs(playerX - targetX) > 315 ? 3 : 2;
}
// PHYSICS_END

let phase = 'lobby';
let previousPhase = 'live';
let selectedMode = 'cpu';
let selectedBaller = 'ace';
let players = [];
let ball = {};
let scores = [0, 0];
let remaining = 60;
let matchLength = 60;
let overtime = false;
let pointTime = 0;
let nextPossession = 0;
let finishingPoint = false;
let calloutTime = 0;
let particles = [];
let trail = [];
let shake = 0;
let elapsed = 0;
let soundEnabled = false;
let audio = null;
let record = { wins: 0, losses: 0 };
let resumeAfterHelp = false;
const inputs = [new Set(), new Set()];
const pointers = new Map();
const activeKeys = new Map();
const touchDevice =
  matchMedia('(pointer: coarse)').matches || innerWidth <= 640;
try {
  record = {
    ...record,
    ...JSON.parse(localStorage.getItem('rimrush-record') || '{}'),
  };
} catch {}


const LOOK_KEY = 'rimrush-locker-v2';
const COURTS = {
  downtown: { title: 'AFTER HOURS', subtitle: 'DOWNTOWN COURT' },
  sunset: { title: 'GOLDEN HOUR', subtitle: 'ROOFTOP COURT' },
  neon: { title: 'NEON NIGHTS', subtitle: 'THE DOME' }
};
function defaultLook(key = 'ace') {
  const base = ROSTER[key];
  return { name: base.name, number: base.number, jersey: base.color, trim: base.trim,
    skin: base.skin, hair: base.hair, shoes: '#e4e9da',
    hairstyle: key === 'bolt' ? 'curls' : key === 'tank' ? 'fade' : 'crop',
    gear: key === 'tank' ? 'headband' : 'none' };
}
function safeColor(value, fallback) {
  return typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value) ? value : fallback;
}
function normalizeLook(value, key = 'ace') {
  const base = defaultLook(key);
  if (!value || typeof value !== 'object') return null;
  return {
    name: String(value.name || base.name).replace(/[<>\x00-\x1f]/g, '').trim().slice(0, 12) || base.name,
    number: String(Math.max(0, Math.min(99, parseInt(value.number, 10) || 0))),
    jersey: safeColor(value.jersey, base.jersey), trim: safeColor(value.trim, base.trim),
    skin: safeColor(value.skin, base.skin), hair: safeColor(value.hair, base.hair),
    shoes: safeColor(value.shoes, base.shoes),
    hairstyle: ['crop', 'fade', 'curls', 'spikes', 'long', 'bald'].includes(value.hairstyle) ? value.hairstyle : base.hairstyle,
    gear: ['none', 'headband', 'sleeve', 'both'].includes(value.gear) ? value.gear : 'none'
  };
}
function loadPreferences() {
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(LOOK_KEY) || '{}') || {}; } catch {}
  return {
    looks: [normalizeLook(saved.looks?.[0]), normalizeLook(saved.looks?.[1], 'bolt')],
    court: COURTS[saved.court] ? saved.court : 'downtown',
    ball: ['classic', 'lime', 'ice'].includes(saved.ball) ? saved.ball : 'classic',
    shake: saved.shake !== false, guide: saved.guide !== false
  };
}
function shade(color, amount = .6) {
  const h = color.slice(1);
  return '#' + [0, 2, 4].map(i => Math.max(0, Math.min(255, Math.round(parseInt(h.slice(i, i + 2), 16) * amount))).toString(16).padStart(2, '0')).join('');
}
let preferences = loadPreferences();
let rimImpulses = [0, 0];
let ripples = [];
let ghosts = [];
let dunkAnimation = null;
let comboTime = 0;
let comboCount = 0;
let fullscreenBusy = false;
let editingPlayer = 0;
let lockerDraft = null;
let lockerOptions = null;
let lockerResume = false;
let previewClock = 0;

function applyLook(p, custom = true, override = null) {
  const look = override || (custom ? preferences.looks[p.id] || defaultLook(p.key) : defaultLook(p.key));
  p.name = look.name; p.number = look.number; p.color = look.jersey;
  p.dark = shade(look.jersey, .54); p.trim = look.trim; p.skin = look.skin;
  p.hair = look.hair; p.hairstyle = look.hairstyle; p.gear = look.gear; p.shoes = look.shoes;
  return p;
}

function dribbleMove(p, kind) {
  if (phase !== 'live') return false;
  if (ball.owner !== p.id) {
    if (p.id === 0) setStatus('Get the ball first, then show off your handles.');
    return false;
  }
  if (!p.grounded || p.charging || p.moveCooldown > 0 || p.stunned > 0) return false;
  const moves = {
    cross: { cost: 14, length: .34, cooldown: .5, speed: 150, label: 'CROSSOVER' },
    behind: { cost: 20, length: .46, cooldown: .68, speed: 185, label: 'BEHIND THE BACK' },
    spin: { cost: 27, length: .58, cooldown: .85, speed: 220, label: 'SPIN MOVE' }
  };
  const move = moves[kind];
  if (!move) return false;
  if (p.stamina < move.cost) {
    if (p.id === 0) setStatus('Handles need a breather. Let your stamina refill.');
    return false;
  }
  p.stamina -= move.cost;
  p.moveKind = kind; p.moveAge = 0; p.moveLength = move.length; p.moveCooldown = move.cooldown;
  p.oldHand = p.hand; p.hand *= -1;
  const direction = (inputs[p.id].has('right') ? 1 : 0) - (inputs[p.id].has('left') ? 1 : 0);
  p.dash = (direction || p.face) * move.speed;
  p.protected = kind === 'cross' ? .22 : move.length;
  comboCount = comboTime > 0 ? Math.min(5, comboCount + 1) : 1;
  comboTime = 1.7;
  p.moveCount++;
  const opponent = players[1 - p.id];
  if (selectedMode !== 'practice' && Math.abs(opponent.x - p.x) < 85 && opponent.cooldown > .25 && opponent.grounded) {
    opponent.stunned = .42; opponent.vx *= .15;
    announce('ANKLE BREAKER!', .7);
    p.energy = Math.min(1, p.energy + .08);
    burst(opponent.x, opponent.y - 36, '#8be9fb', 9);
  } else if (p.id === 0) {
    announce(move.label + (comboCount > 1 ? ' ×' + comboCount : ''), .48);
  }
  if (p.id === 0) {
    setStatus(move.label + ' · ' + Math.ceil(p.stamina) + '% stamina · ball protected during the move.');
  }
  tone(kind === 'spin' ? 210 : kind === 'behind' ? 310 : 420, .045, 'triangle', .026);
  return true;
}

function handleBallPosition(p) {
  if (p.charging) return { x: p.x + (p.id === 0 ? 14 : -14), y: p.y - 103, behind: false };
  if (!p.grounded) return { x: p.x + p.hand * 26, y: p.y - 77, behind: false };
  const t = p.dribbleCycle % 1;
  let x = p.x + p.hand * (28 + Math.sin(t * Math.PI * 2) * 3);
  let y = p.y - 76 + (1 - Math.pow(Math.abs(2 * t - 1), 2)) * 65;
  let behind = false;
  if (p.moveKind) {
    const q = Math.min(1, p.moveAge / p.moveLength);
    if (p.moveKind === 'cross') {
      x = p.x + (p.oldHand + (p.hand - p.oldHand) * q) * 33;
      y = p.y - 27 - 29 * Math.abs(q * 2 - 1);
    } else if (p.moveKind === 'behind') {
      x = p.x + Math.cos(q * Math.PI) * p.oldHand * 36;
      y = p.y - 42 - Math.sin(q * Math.PI) * 7;
      behind = q > .18 && q < .78;
    } else {
      x = p.x + Math.cos(q * Math.PI * 2) * p.hand * 33;
      y = p.y - 53 + Math.sin(q * Math.PI * 2) * 16;
      behind = q > .22 && q < .7;
    }
  }
  return { x, y, behind };
}

function updatePresentation(dt) {
  comboTime = Math.max(0, comboTime - dt);
  rimImpulses = rimImpulses.map(v => Math.max(0, v - dt * 1.5));
  ghosts = ghosts.filter(g => (g.life -= dt) > 0);
  ripples = ripples.filter(r => (r.life -= dt) > 0);
  for (const p of players) {
    p.shootPose = Math.max(0, p.shootPose - dt);
    p.squash = Math.max(0, p.squash - dt * 3);
    p.landDust = Math.max(0, p.landDust - dt);
    p.dribbleCycle += dt * (Math.abs(p.vx) > 40 ? 2.4 : 1.7);
    if (p.moveKind && !reducedMotion && Math.abs(p.vx) > 50 && phase === 'live') {
      p.ghostClock -= dt;
      if (p.ghostClock <= 0) {
        p.ghostClock = .05;
        ghosts.push({ player: { ...p }, x: p.x, y: p.y, life: .16 });
      }
    }
  }
  if (dunkAnimation) {
    const d = dunkAnimation;
    d.time += dt;
    const p = players[d.id];
    const hangX = d.hoop.x + (d.id === 0 ? -25 : 25);
    if (d.time < .2) {
      const t = 1 - Math.pow(1 - d.time / .2, 3);
      p.x = d.x + (hangX - d.x) * t;
      p.y = d.y + (d.hoop.y + 91 - d.y) * t;
    } else if (d.time < .54) {
      p.x = hangX; p.y = d.hoop.y + 91 + Math.sin(d.time * 30) * 2;
    } else {
      p.y = Math.min(FLOOR, d.hoop.y + 91 + Math.pow((d.time - .54) / .52, 2) * (FLOOR - d.hoop.y - 91));
      if (p.y >= FLOOR) { p.grounded = true; p.squash = .18; dunkAnimation = null; burst(p.x, FLOOR - 1, '#c0bd91', 6); }
    }
  }
}

function makePlayer(id, key, custom = true) {
  return applyLook({
    id, key, ...ROSTER[key], x: id === 0 ? 285 : 675, y: FLOOR, vx: 0, vy: 0,
    face: id === 0 ? 1 : -1, grounded: true, charge: .15, charging: false,
    cooldown: 0, arm: 0, walk: 0, energy: .35, aiWait: .9, aiRelease: .67,
    buckets: 0, steals: 0, dunks: 0, blocks: 0, shotCount: 0, moveCount: 0,
    stamina: 100, hand: id === 0 ? 1 : -1, oldHand: 1, dribbleCycle: 0,
    moveKind: null, moveAge: 0, moveLength: .34, moveCooldown: 0,
    protected: 0, dash: 0, stunned: 0, shootPose: 0, squash: 0,
    landDust: 0, ghostClock: 0, animationClock: 0
  }, custom);
}

function createPlayers() {
  const other = selectedBaller === 'bolt' ? 'tank' : 'bolt';
  players = [makePlayer(0, selectedBaller), makePlayer(1, other)];
}

function clearInputs() {
  for (const set of inputs) set.clear();
  activeKeys.clear();
  pointers.clear();
  for (const p of players) {
    p.charging = false;
    p.charge = 0.15;
  }
  document
    .querySelectorAll('[data-action]')
    .forEach(b => b.classList.remove('pressed'));
}

function resetCourt(owner) {
  players.forEach((p, i) => {
    p.x = i === 0 ? 285 : 675;
    p.y = FLOOR;
    p.vx = 0;
    p.vy = 0;
    p.grounded = true;
    p.charging = false;
    p.charge = 0.15;
    p.aiWait = 0.9;
    p.cooldown = 0.25;
    p.face = i === 0 ? 1 : -1;
    p.hand = p.face; p.moveKind = null; p.moveCooldown = 0; p.protected = 0;
    p.stunned = 0; p.dash = 0; p.dribbleCycle = 0; p.shootPose = 0;
  });
  ball = {
    x: players[owner].x + 26,
    y: FLOOR - 65,
    vx: 0,
    vy: 0,
    owner,
    lock: 0.2,
    shot: null,
    scored: false,
    age: 0,
    spin: 0,
  };
  trail = [];
  dunkAnimation = null; ghosts = []; ripples = [];
  clearInputs();
}

function setStatus(message) {
  if ($('play-state').textContent !== message)
    $('play-state').textContent = message;
}

function updateRecord() {
  $('record').innerHTML =
    'YOUR RECORD <b>' + record.wins + ' W / ' + record.losses + ' L</b>';
}

function updateScoreboard() {
  $('score-one').textContent = String(scores[0]).padStart(2, '0');
  $('score-two').textContent = String(scores[1]).padStart(2, '0');
  const t = Math.max(0, Math.ceil(remaining));
  $('clock').textContent =
    selectedMode === 'practice'
      ? '∞'
      : overtime
        ? 'OT'
        : String(Math.floor(t / 60)).padStart(2, '0') +
          ':' +
          String(t % 60).padStart(2, '0');
  $('period').textContent =
    selectedMode === 'practice'
      ? 'FREE PRACTICE'
      : overtime
        ? 'NEXT BUCKET WINS'
        : 'QUICK MATCH';
  $('name-one').textContent = players[0].name;
  $('name-two').textContent =
    selectedMode === 'practice' ? 'SOLO' : players[1].name;
  $('side-one').textContent = selectedMode === 'two' ? 'PLAYER 1' : 'YOU';
  $('side-two').textContent =
    selectedMode === 'two'
      ? 'PLAYER 2'
      : selectedMode === 'practice'
        ? 'NO TIMER'
        : 'CPU';
  $('mode-label').textContent =
    selectedMode === 'two'
      ? 'LOCAL 2 PLAYER'
      : selectedMode === 'practice'
        ? 'PRACTICE COURT'
        : '1 PLAYER VS CPU';
  $('boost-fill').style.width = Math.round(players[0].energy * 100) + '%';
  $('stamina-fill').style.width = Math.round(players[0].stamina) + '%';
  $('move-label').textContent = players[0].moveKind ? players[0].moveKind.toUpperCase() : players[0].stamina < 27 ? 'RECOVER' : 'READY';
  const owner = ball.owner;
  $('possession').textContent =
    phase === 'lobby'
      ? 'READY WHEN YOU ARE.'
      : phase === 'paused'
        ? 'MATCH PAUSED'
        : phase === 'over'
          ? 'FINAL BUZZER'
          : owner === 0
            ? 'YOUR BALL → ATTACK RIGHT'
            : owner === 1
              ? '← OPPONENT BALL'
              : 'LOOSE BALL — GO GET IT';
}

function announce(text, duration = 1.1) {
  $('callout').textContent = text;
  if (!reducedMotion && $('callout').animate) $('callout').animate([{ transform: 'translateY(6px) scale(.88)', opacity: .4 }, { transform: 'translateY(0) scale(1)', opacity: 1 }], { duration: 150, easing: 'ease-out' });
  calloutTime = duration;
}

function showLobby() {
  phase = 'lobby';
  $('lobby').hidden = false;
  $('pause-screen').hidden = true;
  $('result-screen').hidden = true;
  $('stage').classList.remove('result-active');
  $('stage').classList.add('lobby-active');
  $('pause-button').disabled = true;
  $('pause-button').setAttribute('aria-label', 'Pause game');
  $('callout').textContent = '';
  createPlayers();
  resetCourt(0);
  players[0].x = 633;
  players[1].x = 773;
  scores = [0, 0];
  remaining = Number($('duration').value);
  overtime = false;
  particles = [];
  updateScoreboard();
  setStatus('Choose a player and hit the court.');
}

function startMatch() {
  createPlayers();
  scores = [0, 0];
  remaining = Number($('duration').value);
  matchLength = remaining;
  overtime = false;
  finishingPoint = false;
  particles = [];
  resetCourt(0);
  phase = 'live';
  $('lobby').hidden = true;
  $('pause-screen').hidden = true;
  $('result-screen').hidden = true;
  $('stage').classList.remove('lobby-active', 'result-active');
  $('pause-button').disabled = false;
  $('pause-button').setAttribute('aria-label', 'Pause game');
  updateScoreboard();
  announce(
    selectedMode === 'practice' ? 'FIND YOUR SHOT.' : 'LET’S BALL!',
    1.1
  );
  setStatus(
    selectedMode === 'two'
      ? 'Player 1 attacks right. Player 2 attacks left. Shared keyboard.'
      : 'Hold Shoot, release in the green. Attack the right basket.'
  );
  canvas.focus({ preventScroll: true });
  if (soundEnabled) initAudio();
  tone(330, 0.08);
}

function pauseGame() {
  if (phase !== 'live' && phase !== 'point') return;
  previousPhase = phase;
  phase = 'paused';
  clearInputs();
  $('pause-screen').hidden = false;
  $('pause-button').setAttribute('aria-label', 'Resume game');
  setStatus('Paused. The clock and players are frozen.');
  updateScoreboard();
}

function resumeGame() {
  if (phase !== 'paused') return;
  phase = previousPhase;
  $('pause-screen').hidden = true;
  $('pause-button').setAttribute('aria-label', 'Pause game');
  clearInputs();
  setStatus('Back on the court. Make it count.');
  canvas.focus({ preventScroll: true });
}

function endMatch() {
  phase = 'over';
  $('stage').classList.add('result-active');
  clearInputs();
  $('result-screen').hidden = false;
  $('pause-screen').hidden = true;
  $('pause-button').disabled = true;
  const won = scores[0] > scores[1];
  $('result-title').textContent =
    selectedMode === 'two'
      ? won
        ? 'PLAYER 1 WINS.'
        : 'PLAYER 2 WINS.'
      : won
        ? 'YOU WIN.'
        : 'TOUGH GAME.';
  $('result-eyebrow').textContent = overtime
    ? 'OVERTIME WINNER'
    : 'FINAL BUZZER';
  $('final-score').textContent = scores[0] + ' — ' + scores[1];
  $('result-message').textContent = won
    ? 'Big buckets. Bragging rights earned.'
    : 'Every legend starts somewhere. Run it back.';
  $('result-buckets').textContent = players[0].buckets;
  $('result-steals').textContent = players[0].steals;
  $('result-dunks').textContent = players[0].dunks;
  if (selectedMode === 'cpu') {
    record[won ? 'wins' : 'losses'] += 1;
    try {
      localStorage.setItem('rimrush-record', JSON.stringify(record));
    } catch {}
    updateRecord();
  }
  $('callout').textContent = '';
  setStatus(
    (won ? 'You won! ' : 'Match over. ') +
      'Final score ' +
      scores[0] +
      ' to ' +
      scores[1] +
      '.'
  );
  updateScoreboard();
  tone(won ? 660 : 180, 0.3);
}

function initAudio() {
  if (!audio) {
    const AudioEngine = window.AudioContext || window.webkitAudioContext;
    if (AudioEngine) audio = new AudioEngine();
  }
  if (audio && audio.state === 'suspended') audio.resume().catch(() => {});
}

function tone(frequency, duration = 0.07, wave = 'square', gain = 0.035) {
  if (!soundEnabled || !audio) return;
  try {
    const oscillator = audio.createOscillator();
    const volume = audio.createGain();
    oscillator.type = wave;
    oscillator.frequency.setValueAtTime(frequency, audio.currentTime);
    volume.gain.setValueAtTime(gain, audio.currentTime);
    volume.gain.exponentialRampToValueAtTime(
      0.001,
      audio.currentTime + duration
    );
    oscillator.connect(volume);
    volume.connect(audio.destination);
    oscillator.start();
    oscillator.stop(audio.currentTime + duration);
  } catch {}
}

function burst(x, y, color, count = 16) {
  for (let i = 0; i < count; i++) {
    particles.push({
      x,
      y,
      vx: (Math.random() - 0.5) * 300,
      vy: -70 - Math.random() * 200,
      life: 0.55 + Math.random() * 0.4,
      color,
      size: 3 + Math.floor(Math.random() * 3),
    });
  }
}

function addScore(id, value, dunk = false) {
  if (phase !== 'live') return;
  scores[id] += value;
  players[id].buckets++;
  if (dunk) players[id].dunks++;
  players[id].moveKind = null; players[id].protected = 0; players[id].dash = 0;
  rimImpulses[id === 0 ? 1 : 0] = dunk ? 1 : .6;
  players[id].shootPose = .4;
  if (dunk) {
    dunkAnimation = { id, x: players[id].x, y: players[id].y, hoop: HOOPS[id === 0 ? 1 : 0], time: 0 };
    players[id].grounded = false;
  }
  players[id].energy = Math.min(1, players[id].energy + (dunk ? 0.24 : 0.18));
  const hoop = HOOPS[id === 0 ? 1 : 0];
  burst(hoop.x, hoop.y, dunk ? '#ffbb62' : '#d7ff57', dunk ? 30 : 20);
  shake = dunk ? 9 : 4;
  announce(
    dunk
      ? 'BOOM! SLAM DUNK.'
      : value === 3
        ? 'FROM DOWNTOWN! +3'
        : 'BUCKET! +2',
    1.05
  );
  ball.owner = null;
  ball.scored = true;
  ball.shot = null;
  ball.x = hoop.x;
  ball.y = hoop.y + 12;
  ball.vx = 0;
  ball.vy = 140;
  phase = 'point';
  pointTime = dunk ? 1.3 : 1.05;
  nextPossession = selectedMode === 'practice' ? 0 : 1 - id;
  finishingPoint = overtime;
  clearInputs();
  updateScoreboard();
  tone(dunk ? 100 : 760, dunk ? 0.2 : 0.12, dunk ? 'sawtooth' : 'square');
}

function jump(p) {
  if (!p.grounded || phase !== 'live') return;
  p.vy = -p.jump;
  p.grounded = false;
  p.squash = .12;
  burst(p.x, FLOOR - 2, '#9cb7a6', 5);
  tone(190, 0.04, 'triangle', 0.025);
}

function defend(p) {
  if (phase !== 'live' || p.cooldown > 0) return;
  p.cooldown = 0.7;
  p.arm = 0.23;
  const opponent = players[1 - p.id];
  if (
    selectedMode !== 'practice' &&
    ball.owner === opponent.id &&
    opponent.protected <= 0 &&
    p.stunned <= 0 &&
    Math.abs(p.x - opponent.x) < (p.key === 'tank' ? 76 : 64) &&
    Math.abs(p.y - opponent.y) < 73
  ) {
    ball.owner = p.id;
    ball.shot = null;
    ball.scored = false;
    p.steals++;
    p.energy = Math.min(1, p.energy + 0.17);
    opponent.charging = false;
    opponent.charge = 0.15;
    p.aiWait = 0.8;
    burst(p.x, p.y - 60, '#b6fbff', 7);
    announce('CLEAN STEAL!', 0.6);
    tone(410, 0.06);
  } else {
    tryBlock(p, true);
    tone(130, 0.04, 'triangle');
  }
}

function tryBlock(p, active = false) {
  if (
    ball.owner !== null ||
    !ball.shot ||
    ball.scored ||
    ball.lock > 0 ||
    ball.shot.shooter === p.id
  )
    return;
  const handY = p.y - (active || !p.grounded ? 103 : 67);
  if (
    Math.abs(ball.x - p.x) < 43 &&
    Math.abs(ball.y - handY) < 41 &&
    (active || !p.grounded)
  ) {
    ball.vx = (p.id === 0 ? 1 : -1) * (230 + Math.random() * 60);
    ball.vy = -170;
    ball.shot = null;
    ball.lock = 0.16;
    p.blocks++;
    p.energy = Math.min(1, p.energy + 0.2);
    burst(ball.x, ball.y, '#c4ffff', 11);
    announce('GET THAT OUT!', 0.8);
    tone(90, 0.12);
  }
}

function shoot(p, boosted = false) {
  if (phase !== 'live' || ball.owner !== p.id) {
    p.charging = false;
    return;
  }
  const hoop = HOOPS[p.id === 0 ? 1 : 0];
  const distance = Math.abs(hoop.x - p.x);
  const start = { x: p.x + (p.id === 0 ? 14 : -14), y: p.y - 103 };
  if (distance < 93 && p.y < FLOOR - 66) {
    p.shotCount++;
    addScore(p.id, 2, true);
    p.charging = false;
    return;
  }
  const green = p.charge >= 0.55 && p.charge <= 0.79;
  const error = boosted
    ? 0
    : green
      ? (Math.random() - 0.5) * 5
      : (p.charge - 0.67) * 164 * p.accuracy;
  const target = { x: hoop.x + error, y: hoop.y - 2 };
  const ceilingFlight =
    Math.sqrt((2 * Math.max(30, start.y - 105)) / BALL_G) +
    Math.sqrt((2 * (hoop.y - 105)) / BALL_G);
  const flight = Math.min(0.64 + distance / 1000, ceilingFlight);
  const velocity = launchVelocity(start, target, flight, BALL_G);
  ball = {
    ...start,
    ...velocity,
    owner: null,
    lock: 0.23,
    scored: false,
    age: 0,
    spin: 0,
    shot: { shooter: p.id, value: shotPoints(p.x, hoop.x), boosted },
  };
  p.shotCount++;
  p.shootPose = .42;
  p.moveKind = null; p.protected = 0; p.dash = 0;
  p.charging = false;
  p.charge = 0.15;
  p.arm = 0.24;
  p.energy = boosted ? 0 : Math.min(1, p.energy + 0.045);
  p.aiWait = 0.8;
  trail = [];
  if (boosted) {
    announce('HEAT CHECK!', 0.8);
    burst(start.x, start.y, '#d7ff57', 12);
  } else if (green && p.id === 0) {
    announce('GREEN RELEASE!', 0.5);
  }
  tone(boosted ? 570 : 320, 0.07, 'triangle');
}

function boost(p) {
  if (ball.owner !== p.id) {
    if (p.id === 0) setStatus('Grab the ball before using Boost.');
    return;
  }
  if (p.energy < 0.999) {
    if (p.id === 0)
      setStatus('Boost needs 100%. Score, steal and block to fill the meter.');
    return;
  }
  shoot(p, true);
}

function beginAction(id, action) {
  if (phase !== 'live' || (id === 1 && selectedMode !== 'two')) return;
  if (inputs[id].has(action)) return;
  inputs[id].add(action);
  const p = players[id];
  if (action === 'jump') jump(p);
  if (action === 'steal') defend(p);
  if (action === 'boost') boost(p);
  if (['cross', 'behind', 'spin'].includes(action)) dribbleMove(p, action);
  if (action === 'shoot' && ball.owner === id) {
    p.charging = true;
    p.charge = 0.15;
  }
}
function endAction(id, action) {
  inputs[id].delete(action);
  if (action === 'shoot' && players[id]?.charging && phase === 'live')
    shoot(players[id]);
}

function computer(dt) {
  if (selectedMode !== 'cpu') return;
  const p = players[1];
  const other = players[0];
  const level = $('difficulty').value;
  p.aiWait -= dt;
  inputs[1].clear();
  let targetX = p.x;
  if (ball.owner === 1) {
    if (level !== 'easy' && Math.abs(p.x - other.x) < 100 && !p.charging && p.aiWait < .35 && p.moveCooldown <= 0) dribbleMove(p, level === 'hard' ? 'spin' : 'cross');
    targetX = level === 'easy' ? 320 : level === 'hard' ? 245 : 290;
    if (Math.abs(p.x - targetX) > 32 && !p.charging)
      inputs[1].add(p.x > targetX ? 'left' : 'right');
    if (
      Math.abs(p.x - other.x) < 85 &&
      other.x < p.x &&
      p.grounded &&
      p.aiWait < 0.4
    )
      jump(p);
    if (
      !p.charging &&
      p.aiWait <= 0 &&
      (Math.abs(p.x - targetX) < 55 || Math.abs(p.x - other.x) < 68)
    ) {
      p.charging = true;
      p.charge = 0.15;
      p.aiRelease =
        level === 'easy'
          ? 0.45 + Math.random() * 0.36
          : level === 'hard'
            ? 0.65
            : 0.54 + Math.random() * 0.25;
    }
    if (p.charging) {
      inputs[1].add('shoot');
      if (p.charge >= p.aiRelease) shoot(p);
    }
  } else if (ball.owner === 0) {
    targetX = Math.min(886, other.x + (level === 'easy' ? 86 : 52));
    if (Math.abs(p.x - targetX) > 18)
      inputs[1].add(p.x > targetX ? 'left' : 'right');
    if (Math.abs(p.x - other.x) < 72 && p.cooldown <= 0 && p.aiWait <= 0) {
      if (level !== 'easy' || Math.random() < 0.35) defend(p);
      p.aiWait = level === 'hard' ? 0.65 : 1.05;
    }
    if (
      other.charging &&
      other.charge > 0.4 &&
      Math.abs(p.x - other.x) < 115 &&
      p.grounded &&
      level !== 'easy'
    )
      jump(p);
  } else {
    targetX = ball.x;
    if (Math.abs(p.x - targetX) > 12)
      inputs[1].add(p.x > targetX ? 'left' : 'right');
    if (
      ball.y < FLOOR - 105 &&
      ball.y > FLOOR - 225 &&
      Math.abs(p.x - ball.x) < 70 &&
      p.grounded
    )
      jump(p);
  }
}

function stepPlayers(dt) {
  const level = $('difficulty').value;
  for (const p of players) {
    if (selectedMode === 'practice' && p.id === 1) continue;
    p.cooldown = Math.max(0, p.cooldown - dt);
    p.arm = Math.max(0, p.arm - dt);
    p.moveCooldown = Math.max(0, p.moveCooldown - dt);
    p.protected = Math.max(0, p.protected - dt);
    p.stunned = Math.max(0, p.stunned - dt);
    p.stamina = Math.min(100, p.stamina + dt * (p.moveKind ? 5 : 23));
    if (p.moveKind) {
      p.moveAge += dt;
      if (p.moveAge >= p.moveLength) p.moveKind = null;
    }
    p.dash *= Math.exp(-dt * 6);
    p.energy = Math.min(1, p.energy + dt * .023);
    const direction = (inputs[p.id].has('right') ? 1 : 0) - (inputs[p.id].has('left') ? 1 : 0);
    const modifier = p.id === 1 && selectedMode === 'cpu' ? level === 'easy' ? .64 : level === 'hard' ? 1 : .84 : 1;
    const speed = p.speed * modifier * (p.charging ? .48 : 1) * (p.stunned > 0 ? .1 : 1);
    p.vx += (direction * speed - p.vx) * Math.min(1, 13 * dt);
    p.x = Math.max(38, Math.min(922, p.x + (p.vx + p.dash) * dt));
    if (direction) p.face = direction;
    p.walk += Math.abs(p.vx) * dt * .045;
    p.animationClock += dt;
    p.vy += GRAVITY * dt;
    p.y += p.vy * dt;
    if (p.y >= FLOOR) {
      if (!p.grounded && p.vy > 170) {
        p.squash = .19;
        burst(p.x, FLOOR - 1, '#9fbbaa', 5);
        ripples.push({ x: p.x, y: FLOOR, life: .26, color: '#b4d4b577' });
        tone(82, .045, 'triangle', .012);
      }
      p.y = FLOOR; p.vy = 0; p.grounded = true;
    }
    if (p.grounded && Math.abs(p.vx) > 130 && p.landDust <= 0) {
      p.landDust = .19;
      if (!reducedMotion) particles.push({ x: p.x - Math.sign(p.vx) * 12, y: FLOOR - 3, vx: -p.vx * .1, vy: -24, life: .18, size: 3, color: '#a1b5a266' });
    }
    if (ball.owner === p.id && inputs[p.id].has('shoot')) {
      if (!p.charging) { p.charging = true; p.charge = .15; p.moveKind = null; }
      p.charge = Math.min(1, p.charge + dt * .97);
    }
    tryBlock(p);
  }
  if (selectedMode !== 'practice') {
    const a = players[0], b = players[1], dx = b.x - a.x;
    const separation = a.moveKind === 'spin' || b.moveKind === 'spin' ? 0 : 37;
    if (Math.abs(dx) < separation && Math.abs(a.y - b.y) < 74) {
      const push = (separation - Math.abs(dx)) * .5, sign = dx >= 0 ? 1 : -1;
      a.x = Math.max(38, a.x - push * sign);
      b.x = Math.min(922, b.x + push * sign);
    }
  }
}

function stepBall(dt) {
  ball.lock = Math.max(0, ball.lock - dt);
  ball.age += dt;

  if (ball.owner !== null) {
    const p = players[ball.owner];
    const oldCycle = (p.dribbleCycle - dt * (Math.abs(p.vx) > 40 ? 2.4 : 1.7)) % 1;
    const position = handleBallPosition(p);
    ball.x = position.x; ball.y = position.y; ball.behind = position.behind;
    ball.vx = 0; ball.vy = 0; ball.spin += dt * 8 * p.hand;
    if (p.grounded && !p.charging && !p.moveKind && oldCycle < .5 && p.dribbleCycle % 1 >= .5) {
      ripples.push({ x: ball.x, y: FLOOR - 1, life: .18, color: '#b5d3bd66' });
      tone(95, .035, 'triangle', .02);
    }
    return;
  }
  ball.behind = false;
  const previous = { x: ball.x, y: ball.y };
  ball.vy += BALL_G * dt;
  ball.x += ball.vx * dt;
  ball.y += ball.vy * dt;
  ball.spin += ball.vx * dt * 0.025;
  if (ball.shot) {
    trail.push({ x: ball.x, y: ball.y });
    if (trail.length > (ball.shot.boosted ? 16 : 6)) trail.shift();
    const hoop = HOOPS[ball.shot.shooter === 0 ? 1 : 0];
    if (basketCrossing(previous, ball, hoop)) {
      addScore(ball.shot.shooter, ball.shot.value);
      return;
    }
  }
  if (ball.x < 17 || ball.x > W - 17) {
    ball.x = Math.max(17, Math.min(W - 17, ball.x));
    ball.vx *= -0.65;
  }
  if (ball.y < 83) {
    ball.y = 83;
    ball.vy = Math.abs(ball.vy) * 0.45;
  }
  for (const hoop of HOOPS) {
    const boardX = hoop.x < W / 2 ? 65 : 895;
    if (ball.y > 179 && ball.y < 253 && Math.abs(ball.x - boardX) < 11) {
      ball.x = boardX + (previous.x < boardX ? -12 : 12);
      ball.vx *= -0.65;
      tone(170, 0.035, 'triangle', 0.016);
    }
    for (const rimX of [hoop.x - 23, hoop.x + 23]) {
      const dx = ball.x - rimX,
        dy = ball.y - hoop.y;
      const d = Math.hypot(dx, dy);
      if (d < 10 && d > 0.01) {
        const nx = dx / d,
          ny = dy / d;
        const dot = ball.vx * nx + ball.vy * ny;
        ball.x = rimX + nx * 10;
        ball.y = hoop.y + ny * 10;
        if (dot < 0) {
          ball.vx -= 1.65 * dot * nx;
          ball.vy -= 1.65 * dot * ny;
        }
      }
    }
  }
  if (ball.y > FLOOR - 9) {
    ball.y = FLOOR - 9;
    ball.vy = -Math.abs(ball.vy) * 0.64;
    ball.vx *= 0.82;
    if (Math.abs(ball.vy) < 23) ball.vy = 0;
    if (Math.abs(ball.vx) < 6) ball.vx = 0;
  }
  if (ball.lock <= 0 && !ball.scored) {
    for (const p of players) {
      if (selectedMode === 'practice' && p.id === 1) continue;
      if (ball.shot && ball.age < 0.55 && ball.shot.shooter === p.id) continue;
      if (
        Math.abs(ball.x - p.x) < 36 &&
        ball.y > p.y - 96 &&
        ball.y < p.y + 2
      ) {
        ball.owner = p.id;
        ball.shot = null;
        ball.age = 0;
        p.aiWait = 0.55;
        p.charge = 0.15;
        p.charging = false;
        trail = [];
        break;
      }
    }
  }
  if (selectedMode === 'practice' && ball.owner === null && ball.age > 4) {
    ball.owner = 0;
    ball.shot = null;
    ball.scored = false;
    trail = [];
    announce('BALL RETURNED', 0.6);
  }
}

function step(dt) {
  if (phase === 'paused' || phase === 'over') return;
  elapsed += dt;
  updatePresentation(dt);
  particles = particles.filter(p => {
    p.life -= dt;
    p.x += p.vx * dt;
    p.vy += 500 * dt;
    p.y += p.vy * dt;
    return p.life > 0;
  });
  shake = Math.max(0, shake - dt * 30);
  if (calloutTime > 0) {
    calloutTime -= dt;
    if (calloutTime <= 0) $('callout').textContent = '';
  }
  if (phase === 'lobby') {
    stepBall(dt);
    updateScoreboard();
    return;
  }
  if (phase === 'point') {
    pointTime -= dt;
    ball.vy += BALL_G * dt;
    ball.y = Math.min(FLOOR - 8, ball.y + ball.vy * dt);
    if (pointTime <= 0) {
      if (finishingPoint) {
        endMatch();
        return;
      }
      resetCourt(nextPossession);
      phase = 'live';
    }
    updateScoreboard();
    return;
  }
  computer(dt);
  stepPlayers(dt);
  stepBall(dt);
  if (phase === 'live' && selectedMode !== 'practice' && !overtime) {
    remaining = Math.max(0, remaining - dt);
    if (remaining <= 0) {
      if (scores[0] === scores[1]) {
        overtime = true;
        announce('OVERTIME — NEXT BUCKET WINS', 2);
        setStatus('Overtime! The next basket wins.');
      } else endMatch();
    }
  }
  updateScoreboard();
}

function rect(c, x, y, w, h, color) {
  c.fillStyle = color;
  c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

function buildBackdrop() {
  const layer = document.createElement('canvas');
  layer.width = W;
  layer.height = H;
  const c = layer.getContext('2d');
  c.imageSmoothingEnabled = false;
  rect(c, 0, 0, W, H, '#1c3541');
  rect(c, 0, 0, W, 158, '#172a39');
  rect(c, 0, 61, W, 94, '#203745');
  const buildings = [
    [0, 78, 74, 110],
    [81, 41, 83, 145],
    [173, 94, 68, 92],
    [248, 66, 81, 119],
    [336, 108, 51, 80],
    [394, 31, 93, 152],
    [496, 68, 70, 114],
    [574, 92, 84, 96],
    [667, 54, 75, 138],
    [753, 80, 63, 113],
    [826, 29, 87, 157],
    [922, 98, 55, 90],
  ];
  buildings.forEach(([x, y, width, height], i) => {
    rect(c, x, y, width, height, i % 2 ? '#122932' : '#19303d');
    rect(c, x - 3, y - 4, width + 6, 5, '#2a4146');
    for (let wx = x + 12; wx < x + width - 5; wx += 17) {
      for (let wy = y + 16; wy < 154; wy += 21) {
        if ((wx * 7 + wy * 11 + i) % 5 > 1)
          rect(c, wx, wy, 5, 7, (wx + wy) % 3 ? '#b2a96c66' : '#71b6aa55');
      }
    }
  });
  for (let i = 0; i < 26; i++)
    rect(c, (i * 173 + 58) % W, ((i * 37) % 81) + 5, 2, 2, '#a1bec877');
  c.fillStyle = '#2e5a5d55';
  c.beginPath();
  c.moveTo(135, 58);
  c.lineTo(0, 398);
  c.lineTo(395, 398);
  c.fill();
  c.beginPath();
  c.moveTo(825, 58);
  c.lineTo(566, 398);
  c.lineTo(960, 398);
  c.fill();
  [135, 825].forEach(x => {
    rect(c, x - 3, 46, 6, 306, '#324b50');
    rect(c, x - 28, 45, 56, 11, '#172e37');
    rect(c, x - 25, 47, 50, 6, '#d9edc3');
    rect(c, x - 25, 55, 50, 4, '#84977c');
  });
  rect(c, 0, 166, W, 119, '#233e47');
  for (let row = 0; row < 4; row++) {
    const y = 172 + row * 23;
    rect(c, 0, y + 18, W, 6, '#17303a');
    rect(c, 0, y + 18, W, 2, '#456165');
    for (let col = 0; col < 43; col++) {
      const n = (row * 71 + col * 31) % 13;
      if (n < 3) continue;
      const x = col * 23 + (row % 2 ? 7 : 0);
      const shirts = [
        '#587b76',
        '#82775f',
        '#755b6e',
        '#44666f',
        '#567274',
        '#9b795f',
      ];
      rect(c, x, y + 5, 7, 7, n % 2 ? '#b58f70' : '#825f51');
      rect(c, x - 2, y + 12, 11, 8, shirts[n % shirts.length]);
      rect(c, x - 1, y + 3, 8, 3, '#253238');
    }
  }
  c.strokeStyle = '#85a39c17';
  c.lineWidth = 1;
  for (let x = -180; x < W + 180; x += 29) {
    c.beginPath();
    c.moveTo(x, 144);
    c.lineTo(x + 180, 300);
    c.stroke();
    c.beginPath();
    c.moveTo(x, 300);
    c.lineTo(x + 180, 144);
    c.stroke();
  }
  for (let x = 12; x < W; x += 124) rect(c, x, 145, 3, 164, '#718d8540');
  rect(c, 0, 282, W, 66, '#203740');
  rect(c, 0, 282, W, 5, '#526b65');
  rect(c, 0, 343, W, 10, '#152b34');
  rect(c, 332, 295, 296, 34, '#172f37');
  c.fillStyle = '#b4c7a5';
  c.font = 'bold 15px Courier New';
  c.textAlign = 'center';
  c.fillText('NO EASY BUCKETS.', W / 2, 318);
  rect(c, 180, 297, 103, 27, '#7c7350');
  c.fillStyle = '#e7dca7';
  c.font = 'bold 10px Courier New';
  c.fillText('NIGHT LEAGUE', 231, 314);
  rect(c, 677, 297, 103, 27, '#385760');
  c.fillStyle = '#b1d4c4';
  c.fillText('PLAY YOUR WAY', 728, 314);
  rect(c, 0, 353, W, 138, '#365359');
  rect(c, 0, 353, W, 8, '#445e60');
  for (let y = 360; y < 492; y += 21) {
    for (let x = (y % 2) * 30; x < W; x += 76) {
      rect(c, x, y, 73, 1, '#84a09610');
      rect(c, x + 33, y + 4, 2, 1, '#142e3820');
    }
  }
  rect(c, 37, 372, 153, 96, '#744d51');
  rect(c, 770, 372, 153, 96, '#744d51');
  c.strokeStyle = '#b8c3a5';
  c.lineWidth = 2;
  c.strokeRect(38, 371, 884, 98);
  c.strokeRect(38, 383, 152, 75);
  c.strokeRect(770, 383, 152, 75);
  c.beginPath();
  c.moveTo(480, 371);
  c.lineTo(480, 469);
  c.stroke();
  c.beginPath();
  c.ellipse(480, 420, 60, 33, 0, 0, Math.PI * 2);
  c.stroke();
  c.beginPath();
  c.ellipse(188, 420, 36, 37, 0, -Math.PI / 2, Math.PI / 2);
  c.stroke();
  c.beginPath();
  c.ellipse(772, 420, 36, 37, 0, Math.PI / 2, Math.PI * 1.5);
  c.stroke();
  c.beginPath();
  c.ellipse(68, 420, 235, 98, 0, -Math.PI / 2.7, Math.PI / 2.7);
  c.stroke();
  c.beginPath();
  c.ellipse(
    892,
    420,
    235,
    98,
    0,
    Math.PI - Math.PI / 2.7,
    Math.PI + Math.PI / 2.7
  );
  c.stroke();
  c.save();
  c.translate(480, 420);
  c.scale(1, 0.52);
  c.rotate(-0.12);
  c.font = 'italic 900 40px Arial';
  c.fillStyle = '#b8d49955';
  c.fillText('RR', 0, 14);
  c.restore();
  rect(c, 0, 492, W, 48, '#112b34');
  rect(c, 0, 493, W, 4, '#729284');
  rect(c, 0, 500, W, 4, '#29464b');
  c.fillStyle = '#5b7d75';
  c.font = 'bold 8px Courier New';
  c.textAlign = 'left';
  c.fillText('RIM RUSH / DOWNTOWN', 21, 518);
  c.textAlign = 'right';
  c.fillText('LEAVE IT ALL HERE.', 937, 518);
  return layer;
}




function pixelLimb(c, x1, y1, x2, y2, width, color, outline = '#102532') {
  const steps = Math.max(1, Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 3));
  for (let pass = 0; pass < 2; pass++) {
    const w = pass === 0 ? width + 4 : width;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const x = Math.round((x1 + (x2 - x1) * t) / 2) * 2;
      const y = Math.round((y1 + (y2 - y1) * t) / 2) * 2;
      rect(c, x - w / 2, y - w / 2, w, w, pass === 0 ? outline : color);
    }
  }
}

function drawBaller(c, p, x = p.x, y = p.y, scale = 1) {
  const time = p.preview ? p.previewClock : elapsed;
  const moving = Math.min(1, Math.abs(p.vx || 0) / 190);
  const stride = Math.sin(p.walk || 0) * 11 * moving;
  const bob = p.grounded ? Math.sin((p.walk || 0) * 2) * moving * 1.7 + Math.sin(time * 3) * .7 : -2;
  const lean = Math.max(-5, Math.min(5, (p.vx || 0) / 60));
  const body = -61 + bob;
  const isDunk = !p.preview && dunkAnimation?.id === p.id;
  const shooting = p.charging || p.shootPose > 0;
  const defending = p.arm > 0 && !shooting;
  const protectedMove = p.moveKind === 'spin' || p.moveKind === 'behind';
  const bulge = p.key === 'tank' ? 3 : 0;
  const outline = '#102532';
  let spinScale = 1;
  if (p.moveKind === 'spin') spinScale = Math.cos(Math.min(1, p.moveAge / p.moveLength) * Math.PI * 2);
  if (Math.abs(spinScale) < .2) spinScale = spinScale < 0 ? -.2 : .2;
  c.save(); c.translate(Math.round(x), Math.round(y));
  c.scale(scale * spinScale * (1 + (p.squash || 0) * .4), scale * (1 - (p.squash || 0) + (!p.grounded ? .035 : 0)));

  const lift = !p.grounded ? Math.min(13, Math.abs(p.vy || 0) * .025) : 0;
  const feet = [
    { hip: -9, knee: -13 + stride * .65, ankle: -12 - stride, y: -5 - lift * .5 },
    { hip: 10, knee: 12 - stride * .65, ankle: 12 + stride, y: -5 - lift }
  ];
  for (const f of feet) {
    pixelLimb(c, f.hip, -27, f.knee, -17 - lift * .35, 9, shade(p.skin, .78));
    pixelLimb(c, f.knee, -17 - lift * .35, f.ankle, f.y, 8, p.skin);
    rect(c, f.ankle - 5, f.y - 3, 10, 5, p.trim);
    rect(c, f.ankle - 7, f.y + 1, 19, 7, outline);
    rect(c, f.ankle - 5, f.y + 1, 16, 4, p.shoes || '#e4e9da');
    rect(c, f.ankle - 6, f.y + 6, 18, 2, '#e2efd1');
    rect(c, f.ankle + 2, f.y + 2, 5, 2, p.trim);
  }
  rect(c, -19 - bulge, -36 + bob, 38 + bulge * 2, 16, outline);
  rect(c, -16 - bulge, -35 + bob, 32 + bulge * 2, 13, p.dark);
  rect(c, -1, -34 + bob, 3, 14, outline);
  rect(c, -17 - bulge, -25 + bob, 14, 3, p.trim);
  rect(c, 3, -25 + bob, 15 + bulge, 3, p.trim);

  let held = null;
  if (p.preview && p.previewBall) held = { x: p.previewBall.x - p.x, y: p.previewBall.y - p.y };
  else if (!p.ghost && ball.owner === p.id) held = { x: ball.x - p.x, y: ball.y - p.y };
  const armData = [];
  for (const side of [-1, 1]) {
    const shoulder = { x: side * (20 + bulge) + lean, y: body + 4 };
    let elbow = { x: side * (26 + bulge) - stride * side * .25, y: body + 17 };
    let hand = { x: side * (26 + bulge) + stride * side * .4, y: body + 31 };
    if (isDunk) {
      elbow = { x: side * 29, y: -89 };
      hand = { x: (p.id === 0 ? 24 : -24) + side * 5, y: -92 };
    } else if (shooting) {
      elbow = { x: side * 28 + lean, y: -88 };
      hand = { x: (p.id === 0 ? 14 : -14) + side * 7, y: p.charging ? -107 : -115 };
    } else if (defending) {
      elbow = { x: side * 31 + p.face * 8, y: -88 };
      hand = { x: side * 25 + p.face * 14, y: -113 };
    } else if (held && side === p.hand) {
      hand = { x: Math.max(-43, Math.min(43, held.x)), y: Math.max(-106, held.y - 9) };
      elbow = { x: shoulder.x + side * 6, y: shoulder.y + (hand.y - shoulder.y) * .5 };
    } else if (!p.grounded) {
      elbow = { x: side * 30 + lean, y: -78 };
      hand = { x: side * 34 + lean, y: -92 };
    } else if (protectedMove) {
      hand = { x: side * 31, y: -43 };
      elbow = { x: side * 29, y: -52 };
    }
    armData.push({ side, shoulder, elbow, hand });
  }
  for (const a of armData) {
    const sleeve = (p.gear === 'sleeve' || p.gear === 'both') && a.side === -1;
    pixelLimb(c, a.shoulder.x, a.shoulder.y, a.elbow.x, a.elbow.y, 9, sleeve ? p.trim : shade(p.skin, .9));
    pixelLimb(c, a.elbow.x, a.elbow.y, a.hand.x, a.hand.y, 8, sleeve ? shade(p.trim, .8) : p.skin);
    rect(c, a.hand.x - 5, a.hand.y - 4, 10, 8, outline);
    rect(c, a.hand.x - 4, a.hand.y - 3, 8, 6, p.skin);
    if (sleeve) rect(c, a.hand.x - 4, a.hand.y - 6, 8, 3, p.color);
  }
  rect(c, -20 - bulge + lean, body - 5, 40 + bulge * 2, 35, outline);
  rect(c, -17 - bulge + lean, body - 4, 34 + bulge * 2, 33, p.color);
  rect(c, -17 - bulge + lean, body - 2, 8, 31, p.dark);
  rect(c, 13 + bulge + lean, body + 4, 4, 25, shade(p.color, .8));
  rect(c, -11 + lean, body - 4, 23, 4, p.trim);
  rect(c, -6 + lean, body - 5, 13, 4, p.skin);
  rect(c, -17 - bulge + lean, body + 24, 34 + bulge * 2, 3, p.trim);
  rect(c, 11 + lean, body + 3, 3, 4, p.trim);
  c.fillStyle = p.trim; c.font = 'bold 14px Courier New'; c.textAlign = 'center';
  c.fillText(p.number, 3 + lean, body + 19);
  rect(c, -5 + lean, body - 11, 11, 8, shade(p.skin, .85));

  const hx = Math.round(lean * 1.3);
  const hy = Math.round(-106 + bob);
  rect(c, hx - 24, hy + 3, 48, 36, outline);
  rect(c, hx - 27, hy + 10, 54, 21, outline);
  rect(c, hx - 22, hy + 5, 44, 33, p.skin);
  rect(c, hx - 25, hy + 11, 50, 17, p.skin);
  rect(c, hx - 22, hy + 8, 8, 27, shade(p.skin, .78));
  rect(c, hx + 16, hy + 10, 5, 24, shade(p.skin, .9));
  rect(c, hx - 24, hy + 18, 5, 7, shade(p.skin, .88));
  rect(c, hx + 20, hy + 18, 5, 7, shade(p.skin, .88));
  const hair = p.hairstyle || 'crop';
  if (hair === 'crop') {
    rect(c, hx - 24, hy, 47, 12, p.hair);
    rect(c, hx - 26, hy + 7, 9, 12, p.hair);
    rect(c, hx - 9, hy - 4, 28, 7, p.hair);
    rect(c, hx - 14, hy + 1, 23, 3, shade(p.hair, 1.3));
  } else if (hair === 'fade') {
    rect(c, hx - 22, hy + 1, 44, 8, p.hair);
    rect(c, hx - 24, hy + 8, 5, 10, shade(p.hair, 1.25));
    rect(c, hx + 19, hy + 8, 5, 10, shade(p.hair, 1.25));
  } else if (hair === 'curls') {
    for (let i = 0; i < 7; i++) {
      rect(c, hx - 26 + i * 7, hy - (i % 2 ? 5 : 1), 11, 14, p.hair);
      rect(c, hx - 24 + i * 7, hy - (i % 2 ? 4 : 0), 5, 3, shade(p.hair, 1.25));
    }
    rect(c, hx - 26, hy + 8, 8, 12, p.hair);
  } else if (hair === 'spikes') {
    rect(c, hx - 23, hy + 3, 46, 9, p.hair);
    for (let i = 0; i < 6; i++) rect(c, hx - 23 + i * 8, hy - 7 + (i % 2) * 4, 5, 14, p.hair);
  } else if (hair === 'long') {
    rect(c, hx - 26, hy + 5, 9, 33, p.hair);
    rect(c, hx + 18, hy + 6, 9, 32, p.hair);
    rect(c, hx - 22, hy, 46, 12, p.hair);
    rect(c, hx - 15, hy - 3, 34, 8, p.hair);
    rect(c, hx - 18, hy + 5, 12, 13, p.hair);
  } else {
    rect(c, hx - 12, hy + 4, 25, 3, shade(p.skin, 1.1));
  }
  if (p.gear === 'headband' || p.gear === 'both') {
    rect(c, hx - 25, hy + 13, 50, 5, outline);
    rect(c, hx - 25, hy + 13, 50, 3, p.trim);
    rect(c, hx - 31, hy + 14, 8, 4, p.trim);
    rect(c, hx - 34 + Math.sin(time * 9) * 2, hy + 18, 10, 3, p.trim);
  }
  const look = p.face || 1;
  const blink = Math.sin(time * 1.8 + p.id) > .994;
  if (blink) {
    rect(c, hx - 12, hy + 24, 11, 2, outline);
    rect(c, hx + 7, hy + 24, 11, 2, outline);
  } else {
    rect(c, hx - 13 + look, hy + 21, 12, 8, '#fff3da');
    rect(c, hx + 6 + look, hy + 21, 12, 8, '#fff3da');
    rect(c, hx - 7 + look * 3, hy + 22, 4, 6, outline);
    rect(c, hx + 11 + look * 3, hy + 22, 4, 6, outline);
    rect(c, hx - 14, hy + 18, 14, 3, p.hair);
    rect(c, hx + 6, hy + 18, 14, 3, p.hair);
  }
  rect(c, hx + 2 + look * 3, hy + 30, 5, 3, shade(p.skin, .8));
  rect(c, hx - 3, hy + 36, 14, isDunk ? 5 : 2, '#5c4037');
  if (p.stamina < 27) rect(c, hx + 24, hy + 25, 3, 6, '#9fddf6');
  c.restore();
}

function drawBasketball(c, x, y, spin = 0, style = preferences.ball, hot = false) {
  const colors = hot || style === 'lime' ? ['#e6ff95', '#c7ef49', '#8aa62d', '#4d6929'] : style === 'ice' ? ['#c0f5ff', '#82d9f1', '#4799ba', '#285b74'] : ['#ffbd71', '#f29249', '#cc6334', '#763e2e'];
  c.save(); c.translate(Math.round(x), Math.round(y)); c.rotate(spin);
  rect(c, -7, -10, 14, 20, '#172b32'); rect(c, -10, -7, 20, 14, '#172b32');
  rect(c, -7, -8, 14, 16, colors[0]); rect(c, -8, -6, 16, 12, colors[1]);
  rect(c, -6, 2, 12, 5, colors[2]);
  c.strokeStyle = colors[3]; c.lineWidth = 1.5;
  c.beginPath(); c.moveTo(-8, 0); c.lineTo(8, 0); c.moveTo(0, -8); c.lineTo(0, 8); c.stroke();
  c.beginPath(); c.moveTo(-6, -7); c.quadraticCurveTo(4, 0, -6, 7); c.stroke();
  rect(c, -5, -6, 3, 2, '#fff0c5'); c.restore();
}
function drawBall(c) {
  drawBasketball(c, ball.x, ball.y, ball.spin || 0, preferences.ball, ball.shot?.boosted);
}

function buildThemedBackdrop(theme) {
  const layer = buildBackdrop();
  const c = layer.getContext('2d');
  const maps = {
    sunset: { '172a39': '724a65', '203745': 'a16774', '122932': '36364d', '19303d': '433c56', '1c3541': '6c586c', '233e47': '655463', '203740': '4b455a', '365359': '78646a', '744d51': 'a5726b', '112b34': '333747', '152b34': '302b40' },
    neon: { '172a39': '15162f', '203745': '252746', '122932': '141d38', '19303d': '1a2041', '1c3541': '17264a', '233e47': '2e3151', '203740': '22263f', '365359': '303b61', '744d51': '67455f', '112b34': '141b35', '152b34': '151b34' }
  };
  if (maps[theme]) {
    const image = c.getImageData(0, 0, W, H);
    const map = new Map(Object.entries(maps[theme]).map(([a, b]) => [parseInt(a, 16), parseInt(b, 16)]));
    const data = image.data;
    for (let i = 0; i < data.length; i += 4) {
      const color = (data[i] << 16) | (data[i + 1] << 8) | data[i + 2];
      if (map.has(color)) { const next = map.get(color); data[i] = next >> 16; data[i + 1] = (next >> 8) & 255; data[i + 2] = next & 255; }
    }
    c.putImageData(image, 0, 0);
    c.textAlign = 'center'; c.font = 'bold 12px Courier New';
    rect(c, 332, 295, 296, 34, theme === 'neon' ? '#151d3b' : '#40394c');
    c.fillStyle = theme === 'neon' ? '#c1ff80' : '#ffe0ae';
    c.fillText(theme === 'neon' ? 'AFTER DARK. ALL HEART.' : 'GOLDEN HOUR. GOLDEN TOUCH.', 480, 317);
  }
  if (theme === 'sunset') {
    rect(c, 718, 63, 54, 6, '#f6c68c'); rect(c, 712, 69, 66, 23, '#ffbe8c'); rect(c, 718, 92, 54, 6, '#eaa38a');
  }
  if (theme === 'neon') {
    for (const x of [39, 921]) rect(c, x, 174, 2, 264, '#9a6ae9');
    c.strokeStyle = '#c1ff8577'; c.lineWidth = 2; c.strokeRect(38, 371, 884, 98);
  }
  return layer;
}

function drawHoop(c, hoop) {
  const left = hoop.x < W / 2;
  const boardX = left ? 60 : 890;
  const impact = rimImpulses[left ? 0 : 1];
  const wobble = Math.sin(elapsed * 37) * impact * 4;
  rect(c, left ? 37 : 915, 218, 9, 220, '#102b36');
  rect(c, left ? 45 : 899, 214, 18, 10, '#74908c');
  rect(c, boardX - 4, 171, 15, 90, '#112a33');
  rect(c, boardX, 175, 7, 81, impact > .1 ? '#e4ffbd' : '#c0d9c4');
  rect(c, boardX + (left ? 4 : -1), 199, 5, 46, '#78a1a1');
  const netY = hoop.y + wobble;
  c.strokeStyle = '#d5e8cfbb'; c.lineWidth = 1.5;
  for (let i = 0; i < 5; i++) {
    c.beginPath(); c.moveTo(hoop.x - 20 + i * 10, netY + 3);
    c.lineTo(hoop.x - 11 + i * 5.5 + wobble * 1.3, netY + 32 + impact * 8); c.stroke();
  }
  [11, 21, 31].forEach((dy, i) => {
    c.beginPath(); c.moveTo(hoop.x - 19 + i * 3 + wobble * i * .4, netY + dy + impact * i * 3);
    c.lineTo(hoop.x + 19 - i * 3 + wobble * i * .4, netY + dy + impact * i * 3); c.stroke();
  });
  rect(c, hoop.x - 26, netY - 3, 52, 5, '#2f2a2e');
  rect(c, hoop.x - 25, netY - 3, 50, 3, '#ff9660');
  rect(c, left ? 29 : 908, FLOOR + 1, 30, 9, '#162f38');
}

function drawPracticeGuide() {
  const p = players[0];
  if (selectedMode !== 'practice' || !preferences.guide || !p.charging || ball.owner !== 0) return;
  const hoop = HOOPS[1];
  const start = { x: p.x + 14, y: p.y - 103 };
  const green = p.charge >= .55 && p.charge <= .79;
  const error = green ? 0 : (p.charge - .67) * 164 * p.accuracy;
  const cap = Math.sqrt(2 * Math.max(30, start.y - 105) / BALL_G) + Math.sqrt(2 * (hoop.y - 105) / BALL_G);
  const flight = Math.min(.64 + Math.abs(hoop.x - p.x) / 1000, cap);
  const v = launchVelocity(start, { x: hoop.x + error, y: hoop.y - 2 }, flight, BALL_G);
  ctx.globalAlpha = .45;
  for (let t = .08; t <= flight; t += .07) {
    rect(ctx, start.x + v.vx * t - 2, start.y + v.vy * t + .5 * BALL_G * t * t - 2, 3, 3, green ? '#dcff75' : '#aad5df');
  }
  ctx.globalAlpha = 1;
}

function draw() {
  ctx.save();
  if (shake > 0 && preferences.shake && !reducedMotion) ctx.translate((Math.random() - .5) * shake, (Math.random() - .5) * shake);
  ctx.drawImage(backdrop, 0, 0);
  if (!reducedMotion) {
    for (let i = 0; i < 22; i++) {
      const x = 15 + i * 43;
      const jump = Math.sin(elapsed * (3 + i % 3) + i * 1.7) > .82 ? 3 : 0;
      rect(ctx, x, 218 - jump, 5, 4, ['#b3bfa0', '#759f9e', '#ba8b76'][i % 3]);
    }
  }
  for (const hoop of HOOPS) drawHoop(ctx, hoop);
  for (const r of ripples) {
    ctx.strokeStyle = r.color; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.ellipse(r.x, r.y, (1 - r.life / .3) * 23 + 5, 3, 0, 0, Math.PI * 2); ctx.stroke();
  }
  drawPracticeGuide();
  for (const ghost of ghosts) {
    ctx.globalAlpha = ghost.life * 1.6;
    drawBaller(ctx, { ...ghost.player, ghost: true }, ghost.x, ghost.y, 1);
  }
  ctx.globalAlpha = 1;
  if (ball.behind && ball.owner !== null) drawBall(ctx);
  for (const p of players) {
    if (selectedMode === 'practice' && p.id === 1) continue;
    ctx.fillStyle = '#0a203b77';
    ctx.beginPath(); ctx.ellipse(p.x, FLOOR + 4, Math.max(14, 30 - (FLOOR - p.y) / 15), 6, 0, 0, Math.PI * 2); ctx.fill();
    if (p.energy >= .999 && phase !== 'lobby') {
      for (let i = 0; i < 5; i++) {
        const a = elapsed * 3 + i * Math.PI * 2 / 5;
        rect(ctx, p.x + Math.cos(a) * 35, p.y - 54 + Math.sin(a) * 39, 3, 4, '#d7ff57');
      }
    }
    drawBaller(ctx, p);
    if (p.protected > 0 && phase === 'live') {
      ctx.strokeStyle = '#84e5ff66'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(p.x, p.y - 47, 40, 51, 0, -.8, 1.3); ctx.stroke();
    }
    if (p.stunned > 0) {
      ctx.fillStyle = '#fff197'; ctx.font = 'bold 11px Courier New'; ctx.textAlign = 'center'; ctx.fillText('✦ ✦', p.x, p.y - 119);
    }
    if (phase !== 'lobby') {
      ctx.textAlign = 'center'; ctx.font = 'bold 8px Courier New';
      ctx.fillStyle = p.id === 0 ? '#e4ff9b' : '#ffbe91';
      ctx.fillText(p.id === 0 ? selectedMode === 'two' ? 'P1' : 'YOU' : selectedMode === 'two' ? 'P2' : 'CPU', Math.round(p.x), Math.round(p.y - 126));
      if (p.id === 0) {
        ctx.fillStyle = '#d7ff57'; ctx.beginPath(); ctx.moveTo(p.x - 4, p.y - 122); ctx.lineTo(p.x + 4, p.y - 122); ctx.lineTo(p.x, p.y - 117); ctx.fill();
      }
    }
    if (p.charging && ball.owner === p.id) {
      const mx = p.x - 30, my = p.y - 145;
      rect(ctx, mx - 2, my - 2, 64, 11, '#0b2530'); rect(ctx, mx, my, 60, 7, '#9e6843');
      rect(ctx, mx + 33, my, 15, 7, '#d7ff57'); rect(ctx, mx + p.charge * 58, my - 2, 3, 11, '#ffffff');
      if (p.id === 0 && p.charge >= .55 && p.charge <= .79) {
        ctx.fillStyle = '#d7ff57'; ctx.font = 'bold 8px Courier New'; ctx.fillText('RELEASE!', p.x, my - 6);
      }
    }
  }
  if (ball.owner === null && ball.shot) {
    trail.forEach((t, i) => {
      ctx.globalAlpha = (i + 1) / trail.length * .55;
      rect(ctx, t.x - 3, t.y - 3, ball.shot.boosted ? 9 : 4, ball.shot.boosted ? 9 : 4, ball.shot.boosted ? '#d7ff57' : '#ffd3a0');
    }); ctx.globalAlpha = 1;
  }
  if (!(ball.behind && ball.owner !== null)) drawBall(ctx);
  for (const p of particles) {
    ctx.globalAlpha = Math.min(1, p.life * 2.5); rect(ctx, p.x, p.y, p.size, p.size, p.color);
  }
  ctx.globalAlpha = 1; ctx.restore();
}




let backdrop = buildBackdrop();
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;


function refreshPortraits() {
  document.querySelectorAll('[data-portrait]').forEach(portrait => {
    const c = portrait.getContext('2d');
    c.clearRect(0, 0, 60, 64);
    c.imageSmoothingEnabled = false;
    drawBaller(
      c,
      { ...makePlayer(0, portrait.dataset.portrait, false), face: 1 },
      30,
      65,
      0.58
    );
  });
}

function keyAction(code) {
  const p1 = {
    KeyA: 'left',
    KeyD: 'right',
    KeyW: 'jump',
    KeyJ: 'shoot',
    KeyK: 'steal',
    KeyL: 'boost',
    KeyC: 'cross', KeyQ: 'behind', KeyE: 'spin',
  };
  if (p1[code]) return [0, p1[code]];
  if (selectedMode === 'two') {
    const p2 = {
      ArrowLeft: 'left',
      ArrowRight: 'right',
      ArrowUp: 'jump',
      ArrowDown: 'steal',
      Enter: 'shoot',
      ShiftRight: 'boost',
      Slash: 'cross', Period: 'behind', Comma: 'spin',
    };
    if (p2[code]) return [1, p2[code]];
  } else {
    const aliases = {
      ArrowLeft: 'left',
      ArrowRight: 'right',
      ArrowUp: 'jump',
      ArrowDown: 'steal',
      Space: 'shoot',
    };
    if (aliases[code]) return [0, aliases[code]];
  }
  return null;
}

window.addEventListener('keydown', event => {
  if (
    ['SELECT', 'INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName) ||
    $('help-dialog').open || $('locker-dialog').open
  )
    return;
  if (event.code === 'KeyF' && !event.repeat) { event.preventDefault(); toggleFullscreen(); return; }
  if (event.code === 'Escape' && isExpanded()) { event.preventDefault(); exitExpanded(); return; }
  if (event.code === 'Escape' || event.code === 'KeyP') {
    if (phase === 'live' || phase === 'point') {
      event.preventDefault();
      pauseGame();
    } else if (phase === 'paused') {
      event.preventDefault();
      resumeGame();
    }
    return;
  }
  if (phase !== 'live') return;
  const action = keyAction(event.code);
  if (!action) return;
  event.preventDefault();
  if (event.repeat || activeKeys.has(event.code)) return;
  activeKeys.set(event.code, action);
  beginAction(action[0], action[1]);
});
window.addEventListener('keyup', event => {
  const action = activeKeys.get(event.code);
  if (!action) return;
  event.preventDefault();
  activeKeys.delete(event.code);
  if (
    ![...activeKeys.values(), ...pointers.values()].some(
      other => other[0] === action[0] && other[1] === action[1]
    )
  )
    endAction(action[0], action[1]);
});
window.addEventListener('blur', clearInputs);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) pauseGame();
});

document.querySelectorAll('[data-action]').forEach(button => {
  button.addEventListener('contextmenu', e => e.preventDefault());
  button.addEventListener('pointerdown', e => {
    e.preventDefault();
    if (phase !== 'live') return;
    button.setPointerCapture(e.pointerId);
    const action = [0, button.dataset.action];
    pointers.set(e.pointerId, action);
    button.classList.add('pressed');
    beginAction(0, action[1]);
  });
  const release = e => {
    const action = pointers.get(e.pointerId);
    if (!action) return;
    pointers.delete(e.pointerId);
    button.classList.remove('pressed');
    if (
      ![...activeKeys.values(), ...pointers.values()].some(
        other => other[0] === action[0] && other[1] === action[1]
      )
    )
      endAction(0, action[1]);
  };
  button.addEventListener('pointerup', release);
  button.addEventListener('pointercancel', release);
  button.addEventListener('lostpointercapture', release);
});

document.querySelectorAll('[data-mode]').forEach(button => {
  button.addEventListener('click', () => {
    selectedMode = button.dataset.mode;
    document.querySelectorAll('[data-mode]').forEach(b => {
      const chosen = b === button;
      b.classList.toggle('selected', chosen);
      b.setAttribute('aria-pressed', String(chosen));
    });
    $('difficulty').disabled = selectedMode !== 'cpu';
    $('duration').disabled = selectedMode === 'practice';
    $('lobby-tip').textContent =
      selectedMode === 'two'
        ? 'One keyboard · P1: WASD + JKL · P2: arrows + Enter'
        : touchDevice
          ? 'Use the touch buttons · Hold Shoot, release in green'
          : 'WASD to move · Hold J to shoot · K to steal';
    showLobby();
  });
});
document.querySelectorAll('[data-baller]').forEach(button => {
  button.addEventListener('click', () => {
    selectedBaller = button.dataset.baller;
    document.querySelectorAll('[data-baller]').forEach(b => {
      const chosen = b === button;
      b.classList.toggle('selected', chosen);
      b.setAttribute('aria-pressed', String(chosen));
    });
    $('baller-trait').textContent = ROSTER[selectedBaller].trait;
    showLobby();
  });
});
$('duration').addEventListener('change', () => {
  if (phase === 'lobby') showLobby();
});
$('start-button').addEventListener('click', startMatch);
$('pause-button').addEventListener('click', () =>
  phase === 'paused' ? resumeGame() : pauseGame()
);
$('resume-button').addEventListener('click', resumeGame);
$('restart-button').addEventListener('click', startMatch);
$('quit-button').addEventListener('click', showLobby);
$('rematch-button').addEventListener('click', startMatch);
$('result-lobby-button').addEventListener('click', showLobby);
$('sound-button').addEventListener('click', () => {
  soundEnabled = !soundEnabled;
  if (soundEnabled) initAudio();
  if (soundEnabled && !audio) {
    soundEnabled = false;
    setStatus(
      'Audio is unavailable in this browser. The game is ready to play.'
    );
  }
  $('sound-button').textContent = soundEnabled ? 'SOUND ON' : 'SOUND OFF';
  $('sound-button').setAttribute(
    'aria-label',
    soundEnabled ? 'Mute sound' : 'Enable sound'
  );
  $('sound-button').setAttribute('aria-pressed', String(soundEnabled));
  if (soundEnabled) tone(520, 0.08);
});
function openHelp() {
  resumeAfterHelp = phase === 'live' || phase === 'point';
  if (resumeAfterHelp) pauseGame();
  $('help-dialog').showModal();
}
function closeHelp() {
  $('help-dialog').close();
  if (resumeAfterHelp) {
    resumeAfterHelp = false;
    resumeGame();
  }
}
$('help-open').addEventListener('click', openHelp);
$('help-bottom').addEventListener('click', openHelp);
$('help-close').addEventListener('click', closeHelp);
$('help-done').addEventListener('click', closeHelp);
$('help-dialog').addEventListener('cancel', e => {
  e.preventDefault();
  closeHelp();
});

function applyCourtSettings() {
  backdrop = buildThemedBackdrop(preferences.court);
  $('court-title').textContent = COURTS[preferences.court].title;
  $('court-subtitle').textContent = COURTS[preferences.court].subtitle;
}
function readLookFields() {
  return {
    name: $('custom-name').value, number: $('custom-number').value,
    jersey: $('custom-jersey').value, trim: $('custom-trim').value,
    shoes: $('custom-shoes').value, skin: $('custom-skin').value,
    hair: $('custom-hair').value, hairstyle: $('custom-hairstyle').value,
    gear: $('custom-gear').value
  };
}
function fillLookFields(look) {
  $('custom-name').value = look.name;
  $('custom-number').value = look.number;
  $('custom-jersey').value = look.jersey;
  $('custom-trim').value = look.trim;
  $('custom-shoes').value = look.shoes;
  $('custom-skin').value = look.skin;
  $('custom-hair').value = look.hair;
  $('custom-hairstyle').value = look.hairstyle;
  $('custom-gear').value = look.gear;
  $('custom-error').textContent = '';
}
function openLocker() {
  lockerResume = phase === 'live' || phase === 'point';
  if (lockerResume) pauseGame();
  editingPlayer = 0;
  lockerDraft = players.map((p, id) => ({ ...(preferences.looks[id] || defaultLook(p.key)) }));
  lockerOptions = { court: preferences.court, ball: preferences.ball, shake: preferences.shake, guide: preferences.guide };
  fillLookFields(lockerDraft[0]);
  $('custom-court').value = lockerOptions.court;
  $('custom-ball').value = lockerOptions.ball;
  $('custom-shake').checked = lockerOptions.shake;
  $('custom-guide').checked = lockerOptions.guide;
  updateEditorTabs();
  $('locker-dialog').showModal();
}
function updateEditorTabs() {
  document.querySelectorAll('[data-edit-player]').forEach(button => {
    const chosen = Number(button.dataset.editPlayer) === editingPlayer;
    button.classList.toggle('selected', chosen);
    button.setAttribute('aria-pressed', String(chosen));
  });
}
function closeLocker() {
  $('locker-dialog').close();
  if (lockerResume) { lockerResume = false; resumeGame(); }
}
function saveLocker(event) {
  event.preventDefault();
  lockerDraft[editingPlayer] = readLookFields();
  for (let id = 0; id < 2; id++) {
    const number = Number(lockerDraft[id].number);
    if (lockerDraft[id].number === '' || !Number.isInteger(number) || number < 0 || number > 99) {
      editingPlayer = id; updateEditorTabs(); fillLookFields(lockerDraft[id]);
      $('custom-error').textContent = 'Choose a whole jersey number from 0 to 99.';
      $('custom-number').focus();
      return;
    }
  }
  preferences = {
    looks: lockerDraft.map((look, id) => normalizeLook(look, players[id].key)),
    court: COURTS[$('custom-court').value] ? $('custom-court').value : 'downtown',
    ball: ['classic', 'lime', 'ice'].includes($('custom-ball').value) ? $('custom-ball').value : 'classic',
    shake: $('custom-shake').checked, guide: $('custom-guide').checked
  };
  let saved = true;
  try { localStorage.setItem(LOOK_KEY, JSON.stringify(preferences)); } catch { saved = false; }
  players.forEach(p => applyLook(p));
  applyCourtSettings(); updateScoreboard();
  closeLocker();
  setStatus(saved ? 'Look saved. Your style is ready for the court.' : 'Look applied for this session. Browser storage is unavailable.');
}
function isExpanded() {
  return Boolean(document.fullscreenElement || document.webkitFullscreenElement || $('game-cabinet').classList.contains('immersive'));
}
function updateExpandedUI() {
  const expanded = isExpanded();
  document.body.classList.toggle('game-expanded', expanded);
  const button = $('fullscreen-button');
  button.innerHTML = expanded ? '⛶ <span>EXIT FULLSCREEN</span>' : '⛶ <span>FULLSCREEN</span>';
  button.setAttribute('aria-label', expanded ? 'Exit fullscreen' : 'Enter fullscreen');
  button.setAttribute('aria-pressed', String(expanded));
}
function enterImmersive() {
  $('game-cabinet').classList.add('immersive');
  updateExpandedUI();
  canvas.focus({ preventScroll: true });
  setStatus('Expanded play is on. Use F or the fullscreen button to return.');
}
async function exitExpanded() {
  $('game-cabinet').classList.remove('immersive');
  try {
    if (document.fullscreenElement && document.exitFullscreen) await document.exitFullscreen();
    else if (document.webkitFullscreenElement && document.webkitExitFullscreen) document.webkitExitFullscreen();
  } catch {}
  updateExpandedUI();
  canvas.focus({ preventScroll: true });
}
async function toggleFullscreen() {
  if (fullscreenBusy) return;
  fullscreenBusy = true;
  if (isExpanded()) {
    await exitExpanded();
    fullscreenBusy = false;
    return;
  }
  const cabinet = $('game-cabinet');
  const request = cabinet.requestFullscreen || cabinet.webkitRequestFullscreen;
  if (!request) {
    enterImmersive(); fullscreenBusy = false; return;
  }
  try {
    await request.call(cabinet);
    if (!document.fullscreenElement && !document.webkitFullscreenElement) enterImmersive();
    else { updateExpandedUI(); canvas.focus({ preventScroll: true }); }
  } catch { enterImmersive(); }
  fullscreenBusy = false;
}
function renderLockerPreview(now) {
  if (!$('locker-dialog').open) return;
  previewClock = now / 1000;
  const c = $('locker-preview').getContext('2d');
  c.clearRect(0, 0, 300, 300);
  c.imageSmoothingEnabled = false;
  const look = normalizeLook(readLookFields(), players[editingPlayer].key);
  const p = applyLook(makePlayer(editingPlayer, players[editingPlayer].key, false), false, look);
  p.x = 150; p.y = 241; p.preview = true; p.dribbleCycle = previewClock * 1.7;
  p.hand = 1; p.walk = 0; p.previewClock = previewClock;
  const position = handleBallPosition(p);
  p.previewBall = position;
  c.fillStyle = '#91c88d22'; c.beginPath(); c.ellipse(150, 254, 61, 11, 0, 0, Math.PI * 2); c.fill();
  drawBaller(c, p, 150, 241, 1.55);
  c.save(); c.translate(150, 241); c.scale(1.55, 1.55);
  drawBasketball(c, (position.x - p.x), (position.y - p.y), previewClock * 6, $('custom-ball').value);
  c.restore();
  $('preview-name').textContent = look.name;
  $('preview-build').textContent = players[editingPlayer].key === 'bolt' ? 'QUICK FEET / SPEEDSTER' : players[editingPlayer].key === 'tank' ? 'BIG POWER / HIGH FLYER' : 'BALANCED / ALL-ROUNDER';
  $('preview-speed').textContent = players[editingPlayer].key === 'bolt' ? '●●●●●' : players[editingPlayer].key === 'tank' ? '●●●' : '●●●●';
  $('preview-power').textContent = players[editingPlayer].key === 'tank' ? '●●●●●' : '●●●';
}
function initializeUpgrades() {
  const cabinet = $('game-cabinet');
  cabinet.appendChild($('help-dialog'));
  cabinet.appendChild($('locker-dialog'));
  $('locker-form').setAttribute('novalidate', '');
  $('locker-open').addEventListener('click', openLocker);
  $('locker-toolbar').addEventListener('click', openLocker);
  $('locker-close').addEventListener('click', closeLocker);
  $('locker-dialog').addEventListener('cancel', event => { event.preventDefault(); closeLocker(); });
  $('locker-form').addEventListener('submit', saveLocker);
  $('fullscreen-button').addEventListener('click', toggleFullscreen);
  document.addEventListener('fullscreenchange', updateExpandedUI);
  document.addEventListener('webkitfullscreenchange', updateExpandedUI);
  document.querySelectorAll('[data-edit-player]').forEach(button => {
    button.addEventListener('click', () => {
      lockerDraft[editingPlayer] = readLookFields();
      editingPlayer = Number(button.dataset.editPlayer);
      fillLookFields(lockerDraft[editingPlayer]); updateEditorTabs();
    });
  });
  document.querySelectorAll('[data-jersey]').forEach(button => {
    button.addEventListener('click', () => { $('custom-jersey').value = button.dataset.jersey; });
  });
  $('reset-look').addEventListener('click', () => { fillLookFields(defaultLook(players[editingPlayer].key)); });
  applyCourtSettings();
  updateExpandedUI();
}

initializeUpgrades();
refreshPortraits();
updateRecord();
showLobby();
if (touchDevice)
  $('lobby-tip').textContent =
    'Use the touch buttons · Hold Shoot, release in green';
let previousTime = performance.now();
let accumulator = 0;
function frame(now) {
  accumulator += Math.min(0.05, (now - previousTime) / 1000);
  previousTime = now;
  while (accumulator >= 1 / 120) {
    step(1 / 120);
    accumulator -= 1 / 120;
  }
  draw();
  renderLockerPreview(now);
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

