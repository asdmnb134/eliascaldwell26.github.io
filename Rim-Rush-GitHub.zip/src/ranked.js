export const RANKS = [
  { name: 'Rookie', minimum: 0, color: '#a5b5c8', icon: 'Ⅰ' },
  { name: 'Bronze', minimum: 200, color: '#d29463', icon: 'Ⅱ' },
  { name: 'Silver', minimum: 400, color: '#d3e6f4', icon: 'Ⅲ' },
  { name: 'Gold', minimum: 600, color: '#ffd16a', icon: '★' },
  { name: 'Platinum', minimum: 800, color: '#7ce1d1', icon: '✦' },
  { name: 'Diamond', minimum: 1000, color: '#80caff', icon: '◆' },
  { name: 'Elite', minimum: 1200, color: '#b6a0ff', icon: '✧' },
  { name: 'Master', minimum: 1400, color: '#ff91c7', icon: '✪' },
  { name: 'Grandmaster', minimum: 1600, color: '#ff8c65', icon: '♜' },
  { name: 'Legend', minimum: 1800, color: '#f8eb8d', icon: '♛' }
];

export function rankFor(points = 0) {
  const rating = Math.max(0, Math.floor(Number(points) || 0));
  const index = Math.min(9, Math.floor(rating / 200));
  return { ...RANKS[index], index, rating, next: RANKS[index + 1] || null,
    progress: index === 9 ? 1 : (rating - RANKS[index].minimum) / 200 };
}
