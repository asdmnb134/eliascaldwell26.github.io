const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rating=(p,key)=>p.ratings?.[key]||3;
export function lanePressure(from,to,defenders) {
  const dx=to.x-from.x,dy=to.y-from.y,length=dx*dx+dy*dy||1;
  let pressure=0;
  for(const d of defenders){const t=clamp(((d.x-from.x)*dx+(d.y-from.y)*dy)/length,0,1);if(t<.12||t>.9)continue;const gap=Math.hypot(d.x-from.x-dx*t,d.y-from.y-dy*t);pressure=Math.max(pressure,clamp((38-gap)/38,0,1));}
  return pressure;
}
export function courtContest(p,players,hoop) {
  const toward={x:hoop.x-p.x,y:hoop.y-p.y},len=Math.hypot(toward.x,toward.y)||1;
  return players.filter(d=>d.team!==p.team&&!(d.fallTime>0)).reduce((best,d)=>{
    const gap=distance(p,d),dx=d.x-p.x,dy=d.y-p.y;if(gap>94)return best;
    const front=.3+.7*clamp(((dx*toward.x+dy*toward.y)/(Math.max(1,gap)*len)+.35)/1.35,0,1);
    return Math.max(best,clamp((94-gap)/70,0,1)*front);
  },0);
}
export function shotQuality(p,world) {
  const hoop=world.hoops[p.team?0:1],range=distance(p,hoop),contest=courtContest(p,world.players,hoop);
  const close=range<76,skill=rating(p,close?'finish':'three');
  return (close?1.22:range>230&&range<340?1.28:.84)*skill/5-contest*.85-Math.max(0,range-350)*.0025;
}
export function bestPass(p,world) {
  const hoop=world.hoops[p.team?0:1],defenders=world.players.filter(d=>d.team!==p.team),own=shotQuality(p,world);
  return world.players.filter(m=>m.team===p.team&&m.id!==p.id).map(m=>{
    const lane=lanePressure(p,m,defenders),advance=(distance(p,hoop)-distance(m,hoop))*.0017;
    const back=p.lastPass?.from===m.id? .13:0;
    return {player:m,lane,value:shotQuality(m,world)-own+advance-lane*.52-back};
  }).sort((a,b)=>b.value-a.value)[0]||null;
}
export function offensiveSpot(p,owner,world) {
  const hoop=world.hoops[p.team?0:1],sign=p.team?-1:1,clock=world.time;
  const isBig=['C','PF'].includes(p.position),goodShooter=rating(p,'three')>=3.5;
  let depth=[285,250,205,90,64][p.slot]||180,y=world.cy+[0,-130,133,-82,77][p.slot];
  if(isBig&&!goodShooter){depth=65;y=world.cy+(p.slot%2?62:-62);}
  if(isBig&&owner&&distance(owner,hoop)>170) {
    const screen=(clock+p.id*1.7)%8;
    if(screen<1.6)return {x:owner.x+sign*34,y:owner.y+(p.slot%2?22:-22)};
    if(screen<4){depth=37;y=world.cy+(p.slot%2?23:-23);}
  } else if(owner&&(clock+p.id*2.1)%10<1.8&&p.slot>1){depth=55;y=world.cy+(p.slot%2?32:-32);}
  return {x:clamp(hoop.x-sign*depth,112,880),y:clamp(y+Math.sin(clock*.8+p.id)*9,129,450)};
}
export function chooseOffense(p,world) {
  const hoop=world.hoops[p.team?0:1],range=distance(p,hoop),contest=courtContest(p,world.players,hoop),pass=bestPass(p,world);
  const big=p.position==='C'&&rating(p,'three')<3;
  const urgent=world.shotClock<4,openFinish=range<77&&contest<.65;
  const moveBall=world.passes<2&&world.shotClock>10&&range>125;
  if(pass&&p.possessionAge>.65&&p.aiPassCooldown<=0&&pass.lane<.85&&!openFinish&&
    (pass.value>(contest>.5?-.02:.16)||moveBall&&pass.value>-.16))return {action:'pass',receiver:pass.player};
  if(urgent||range<(big?69:rating(p,'three')>=4?320:278)&&(contest<.53||p.possessionAge>3.5||world.shotClock<7))return {action:'shoot'};
  const nearest=world.players.filter(d=>d.team!==p.team&&!(d.fallTime>0)).sort((a,b)=>distance(a,p)-distance(b,p))[0];
  const y=world.cy+Math.sin(world.time*1.1+p.id)*(big?24:80);
  if(nearest&&distance(nearest,p)<45&&p.moveCooldown<=0)return {action:'move',move:contest>.55&&range<270?'stepback':p.slot%2?'behind':'cross',target:{x:hoop.x-(p.team?-1:1)*(big?35:150),y}};
  return {action:'drive',target:{x:hoop.x-(p.team?-1:1)*(big?35:145),y}};
}

export function defensiveAssignment(p, owner, players, hoop) {
  const defenders = players.filter(d => d.team === p.team && !(d.fallTime > 0));
  const nearest = [...defenders].sort((a, b) => distance(a, owner) - distance(b, owner))[0];
  const previous = defenders.find(d => d.id === owner.guardId);
  const onBall = previous && nearest && distance(previous, owner) < distance(nearest, owner) + 38 ? previous : nearest;
  owner.guardId = onBall?.id;
  const others = defenders.filter(d => d !== onBall).sort((a, b) => a.id - b.id);
  const attackers = players.filter(a => a.team !== p.team && a.id !== owner.id).sort((a, b) => a.id - b.id);
  const target = p === onBall ? owner : attackers[others.findIndex(d => d.id === p.id)] || owner;
  const gap = distance(target, hoop) || 1, space = p === onBall ? 43 : 38;
  return { x: target.x + (hoop.x - target.x) / gap * space + target.vx * .1,
    y: target.y + (hoop.y - target.y) / gap * space + target.vy * .1, onBall: p === onBall };
}

// Choose a stable side around a body, rather than pushing directly into it.
export function steerAroundPlayers(p, target, players, time, bounds) {
  let dx = target.x - p.x, dy = target.y - p.y, gap = Math.hypot(dx, dy);
  if (gap < 8) return { x: 0, y: 0 };
  dx /= gap; dy /= gap;
  if (!p.navMark || time - p.navMark.time > .7) {
    if (p.navMark && gap > 45 && Math.hypot(p.x - p.navMark.x, p.y - p.navMark.y) < 10) p.evadeUntil = time + .9;
    p.navMark = { x: p.x, y: p.y, time };
  }
  const candidates = players.filter(o => o.id !== p.id && !(o.fallTime > 0) && !o.dunk).map(o => {
    const x = o.x - p.x, y = o.y - p.y;
    return { player: o, ahead: x * dx + y * dy, cross: dx * y - dy * x, gap: Math.hypot(x, y) };
  }).filter(o => o.ahead > -5 && o.ahead < 66 && Math.abs(o.cross) < 34 && o.gap < gap + 26).sort((a, b) => a.gap - b.gap);
  const obstacle = candidates[0];
  if (obstacle) {
    if (p.avoidId !== obstacle.player.id || time > (p.avoidUntil || 0)) {
      p.avoidId = obstacle.player.id;
      p.avoidSide = Math.abs(obstacle.cross) > 4 ? -Math.sign(obstacle.cross) : p.id % 2 ? -1 : 1;
      p.avoidUntil = time + 1.1;
    }
    let side = p.avoidSide;
    const wallY = p.y + dx * side * 45, wallX = p.x - dy * side * 45;
    if (wallY < bounds.top + 34 || wallY > bounds.bottom - 16 || wallX < bounds.left + 20 || wallX > bounds.right - 20) side *= -1;
    const turn = (p.evadeUntil || 0) > time ? 1.5 : 1.08;
    const forward = obstacle.gap < 35 ? .22 : .65;
    const x = dx * forward - dy * side * turn, y = dy * forward + dx * side * turn;
    const length = Math.hypot(x, y) || 1;
    return { x: x / length, y: y / length };
  }
  return { x: dx, y: dy };
}
