import { PLAYER_SHOOTING, ZONE_KEYS, ZONE_NAMES } from './shooting-data.js';

const clamp = (value, low, high) => Math.max(low, Math.min(high, value));

export function classifyShot(player, hoop) {
  const depth = Math.abs(hoop.x - player.x);
  const lateral = (player.y - hoop.y) * (hoop.x > 496 ? 1 : -1);
  const distance = Math.hypot(depth, lateral);
  if (distance > 500) return { index: 6, distance, value: 3 };
  if (distance > 230) {
    const corner = Math.abs(lateral) > 128 && depth < 200;
    return { index: corner ? lateral < 0 ? 3 : 4 : 5, distance, value: 3 };
  }
  return { index: distance < 54 ? 0 : depth < 155 && Math.abs(lateral) < 69 ? 1 : 2, distance, value: 2 };
}

export function zoneBaseRate(player, index) {
  const data = PLAYER_SHOOTING[player.nbaId || player.id];
  const sample = data?.zones[index];
  if (sample?.[1] > 0) {
    return { base: sample[0] / sample[1], made: sample[0], attempts: sample[1], season: data.season, source: 'NBA zone', estimated: false };
  }
  if (data) {
    const related = data.zones.slice(index < 3 ? 0 : 3, index < 3 ? 3 : 6);
    const made = related.reduce((sum, zone) => sum + zone[0], 0);
    const attempts = related.reduce((sum, zone) => sum + zone[1], 0);
    if (attempts > 0) return { base: made / attempts, made, attempts, season: data.season, source: index < 3 ? 'NBA 2P fallback' : 'NBA 3P fallback', estimated: false };
  }
  const ratings = player.ratings || {};
  const finish = ratings.finish || 3, three = ratings.three || 3;
  const estimates = [.43 + finish * .052, .28 + finish * .038, .22 + three * .043,
    .15 + three * .049, .15 + three * .049, .12 + three * .049, .008];
  return { base: estimates[index], made: null, attempts: 0, season: null, source: 'Estimated · no NBA sample', estimated: true };
}

export function playerShotChance(player, hoop, contest = 0) {
  const location = classifyShot(player, hoop), record = zoneBaseRate(player, location.index);
  const coverage = 1 - clamp(contest, 0, 1) * .72;
  const movement = 1 - clamp((Math.hypot(player.vx || 0, player.vy || 0) - 35) / 180, 0, .24);
  const fatigue = 1 - clamp((45 - (player.stamina ?? 100)) / 100, 0, .28);
  const deep = Math.exp(-Math.max(0, location.distance - 330) / 135);
  let chance = record.base * coverage * movement * fatigue * deep;
  if (location.distance > 500) chance = Math.min(chance, .025 * Math.exp(-(location.distance - 500) / 170));
  return { ...record, ...location, zone: ZONE_KEYS[location.index], label: ZONE_NAMES[location.index], chance: clamp(chance, 0, .97), contest: clamp(contest, 0, 1) };
}
