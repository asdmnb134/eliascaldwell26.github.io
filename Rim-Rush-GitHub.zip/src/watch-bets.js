// Play money only. This bank is separate from animation-shop coins.
export function createWatchBets(storage) {
  const key = 'rimrush-watch-bets-v1';
  let state = { version: 1, balance: 500, active: null, history: [] }, warning = '';
  try {
    const saved = JSON.parse(storage.getItem(key) || 'null');
    if (saved?.version === 1 && Number.isSafeInteger(saved.balance) && saved.balance >= 0) {
      state = { version: 1, balance: Math.min(10000000, saved.balance), active: saved.active || null,
        history: Array.isArray(saved.history) ? saved.history.slice(0, 12) : [] };
      // A full page reload abandons the running simulation; an accepted stake remains spent.
      if (state.active) finish('forfeit');
    }
  } catch { warning = 'Your play-money save could not be read. A new 500-credit bank is ready.'; }
  function save() {
    try { storage.setItem(key, JSON.stringify(state));warning = ''; }
    catch { warning = 'Play-money storage is unavailable. Wagers are disabled until browser storage is available.';throw Error(warning); }
  }
  function commit(next) {
    const previous = state;state = next;
    try { save(); } catch (err) { state = previous;throw err; }
  }
  function place({ id, side, amount, teams }) {
    if (state.active) throw Error('Your current wager is already locked.');
    if (![0, 1].includes(side) || !Array.isArray(teams) || teams.length !== 2 || teams[0].id === teams[1].id) throw Error('Choose two different teams and a winner.');
    if (!Number.isSafeInteger(amount) || amount < 10) throw Error('Enter a whole-number wager of at least 10 play credits.');
    if (amount > state.balance) throw Error('You do not have enough play credits.');
    if (!id) throw Error('Choose a valid watch game.');
    const active = { id, side, amount, teams: teams.map(t => ({ id: t.id, name: t.name })), placedAt: Date.now() };
    commit({ ...state, balance: state.balance - amount, active });return active;
  }
  function finish(winner) {
    const wager = state.active;if (!wager) return null;
    const won = winner === wager.side, payout = won ? wager.amount * 2 : 0;
    const result = { ...wager, outcome: winner === 'forfeit' ? 'abandoned' : won ? 'won' : 'lost', payout, settledAt: Date.now() };
    commit({ ...state, balance: Math.min(10000000, state.balance + payout), active: null, history: [result, ...state.history].slice(0, 12) });return result;
  }
  function refill() {
    if (state.active) throw Error('Finish your current watch game first.');
    if (state.balance >= 10) throw Error('A free refill is available when you have fewer than 10 play credits.');
    commit({ ...state, balance: 500 });
  }
  return { get state() { return state; }, get warning() { return warning; }, place, finish, refill };
}
