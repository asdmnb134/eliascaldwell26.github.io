import { SHOT_EFFECTS, EFFECT_DURATION, drawShotEffect } from './shot-effects.js';

export const TRAINING_UPGRADES = [
  { id: 'timing', name: 'Shooting Lab', icon: '◎', color: '#b9f48b', description: '+2.5% green-window width per level. Applies to shot timing; NBA percentage shooting stays unchanged.' },
  { id: 'handles', name: 'Ankle Breaker', icon: '↝', color: '#c6b3ff', description: '+3 percentage points to ankle-breaker chance and 4% shorter dribble cooldown per level.' },
  { id: 'conditioning', name: 'Conditioning', icon: '↗', color: '#85dcff', description: '8% faster stamina recovery and 3% less dribble stamina cost per level.' }
];
export const UPGRADE_PRICES = [150, 250, 400, 600, 850];

export function createAnimationShop(storage) {
  const key='rimrush-animation-shop-v1',catalog=new Map(SHOT_EFFECTS.map(e=>[e.id,e]));
  let state={version:1,coins:1000,owned:['fireworks'],equipped:'fireworks',trigger:'threes',effectScale:1.4,upgrades:{timing:0,handles:0,conditioning:0}},warning='';
  try {
    const saved=JSON.parse(storage.getItem(key)||'null');
    if(saved?.version===1) {
      const owned=[...new Set(['fireworks',...(Array.isArray(saved.owned)?saved.owned:[]).filter(id=>catalog.has(id))])];
      state={version:1,coins:Number.isFinite(saved.coins)?Math.max(0,Math.min(10000000,Math.floor(saved.coins))):1000,owned,
        equipped:saved.equipped==='none'?'none':owned.includes(saved.equipped)?saved.equipped:'fireworks',trigger:saved.trigger==='all'?'all':'threes',effectScale:Math.max(1,Math.min(2,Number(saved.effectScale)||1.4)),
        upgrades:Object.fromEntries(TRAINING_UPGRADES.map(item=>[item.id,Number.isInteger(saved.upgrades?.[item.id])?Math.max(0,Math.min(5,saved.upgrades[item.id])):0]))};
    }
  } catch {warning='The animation save could not be read. A fresh collection is ready.';}
  function save(){try{storage.setItem(key,JSON.stringify(state));warning='';}catch{warning='Browser storage is full. This session still works, but your collection could not be saved.';}}
  function buy(id) {
    const item=catalog.get(id);if(!item)throw Error('Choose a shop animation.');
    if(state.owned.includes(id))throw Error('You already own this animation. Equip it below.');
    if(state.coins<item.price)throw Error('You need '+(item.price-state.coins)+' more coins. Make shots and finish games to earn them.');
    state.coins-=item.price;state.owned.push(id);state.equipped=id;save();return item;
  }
  function equip(id){if(id!=='none'&&!state.owned.includes(id))throw Error('Unlock this animation before equipping it.');state.equipped=id;save();}
  function earn(amount){if(!Number.isInteger(amount)||amount<=0)return;state.coins=Math.min(10000000,state.coins+amount);save();}
  function trigger(value){state.trigger=value==='all'?'all':'threes';save();}
  function upgrade(id) {
    const item=TRAINING_UPGRADES.find(track=>track.id===id);
    if(!item)throw Error('Choose a player upgrade.');
    const level=state.upgrades[id];
    if(level>=UPGRADE_PRICES.length)throw Error('This upgrade is already maxed out.');
    const price=UPGRADE_PRICES[level];
    if(state.coins<price)throw Error('You need '+(price-state.coins)+' more coins for this level.');
    state.coins-=price;state.upgrades[id]=level+1;save();return {item,level:level+1,price};
  }
  function setEffectScale(value){state.effectScale=Math.max(1,Math.min(2,Number(value)||1.4));save();}
  return {get state(){return state;},get warning(){return warning;},catalog:SHOT_EFFECTS,training:TRAINING_UPGRADES,upgradePrices:UPGRADE_PRICES,buy,equip,earn,trigger,upgrade,setEffectScale,save};
}
export function createAnimationShopView(manager,hooks) {
  const $=id=>document.getElementById(id),dialog=$('animation-shop-dialog'),grid=$('shop-items'),preview=$('shop-preview');
  const c=preview.getContext('2d');let selected='nuke',previewStart=0,lastNow=0,paused=false,filter='all',tab='effects';
  function render(){
    const state=manager.state,item=manager.catalog.find(e=>e.id===selected),own=state.owned.includes(selected);
    $('shop-balance').textContent=state.coins.toLocaleString();$('menu-coins').textContent=state.coins.toLocaleString();
    $('shop-owned').textContent=state.owned.length+' / '+manager.catalog.length+' UNLOCKED';
    $('shop-effect-scale').value=String(Math.round(state.effectScale*100));$('shop-scale-value').textContent=Math.round(state.effectScale*100)+'%';
    $('shop-animations').hidden=tab!=='effects';$('shop-upgrades').hidden=tab!=='upgrades';
    for(const id of ['effects','upgrades']){$('shop-tab-'+id).classList.toggle('selected',tab===id);$('shop-tab-'+id).setAttribute('aria-pressed',String(tab===id));}
    $('shop-upgrade-cards').innerHTML=manager.training.map(track=>{
      const level=state.upgrades[track.id],maxed=level>=5,price=manager.upgradePrices[level],shortfall=price-state.coins;
      return '<article class="upgrade-card" style="--upgrade-color:'+track.color+'"><span class="upgrade-icon" aria-hidden="true">'+track.icon+'</span><span class="upgrade-level">LEVEL '+level+' / 5</span><h3>'+track.name+'</h3><p>'+track.description+'</p><div class="upgrade-progress" aria-label="Level '+level+' of 5">'+[1,2,3,4,5].map(n=>'<i class="'+(n<=level?'filled':'')+'"></i>').join('')+'</div><button type="button" data-upgrade="'+track.id+'"'+(maxed||shortfall>0?' disabled':'')+'>'+(maxed?'MAX LEVEL ✓':shortfall>0?'NEED '+shortfall+' MORE COINS':'UPGRADE TO LVL '+(level+1)+' · '+price+' COINS')+'</button></article>';
    }).join('');
    $('shop-preview-title').textContent=item.name;$('shop-preview-copy').textContent=item.description;
    $('shop-preview-tier').textContent=item.tier;$('shop-preview-tier').style.color=item.color;
    $('shop-trigger').value=state.trigger;$('shop-enable').checked=state.equipped!=='none';
    const buy=$('shop-buy');buy.disabled=!own&&state.coins<item.price;
    buy.textContent=state.equipped===selected?'EQUIPPED ✓':own?'EQUIP ANIMATION':state.coins<item.price?'NEED '+(item.price-state.coins)+' MORE COINS':'UNLOCK · '+item.price+' COINS';
    grid.innerHTML=manager.catalog.filter(e=>filter==='all'||state.owned.includes(e.id)).map((e,i)=>'<button type="button" class="shop-item '+(selected===e.id?'selected ':'')+(state.equipped===e.id?'equipped':'')+'" data-effect="'+e.id+'" aria-pressed="'+(selected===e.id)+'" style="--effect:'+e.color+'"><span class="shop-item-art" aria-hidden="true"><b>'+String(manager.catalog.indexOf(e)+1).padStart(2,'0')+'</b><canvas width="180" height="100" data-shop-thumb="'+e.id+'"></canvas></span><span class="shop-item-tier">'+e.tier+'</span><strong>'+e.name+'</strong><small>'+(state.equipped===e.id?'EQUIPPED ✓':state.owned.includes(e.id)?'OWNED':e.price+' COINS')+'</small></button>').join('');
    for(const thumb of grid.querySelectorAll?.('[data-shop-thumb]')||[]) {
      const pen=thumb.getContext('2d');pen.fillStyle='#142a4a';pen.fillRect(0,0,180,100);
      pen.strokeStyle='#f8b862';pen.lineWidth=2;pen.beginPath();pen.ellipse(90,74,12,4,0,0,Math.PI*2);pen.stroke();
      drawShotEffect(pen,thumb.dataset.shopThumb,1.15,{x:90,y:70,scale:.52});
    }
    hooks.onChange?.();
  }
  function message(value,error=false){$('shop-message').textContent=(value||'')+(manager.warning?' '+manager.warning:'');$('shop-message').classList.toggle('error',error);}
  for(const id of ['effects','upgrades'])$('shop-tab-'+id).addEventListener('click',()=>{tab=id;render();});
  $('shop-upgrade-cards').addEventListener('click',event=>{
    const button=event.target.closest('[data-upgrade]');if(!button)return;
    try{const result=manager.upgrade(button.dataset.upgrade);render();$('shop-upgrade-message').textContent=result.item.name+' is now level '+result.level+'. '+result.price+' coins spent.';$('shop-upgrade-message').classList.remove('error');}
    catch(error){$('shop-upgrade-message').textContent=error.message;$('shop-upgrade-message').classList.add('error');}
  });
  grid.addEventListener('click',event=>{const target=event.target.closest('[data-effect]');if(!target)return;selected=target.dataset.effect;previewStart=lastNow;render();message('Previewing '+manager.catalog.find(e=>e.id===selected).name+'.');});
  $('shop-buy').addEventListener('click',()=>{try{if(manager.state.owned.includes(selected))manager.equip(selected);else manager.buy(selected);render();message(manager.catalog.find(e=>e.id===selected).name+' equipped. Your next '+(manager.state.trigger==='threes'?'made three':'made shot')+' gets the effect.');}catch(err){message(err.message,true);}});
  $('shop-preview-replay').addEventListener('click',()=>{previewStart=lastNow;});
  $('shop-filter-all').addEventListener('click',()=>{filter='all';$('shop-filter-all').classList.add('selected');$('shop-filter-owned').classList.remove('selected');render();});
  $('shop-filter-owned').addEventListener('click',()=>{filter='owned';$('shop-filter-owned').classList.add('selected');$('shop-filter-all').classList.remove('selected');render();});
  $('shop-trigger').addEventListener('change',()=>{manager.trigger($('shop-trigger').value);render();message('Animation trigger saved.');});
  $('shop-effect-scale').addEventListener('input',()=>{manager.setEffectScale(Number($('shop-effect-scale').value)/100);$('shop-scale-value').textContent=Math.round(manager.state.effectScale*100)+'%';hooks.onChange?.();});
  $('shop-enable').addEventListener('change',()=>{manager.equip($('shop-enable').checked?(manager.state.owned.includes(selected)?selected:'fireworks'):'none');render();message(manager.state.equipped==='none'?'Shot effects turned off.':'Shot effects enabled.');});
  function open(){paused=hooks.isPlaying();if(paused)hooks.pause();render();message('1,000 welcome coins. Earn 25 per made three, 10 per two, 15 per block and a game-end bonus.');previewStart=lastNow;dialog.showModal();}
  function close(){dialog.close();if(paused){paused=false;hooks.resume();}}
  $('shop-close').addEventListener('click',close);dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
  function draw(now,reduced=false){
    lastNow=now;if(!dialog.open||tab==='upgrades')return;
    const w=preview.width,h=preview.height;c.clearRect(0,0,w,h);const g=c.createLinearGradient(0,0,0,h);g.addColorStop(0,'#0a1434');g.addColorStop(1,'#173c60');c.fillStyle=g;c.fillRect(0,0,w,h);
    for(let i=0;i<37;i++){c.fillStyle=i%3?'#b3d8ff55':'#ffdc8a88';c.fillRect(i*73%w,14+i*47%(h-75),1,1);}
    c.fillStyle='#ad7544';c.fillRect(0,h-38,w,38);c.strokeStyle='#f6dba2';c.lineWidth=2;c.beginPath();c.ellipse(w/2,h-21,70,10,0,0,Math.PI*2);c.stroke();
    const x=w/2,y=h-75;c.fillStyle='#e6f4ff';c.fillRect(x+31,y-72,6,92);c.strokeStyle='#89a7c4';c.lineWidth=6;c.beginPath();c.moveTo(x+34,y);c.lineTo(x+16,y);c.stroke();c.strokeStyle='#fff4e8';c.lineWidth=1;
    for(let i=0;i<7;i++){const a=i/7*Math.PI*2;c.beginPath();c.moveTo(x+Math.cos(a)*18,y+Math.sin(a)*7);c.lineTo(x+Math.cos(a)*10,y+20);c.stroke();}c.strokeStyle='#ff9850';c.lineWidth=4;c.beginPath();c.ellipse(x,y,19,8,0,0,Math.PI*2);c.stroke();
    drawShotEffect(c,selected,((now-previewStart)/1000)%(EFFECT_DURATION+.45),{x,y,scale:.84*manager.state.effectScale,reducedMotion:reduced});
  }
  return {open,close,render,draw,get selected(){return selected;}};
}
